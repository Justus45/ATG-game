extends Node2D
## Baari, jossa myydään Koskenkorvaa.
##  - ulkopuoli: tummansininen katto, neonkyltti "BAARI" ja Koskenkorva-pullo katolla
##  - ovi: E oven edessä vie sisätilaan (kartan ulkopuolella), E sisällä ovelta vie ulos
##  - sisätila: tiski, baarimikko, pullohylly, jakkarat, pöydät ja jukeboksi
##  - tiskillä on kolme tilauspaikkaa: olut, kossu ja shotti (DRINKS). Jokaisella on oma
##    hinta, vahvuus ja imeytymisnopeus. Player2D.drink() nostaa promilleja, ja kun
##    juo tarpeeksi pelaaja on kännissä: kamera heiluu, kuva sumenee ja kaksoistuu,
##    kävely kaartelee ja lopulta pelaaja sammuu. Humalan säädöt ovat Player2D.gd:n yläosassa.
##  - jukeboksi: E vaihtaa kappaletta (Sfx.gd syntetisoi musiikin)
##  - pelit rahasta: biljardi, tikanheitto ja ventti (BarGames.gd)
##  - portsari: liika tappelu, aseet tai rauhallisten asiakkaiden lyöminen -> ulos;
##    toisesta kerrasta kieltolista muutamaksi minuutiksi (Game.bar_strike)
##  - tutut kasvot: rähinöitsijät muistavat edellisen tappelun (Game.grudges)
##  - aukioloajat 12–04, valomerkki neljältä. Oman baarin omistajalle juomat ovat ilmaisia.
##  - baarin kulmalla Kalle (pimeät keikat) ja tiskin päässä baarimikko (tehtävät), JobManager.gd
##
## CityGenerator luo tämän ja kutsuu setup():ia (sama rakenne kuin Armory.gd).

const TILE := 16

# Sisätilan tiilet kaupungin tilemapista (samat kuin Armory.gd:ssä)
const FLOOR_TILE := Vector2i(1, 4)
const WALL_TILE := Vector2i(19, 2)
const DOOR_TILE := Vector2i(13, 10)

const ROOM_W := 22
const ROOM_H := 13
## Sisätila sijaitsee kartan ulkopuolella, eri paikassa kuin asekauppa ja koti
const INTERIOR_ORIGIN := Vector2(-1800.0, 1400.0)
const EXIT_CELL := Vector2i(11, 12)
const SPAWN_CELL := Vector2i(11, 10)

## Huoneen paikalliset pikselikoordinaatit
const COUNTER := Rect2(16.0, 64.0, 320.0, 14.0)
const STAFF_ZONE := Rect2(16.0, 32.0, 320.0, 46.0)   # tiski + sen takaosa (ei kulkua)
const SERVE_SPOT := Rect2(120.0, 80.0, 112.0, 26.0)  # tässä kohdassa E tilaa ryypyn
const TABLE_L := Rect2(54.0, 140.0, 20.0, 20.0)
const TABLE_R := Rect2(278.0, 140.0, 20.0, 20.0)
const JUKEBOX := Rect2(304.0, 104.0, 24.0, 22.0)
const POOL_TABLE := Rect2(120.0, 124.0, 64.0, 30.0)
const SOLIDS: Array[Rect2] = [STAFF_ZONE, TABLE_L, TABLE_R, JUKEBOX, POOL_TABLE]
const OPEN_HOUR := 12
const CLOSE_HOUR := 4
const FIGHT_LIMIT := 20.0      ## sekuntia tappelua ennen kuin portsari puuttuu
const TROUBLE_LIMIT := 3       ## kaadetut asiakkaat / rettelöinti ennen ulosheittoa
const WEAPON_PICKUP_SCENE: PackedScene = preload("res://scenes/entities/weapons/weapon_pickup.tscn")
## Lattia, jolla asiakkaat voivat liikkua (huoneen paikalliset koordinaatit)
const FLOOR_RECT := Rect2(22.0, 38.0, 308.0, 148.0)
## Asiakkaiden aloituspaikat
const PATRON_SPOTS: Array[Vector2] = [
	Vector2(40.0, 118.0), Vector2(300.0, 156.0), Vector2(90.0, 168.0), Vector2(252.0, 96.0),
]
## Sama kuin CityGenerator.NPC_TYPES (NPC-hahmotyyppejä tilemapissa)
const NPC_TYPES := 6
const PatronScript := preload("res://scripts/world/BarPatron.gd")

## -- SÄÄDÄ NÄITÄ --
## Juomalista. alcohol = promillea yhteensä, absorb = sekuntia, joiden aikana promillet
## nousevat (olut nousee hitaasti, shotti melkein heti). sound = Sfx-ääni tarjoillessa.
const DRINKS := [
	{"name": "Olut", "serving": "0,5 l", "price": 3, "alcohol": 0.20, "absorb": 14.0, "sound": "can", "cooldown": 1.2},
	{"name": "Kossu", "serving": "4 cl", "price": 4, "alcohol": 0.30, "absorb": 4.0, "sound": "clink", "cooldown": 0.55},
	{"name": "Shotti", "serving": "2 x 2 cl", "price": 7, "alcohol": 0.45, "absorb": 1.0, "sound": "clink", "cooldown": 0.55},
]
## Vanhat nimet yhteensopivuuden vuoksi (kossu)
const SHOT_PRICE := 4
const SHOT_ALCOHOL := 0.30
const SERVE_COOLDOWN := 0.55

## Onko pelaaja sisällä (HUD:n minikartta piiloutuu kun tämä on tosi)
var inside := false
## Oven keskipiste maailmassa (HUD:n minikartta näyttää tämän kohdan)
var door_px := Vector2.ZERO

var _busy := false
var _saved_limits := {}
var _interior: Node2D
var _view: InteriorView
var _fade: ColorRect
var _last_serve_ms := 0
var _serve_gap_ms := 0
## Jukeboksin kappale (-1 = hiljaa)
var _jukebox_tune := 0
## Asetetaan CityGeneratorin _make_bar:ssa ennen setup():ia
var city: Node2D   # CityGenerator
var roof_rect := Rect2()
var _trouble := 0
var _fight_time := 0.0
var _ejecting := false
var _bottle: Node = null
var _cue: Node = null
var _kalle: Sprite2D
var patrons: Array[Node2D] = []
var _brawl_cd := 0.0   # sekuntia seuraavaan haasteeseen
var _last_shout_ms := -100000
## Rähinöitsijöiden arvonta: jokaisella on tämä todennäköisyys, enintään MAX_ROWDY
const ROWDY_CHANCE := 0.45
const MAX_ROWDY := 2
const SHOUT_GAP := 3.0   # sekuntia kahden huudon välillä (ettei kaikki huuda yhtä aikaa)


## roof = katon suorakulmio pikseleinä, door_center = ovitiilen keskipiste maailmassa.
func setup(tile_set: TileSet, source_id: int, roof: Rect2, door_center: Vector2) -> void:
	add_to_group("bar")
	global_position = Vector2.ZERO  # kaikki piirtokoordinaatit ovat maailmankoordinaatteja
	door_px = door_center

	# --- ulkopuoli ---
	var ext := ExteriorView.new()
	ext.roof = roof
	ext.sign_rect = Rect2(roof.position.x + 10.0, roof.end.y - 19.0, roof.size.x - 20.0, 14.0)
	ext.door_front = door_center + Vector2(0.0, TILE)
	ext.z_index = 50
	add_child(ext)

	_add_portal(door_center + Vector2(0.0, 17.0), true, "Paina E mennäksesi sisään (baari, auki 12–04)")

	# --- Kalle baarin kulmalla: pimeät keikat ---
	var kalle_pos := Vector2(roof_rect.end.x + 10.0, door_center.y + 6.0)
	if roof_rect.size.x <= 0.0:
		kalle_pos = door_center + Vector2(40.0, 6.0)
	_kalle = Sprite2D.new()
	_kalle.offset = Vector2(0, -4)
	_kalle.z_index = 52
	add_child(_kalle)
	_kalle.global_position = kalle_pos
	InteractSpot.create(self, kalle_pos + Vector2(0, 4), Vector2(26, 26),
		"Paina E jutellaksesi Kallen kanssa (pimeät keikat)", _talk_kalle)

	# --- sisätila ---
	_build_interior(tile_set, source_id)

	# --- häivytys ---
	var layer := CanvasLayer.new()
	layer.layer = 100
	add_child(layer)
	_fade = ColorRect.new()
	_fade.color = Color(0.0, 0.0, 0.0, 0.0)
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(_fade)
	_fade.set_anchors_preset(Control.PRESET_FULL_RECT)


func _process(delta: float) -> void:
	_brawl_cd = maxf(_brawl_cd - delta, 0.0)
	if _kalle and _kalle.texture == null and city and city.has_method("npc_tex"):
		_kalle.texture = city.npc_tex(9, Vector2i.DOWN, 0)
	# Turvaverkko: jos pelaaja on siirretty pois sisätilasta (esim. pidätys), palautetaan kamera
	if not inside or _busy:
		return
	# Portsari: liian pitkä tappelu -> ulos. Valomerkki klo 04.
	if active_fighters() > 0:
		_fight_time += delta
		if _fight_time > FIGHT_LIMIT + (6.0 if int(Game.rep.regulars) >= 30 else 0.0):
			eject("Portsari: \"Nyt riittää, painukaa ulos tappelemaan!\"", true)
			return
	else:
		_fight_time = maxf(_fight_time - delta * 0.5, 0.0)
	if not Game.owns_bar and not Game.is_open(OPEN_HOUR, CLOSE_HOUR):
		eject("Valomerkki! Baari sulkeutuu, ulos kaikki.", false)
		return
	var player := get_tree().get_first_node_in_group("player") as Node2D
	if player and player.global_position.distance_to(INTERIOR_ORIGIN) > 1200.0:
		inside = false
		_set_camera_limits(false)
		_clear_patrons()
		_music_off()


# ----------------------------------------------------------------------------
#  SISÄTILA
# ----------------------------------------------------------------------------
func _cell_center(c: Vector2i) -> Vector2:
	return INTERIOR_ORIGIN + Vector2(c.x * TILE + TILE * 0.5, c.y * TILE + TILE * 0.5)


func _build_interior(tile_set: TileSet, source_id: int) -> void:
	_interior = Node2D.new()
	_interior.name = "Interior"
	_interior.position = INTERIOR_ORIGIN
	add_child(_interior)

	# Musta tausta huoneen ympärille
	var bg := ColorRect.new()
	bg.color = Color(0.02, 0.02, 0.04)
	bg.position = Vector2(-1500.0, -1500.0)
	bg.size = Vector2(3000.0 + ROOM_W * TILE, 3000.0 + ROOM_H * TILE)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bg.z_index = -20
	_interior.add_child(bg)

	var floor_layer := TileMapLayer.new()
	floor_layer.tile_set = tile_set
	_interior.add_child(floor_layer)
	for y in ROOM_H:
		for x in ROOM_W:
			var wall := x == 0 or x == ROOM_W - 1 or y <= 1 or y == ROOM_H - 1
			floor_layer.set_cell(Vector2i(x, y), source_id, WALL_TILE if wall else FLOOR_TILE)

	var deco_layer := TileMapLayer.new()
	deco_layer.tile_set = tile_set
	_interior.add_child(deco_layer)
	deco_layer.set_cell(EXIT_CELL, source_id, DOOR_TILE)

	_view = InteriorView.new()
	_view.price = SHOT_PRICE
	_view.menu = DRINKS
	_view.exit_pos = Vector2(EXIT_CELL.x * TILE + TILE * 0.5, EXIT_CELL.y * TILE + TILE * 0.5)
	_interior.add_child(_view)

	# Törmäykset: tiski + sen takaosa, pöydät, jukeboksi
	_add_block(STAFF_ZONE)
	_add_block(TABLE_L)   # pöytä vasemmalla
	_add_block(TABLE_R)   # pöytä oikealla
	_add_block(JUKEBOX)

	# Ovi ulos + tiskin tilauspaikat (yksi kullekin juomalle, vasemmalta oikealle)
	_add_portal(_cell_center(EXIT_CELL) + Vector2(0.0, -17.0), false, "Paina E poistuaksesi")
	var slot_w := SERVE_SPOT.size.x / DRINKS.size()
	for i in DRINKS.size():
		var d: Dictionary = DRINKS[i]
		var center := INTERIOR_ORIGIN + SERVE_SPOT.position + Vector2(slot_w * (i + 0.5), SERVE_SPOT.size.y * 0.5)
		var idx := i
		_add_hotspot(center, Vector2(slot_w, SERVE_SPOT.size.y),
			"Paina E: %s %s (%d $)" % [d.name, d.serving, d.price],
			func(pl: Node2D) -> void: serve(pl, idx))
	# Jukeboksi
	_add_hotspot(INTERIOR_ORIGIN + Vector2(JUKEBOX.position.x - 8.0, JUKEBOX.get_center().y),
		Vector2(18.0, 30.0), "Paina E vaihtaaksesi jukeboksin kappaletta", _use_jukebox)
	_add_block(POOL_TABLE)
	# Pelit ja baarimikko
	_add_hotspot(INTERIOR_ORIGIN + Vector2(POOL_TABLE.position.x - 9.0, POOL_TABLE.get_center().y),
		Vector2(16.0, 30.0), "Paina E pelataksesi biljardia rahasta", func(_pl: Node2D) -> void: _start_game("pool"))
	_add_hotspot(INTERIOR_ORIGIN + Vector2(30.0, 102.0), Vector2(18.0, 22.0),
		"Paina E heittääksesi tikkaa rahasta", func(_pl: Node2D) -> void: _start_game("darts"))
	_add_hotspot(INTERIOR_ORIGIN + Vector2(TABLE_R.get_center().x, TABLE_R.end.y + 10.0), Vector2(26.0, 14.0),
		"Paina E pelataksesi venttiä rahasta", func(_pl: Node2D) -> void: _start_game("cards"))
	_add_hotspot(INTERIOR_ORIGIN + Vector2(266.0, 92.0), Vector2(34.0, 20.0),
		"Paina E jutellaksesi baarimikon kanssa (tehtävät)", _talk_bartender)


func _add_block(rect: Rect2) -> void:
	var body := StaticBody2D.new()
	var cs := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = rect.size
	cs.shape = shape
	body.add_child(cs)
	_interior.add_child(body)
	body.position = rect.get_center()


# ----------------------------------------------------------------------------
#  TARJOILU
# ----------------------------------------------------------------------------
## Tiskin hotspot kutsuu tätä kun pelaaja painaa E:tä. drink_index = DRINKS-listan rivi.
func serve(player: Node2D, drink_index: int = 1) -> void:
	if _busy or not player.has_method("drink"):
		return
	var d: Dictionary = DRINKS[clampi(drink_index, 0, DRINKS.size() - 1)]
	var now := Time.get_ticks_msec()
	if now - _last_serve_ms < _serve_gap_ms:
		return
	_last_serve_ms = now
	_serve_gap_ms = int(float(d.cooldown) * 1000.0)

	var hud := get_tree().current_scene.get_node_or_null("Hud")
	var price: int = d.price
	if Game.owns_bar:
		price = 0
	elif int(Game.rep.regulars) >= 40:
		price = maxi(price - 1, 1)   # kanta-asiakasalennus
	if player.money < price:
		_view.say("Ilman rahaa ei tipu.", 2.2)
		Sfx.play_ui("denied", -6.0)
		if hud:
			hud.show_message("Ei tarpeeksi rahaa: %d $ / %d $" % [player.money, price], 2.0)
		return

	if price > 0:
		player.add_money(-price)
	Game.add_rep("regulars", 1 if randf() < 0.3 else 0)
	var hung: bool = "hangover" in player and player.hangover > 0.3
	_view.say(_serve_line(player.drunk + player.pending_alcohol(), drink_index, hung), 2.4)
	_view.pour(drink_index)
	Sfx.play(d.sound, INTERIOR_ORIGIN + _view.glass_point())
	# Juoma kumotaan hetken kuluttua, sitten promillet alkavat nousta juoman omaa tahtia
	await get_tree().create_timer(0.55).timeout
	if is_instance_valid(player):
		Sfx.play("gulp", player.global_position, -4.0, 0.1)
		player.drink(float(d.alcohol), float(d.absorb))


## Baarimikon kommentti pelaajan nykyisen humalan ja juoman mukaan.
func _serve_line(level: float, drink_index: int = 1, hungover: bool = false) -> String:
	var lines: Array
	if hungover and level < 0.3:
		lines = ["Tasoittava, vai?", "Näytät kamalalta. Tässä.", "Eilinen kostautuu?"]
	elif level < 0.3:
		match drink_index:
			0:
				lines = ["Kylmä kalja, ole hyvä.", "Tuoppi tulossa.", "Hanasta suoraan."]
			2:
				lines = ["Shotti! Kerralla alas.", "Tää potkii.", "Varovasti näiden kanssa."]
			_:
				lines = ["Ole hyvä, Koskenkorvaa.", "Yksi kossu tulossa.", "Pohjanmaan parasta."]
	elif level < 1.0:
		lines = ["Kippis!", "Eiköhän tästä lähde.", "Tuossa, ota ottaa."]
	elif level < 2.0:
		lines = ["Tuleeko vielä yksi?", "Ei tässä oo kiire minnekään.", "Sä oot hyvässä vauhdissa."]
	elif level < 3.0:
		lines = ["Oot varma että tää on viisasta?", "No, sun rahoilla.", "Pidä kiinni tiskistä."]
	else:
		lines = ["Sulle taitaa riittää jo...", "Mä en kyllä ottais enää.", "Kohta lattia kutsuu."]
	return lines[randi() % lines.size()]


## Pelaaja on sammunut: herätetään hänet baarin oven eteen (kutsuu Player2D).
func wake_up_player(player: Node2D) -> void:
	inside = false
	_set_camera_limits(false)
	_clear_patrons()
	_music_off()
	_move_player(player, door_px + Vector2(0.0, 28.0))


# ----------------------------------------------------------------------------
#  ASIAKKAAT JA TAPPELU
# ----------------------------------------------------------------------------
## Uudet asiakkaat joka kerta kun pelaaja astuu sisään.
func _spawn_patrons() -> void:
	_clear_patrons()
	if city == null:
		return
	_brawl_cd = 6.0
	var rowdy_count := 0
	# Huono maine kanta-asiakkaiden keskuudessa = enemmän rähinöitsijöitä
	var chance := ROWDY_CHANCE + (0.2 if int(Game.rep.regulars) <= -20 else 0.0) - (0.15 if int(Game.rep.regulars) >= 30 else 0.0)
	var grudge := Game.random_grudge() if randf() < 0.6 else {}
	for spot in PATRON_SPOTS:
		var p = PatronScript.new()
		if not grudge.is_empty():
			p.grudge = grudge
			grudge = {}
			rowdy_count += 1
		elif rowdy_count < MAX_ROWDY and randf() < chance:
			p.rowdy = true
			rowdy_count += 1
		p.bar = self
		p.city = city
		p.base_row = int(p.grudge.row) if not p.grudge.is_empty() else (randi() % NPC_TYPES) * 3
		p.position = spot
		_interior.add_child(p)
		patrons.append(p)


func _clear_patrons() -> void:
	for p in patrons:
		if is_instance_valid(p):
			p.queue_free()
	patrons.clear()


## Voiko asiakas liikkua tähän pisteeseen (huoneen paikalliset koordinaatit)?
func is_free(p: Vector2) -> bool:
	if not FLOOR_RECT.has_point(p):
		return false
	for r in SOLIDS:
		if r.grow(5.0).has_point(p):
			return false
	return true


func active_fighters() -> int:
	var n := 0
	for p in patrons:
		if is_instance_valid(p) and p.is_fighting():
			n += 1
	return n


## Haastaja saa aloittaa vain kun kukaan ei jo tappele ja edellisestä on hetki.
func can_challenge() -> bool:
	return inside and _brawl_cd <= 0.0 and active_fighters() == 0


## Tappelu alkoi: osa muista asiakkaista liittyy mukaan hetken päästä.
func brawl_alarm(starter: Node2D) -> void:
	for p in patrons:
		if is_instance_valid(p) and p != starter and p.can_join() and randf() < 0.4:
			p.join_fight()


func can_shout() -> bool:
	return Time.get_ticks_msec() - _last_shout_ms > int(SHOUT_GAP * 1000.0)


func note_shout() -> void:
	_last_shout_ms = Time.get_ticks_msec()


func fight_ended() -> void:
	if active_fighters() == 0:
		_brawl_cd = 14.0


# ----------------------------------------------------------------------------
#  PORTSARI JA TUTUT KASVOT
# ----------------------------------------------------------------------------
## Pelaaja kaatoi asiakkaan. Rähinöitsijä muistaa tämän (tutut kasvot).
func note_knockdown(p: Node2D) -> void:
	_trouble += 1
	Game.add_rep("regulars", -1)
	if p.get("rowdy"):
		var g := Game.add_grudge(int(p.base_row))
		var gname := str(g.get("name", ""))
		if int(g.get("beaten", 1)) >= 3:
			Game.remove_grudge(g)
			p.say("%s: Okei, sä voitit... en kiusaa enää." % gname, 2.5)
		elif not p.get("grudge").is_empty():
			p.say("%s: Tää ei jää tähän!" % gname, 2.2)
		else:
			p.grudge = g
			p.say("Mä muistan sun naaman, %s ei unohda!" % gname, 2.4)
	if _trouble >= TROUBLE_LIMIT + (1 if int(Game.rep.regulars) >= 30 else 0):
		eject("Portsari: \"Kolmas kaatunut. Sä lähdet nyt!\"", true)


func note_unprovoked() -> void:
	_trouble += 2
	Game.add_rep("regulars", -4)
	hud_message("Portsari näki, että löit rauhallista asiakasta!", 2.0)
	if _trouble >= TROUBLE_LIMIT:
		eject("Portsari: \"Rauhallisia asiakkaita ei hakata. Ulos!\"", true)


func note_weapon_violence() -> void:
	Game.add_rep("regulars", -8)
	eject("Portsari: \"Aseet ulos täältä! Ja sinä myös!\"", true)


## Portsari heittää pelaajan ulos. strike = merkintä kieltolistaa varten.
func eject(text: String, strike: bool) -> void:
	if _ejecting or not inside:
		return
	_ejecting = true
	var player := get_tree().get_first_node_in_group("player") as Node2D
	hud_message(text, 2.5)
	await get_tree().create_timer(0.8).timeout
	if player and inside:
		_busy = true
		player.set_physics_process(false)
		await _fade_to(1.0)
		inside = false
		_set_camera_limits(false)
		_clear_patrons()
		_music_off()
		_move_player(player, door_px + Vector2(0.0, 28.0))
		await _fade_to(0.0)
		player.set_physics_process(true)
		_busy = false
		if strike:
			if Game.bar_strike():
				hud_message("Pääsit portsarin kieltolistalle! Baari on sinulta kiinni %d min." % Game.bar_ban_minutes_left(), 3.5)
			else:
				hud_message("Portsari heitti sinut ulos. Seuraavasta kerrasta tulee kielto.", 3.0)
	_ejecting = false


func _start_game(game: String) -> void:
	if active_fighters() > 0:
		hud_message("Ei nyt, kesken tappelun!", 1.5)
		return
	var bg := get_tree().get_first_node_in_group("bar_games")
	if bg and bg.has_method("start"):
		bg.start(game)


func _talk_bartender(_player: Node2D) -> void:
	var jm := get_tree().get_first_node_in_group("job_manager")
	if jm and jm.has_method("bartender_menu"):
		jm.bartender_menu()


func _talk_kalle(_player: Node2D) -> void:
	var jm := get_tree().get_first_node_in_group("job_manager")
	if jm and jm.has_method("kalle_menu"):
		jm.kalle_menu(self)


## Takapihan kohta (ryöstökeikka): baarin takana, katon yläpuolella.
func back_alley_point() -> Vector2:
	if roof_rect.size.x > 0.0:
		return Vector2(roof_rect.get_center().x, roof_rect.position.y - 10.0)
	return door_px + Vector2(0.0, -80.0)


## Pullo ja biljardikeppi odottavat paikoillaan aina kun tulet sisään.
func _respawn_props() -> void:
	if not is_instance_valid(_bottle):
		_bottle = WEAPON_PICKUP_SCENE.instantiate()
		_bottle.weapon_id = "bottle"
		_interior.add_child(_bottle)
		_bottle.global_position = INTERIOR_ORIGIN + Vector2(TABLE_L.get_center().x, TABLE_L.end.y + 8.0)
	if not is_instance_valid(_cue):
		_cue = WEAPON_PICKUP_SCENE.instantiate()
		_cue.weapon_id = "cue"
		_interior.add_child(_cue)
		_cue.global_position = INTERIOR_ORIGIN + Vector2(POOL_TABLE.end.x + 10.0, POOL_TABLE.position.y + 4.0)


func hud_message(text: String, seconds: float) -> void:
	var hud := get_tree().current_scene.get_node_or_null("Hud")
	if hud and hud.has_method("show_message"):
		hud.show_message(text, seconds)


# ----------------------------------------------------------------------------
#  OVET
# ----------------------------------------------------------------------------
func _add_portal(center: Vector2, to_inside: bool, prompt: String) -> void:
	_add_hotspot(center, Vector2(24.0, 22.0), prompt,
		func(player: Node2D) -> void: use_portal(player, to_inside))


func _add_hotspot(center: Vector2, size_px: Vector2, prompt: String, action: Callable) -> void:
	var h := Hotspot.new()
	h.prompt = prompt
	h.action = action
	var cs := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = size_px
	cs.shape = shape
	h.add_child(cs)
	add_child(h)
	h.global_position = center


func use_portal(player: Node2D, to_inside: bool) -> void:
	if _busy:
		return
	if to_inside:
		if Game.bar_banned():
			Sfx.play_ui("denied", -4.0)
			hud_message("Portsari: \"Sä oot kieltolistalla. Tuu takas %d min päästä.\"" % Game.bar_ban_minutes_left(), 2.5)
			return
		if not Game.owns_bar and not Game.is_open(OPEN_HOUR, CLOSE_HOUR):
			Sfx.play_ui("denied", -6.0)
			hud_message("Baari on kiinni. Auki %02d–%02d." % [OPEN_HOUR, CLOSE_HOUR], 2.0)
			return
	_busy = true
	player.set_physics_process(false)
	player.set_process_unhandled_input(false)
	if "velocity" in player:
		player.velocity = Vector2.ZERO
	var hud := get_tree().current_scene.get_node_or_null("Hud")
	if hud:
		hud.hide_instruction()

	await _fade_to(1.0)
	if to_inside:
		inside = true
		_set_camera_limits(true)
		_move_player(player, _cell_center(SPAWN_CELL))
		_spawn_patrons()
		_respawn_props()
		_trouble = 0
		_fight_time = 0.0
		_music_on()
		if Game.owns_bar:
			hud_message("Tervetuloa omaan baariisi, pomo! Juomat talon piikkiin.", 2.5)
	else:
		inside = false
		_set_camera_limits(false)
		_clear_patrons()
		_music_off()
		_move_player(player, door_px + Vector2(0.0, 28.0))
	await _fade_to(0.0)

	player.set_physics_process(true)
	player.set_process_unhandled_input(true)
	_busy = false


func _fade_to(alpha: float) -> void:
	var tw := create_tween()
	tw.tween_property(_fade, "color:a", alpha, 0.18)
	await tw.finished


# ----------------------------------------------------------------------------
#  JUKEBOKSI
# ----------------------------------------------------------------------------
func _music_on() -> void:
	_view.music_on = _jukebox_tune >= 0
	if _jukebox_tune >= 0:
		Sfx.play_music(_jukebox_tune, INTERIOR_ORIGIN + JUKEBOX.get_center())


func _music_off() -> void:
	_view.music_on = false
	Sfx.stop_music()


## E jukeboksin edessä: seuraava kappale, viimeisen jälkeen hiljaisuus.
func _use_jukebox(_player: Node2D) -> void:
	_jukebox_tune += 1
	if _jukebox_tune >= Sfx.tune_count():
		_jukebox_tune = -1
	Sfx.play("coin", INTERIOR_ORIGIN + JUKEBOX.get_center(), -8.0, 0.0, 0.8)
	if _jukebox_tune < 0:
		_music_off()
		hud_message("Jukeboksi hiljeni.", 1.8)
	else:
		_music_on()
		hud_message("Jukeboksi: %s" % Sfx.tune_name(_jukebox_tune), 2.2)


## Siirtää pelaajan niin, että hänen törmäysmuotonsa keskipiste on kohdassa target.
func _move_player(player: Node2D, target: Vector2) -> void:
	var col := player.get_node_or_null("CollisionShape2D") as Node2D
	var off := col.position if col else Vector2.ZERO
	player.global_position = target - off
	var cam := _camera()
	if cam:
		cam.global_position = target


func _camera() -> Camera2D:
	return get_viewport().get_camera_2d()


func _set_camera_limits(in_room: bool) -> void:
	var cam := _camera()
	if cam == null:
		return
	if in_room:
		if _saved_limits.is_empty():
			_saved_limits = {
				"l": cam.limit_left, "t": cam.limit_top,
				"r": cam.limit_right, "b": cam.limit_bottom,
			}
		var r := Rect2(INTERIOR_ORIGIN, Vector2(ROOM_W, ROOM_H) * TILE).grow(260.0)
		cam.limit_left = int(r.position.x)
		cam.limit_top = int(r.position.y)
		cam.limit_right = int(r.end.x)
		cam.limit_bottom = int(r.end.y)
	elif not _saved_limits.is_empty():
		cam.limit_left = _saved_limits.l
		cam.limit_top = _saved_limits.t
		cam.limit_right = _saved_limits.r
		cam.limit_bottom = _saved_limits.b
		_saved_limits = {}


# ----------------------------------------------------------------------------
#  SISÄ-LUOKAT
# ----------------------------------------------------------------------------
## Alue, jossa E tekee jotain (ovi tai tiskin tilaus). Näyttää kehotteen ja
## ilmoittautuu pelaajan nearby_portal-kohteeksi, jolloin E kutsuu use():a.
class Hotspot extends Area2D:
	var prompt := ""
	var action: Callable

	func _ready() -> void:
		collision_layer = 0
		collision_mask = 1
		body_entered.connect(_on_enter)
		body_exited.connect(_on_exit)

	func _on_enter(body: Node2D) -> void:
		if not body.has_method("pickup_weapon"):
			return
		body.nearby_portal = self
		var hud := get_tree().current_scene.get_node_or_null("Hud")
		if hud:
			hud.show_instruction(prompt)

	func _on_exit(body: Node2D) -> void:
		if not body.has_method("pickup_weapon"):
			return
		if body.nearby_portal == self:
			body.nearby_portal = null
			var hud := get_tree().current_scene.get_node_or_null("Hud")
			# Vierekkäiset tilauspaikat: siirrytään suoraan naapuriin, jos pelaaja on sen päällä
			for n in get_parent().get_children():
				if n != self and n is Area2D and n.has_method("use") and n.overlaps_body(body):
					body.nearby_portal = n
					if hud:
						hud.show_instruction(str(n.get("prompt")))
					return
			if hud:
				hud.hide_instruction()

	func use(player: Node2D) -> void:
		action.call(player)


## Rakennuksen päälle piirretty ulkoasu: katto, Koskenkorva-pullo, neonkyltti.
class ExteriorView extends Node2D:
	const TILE := 16
	const NEON := Color(1.0, 0.25, 0.7)
	const NAVY := Color(0.09, 0.12, 0.27)
	const KK_BLUE := Color(0.13, 0.4, 0.85)
	var roof := Rect2()
	var sign_rect := Rect2()
	var door_front := Vector2.ZERO
	var _t := 0.0

	func _process(delta: float) -> void:
		_t += delta
		queue_redraw()

	func _draw() -> void:
		# Tummansininen katto + saumat
		draw_rect(roof, NAVY)
		var x := roof.position.x + TILE
		while x < roof.end.x:
			draw_line(Vector2(x, roof.position.y), Vector2(x, roof.end.y), Color(1, 1, 1, 0.05), 1.0)
			x += TILE
		var y := roof.position.y + TILE
		while y < roof.end.y:
			draw_line(Vector2(roof.position.x, y), Vector2(roof.end.x, y), Color(1, 1, 1, 0.05), 1.0)
			y += TILE
		_stripe_border(roof, 4.0)

		# Koskenkorva-pullo katolla
		_bottle(roof.get_center() + Vector2(0.0, -9.0))

		# Neonkyltti (vilkkuu hieman)
		var flick := 0.8 + 0.2 * sin(_t * 5.0)
		if fmod(_t, 6.0) < 0.12:
			flick = 0.3
		var neon := Color(NEON.r, NEON.g, NEON.b, flick)
		draw_rect(sign_rect, Color(0.04, 0.03, 0.09))
		draw_rect(sign_rect, neon, false, 1.0)
		var font := ThemeDB.fallback_font
		var base := Vector2(sign_rect.position.x, sign_rect.position.y + 11.0)
		draw_string_outline(font, base, "BAARI", HORIZONTAL_ALIGNMENT_CENTER,
			sign_rect.size.x, 11, 3, Color(NEON.r, NEON.g, NEON.b, 0.25 * flick))
		draw_string(font, base, "BAARI", HORIZONTAL_ALIGNMENT_CENTER, sign_rect.size.x, 11, neon)

		# Pulssaava merkki oven edessä
		var pulse := 0.5 + 0.5 * sin(_t * 4.0)
		var rad := 9.0 + 2.0 * pulse
		draw_circle(door_front, rad, Color(NEON.r, NEON.g, NEON.b, 0.15 + 0.2 * pulse))
		draw_arc(door_front, rad, 0.0, TAU, 24, Color(NEON.r, NEON.g, NEON.b, 0.9), 1.0)
		# Pomppiva nuoli oveen päin
		var bob := absf(sin(_t * 3.0)) * 3.0
		var tip := door_front + Vector2(0.0, 24.0 - bob)
		draw_colored_polygon(PackedVector2Array([
			tip + Vector2(0.0, -8.0), tip + Vector2(-5.0, 0.0), tip + Vector2(5.0, 0.0)]), NEON)

	## Koskenkorva-pullo ylhäältä päin: kirkas runko, sininen korkki ja valkoinen etiketti.
	func _bottle(c: Vector2) -> void:
		var glass := Color(0.85, 0.93, 1.0)
		draw_rect(Rect2(c.x - 8.0, c.y - 5.0, 16.0, 22.0), Color(0, 0, 0, 0.55))   # varjo/ääriviiva
		draw_rect(Rect2(c.x - 7.0, c.y - 4.0, 14.0, 20.0), glass)
		draw_colored_polygon(PackedVector2Array([
			Vector2(c.x - 7.0, c.y - 4.0), Vector2(c.x + 7.0, c.y - 4.0),
			Vector2(c.x + 2.5, c.y - 10.0), Vector2(c.x - 2.5, c.y - 10.0)]), glass)
		draw_rect(Rect2(c.x - 2.5, c.y - 18.0, 5.0, 8.0), glass)
		draw_rect(Rect2(c.x - 3.0, c.y - 21.0, 6.0, 4.0), KK_BLUE)
		draw_rect(Rect2(c.x - 7.0, c.y + 1.0, 14.0, 11.0), Color.WHITE)
		draw_rect(Rect2(c.x - 7.0, c.y + 3.0, 14.0, 3.5), KK_BLUE)

	func _stripe_border(r: Rect2, th: float) -> void:
		var step := 4.0
		var n := int(r.size.x / step)
		for i in n:
			var col := Color.WHITE if i % 2 == 0 else KK_BLUE
			draw_rect(Rect2(r.position.x + i * step, r.position.y, step, th), col)
			draw_rect(Rect2(r.position.x + i * step, r.end.y - th, step, th), col)
		var m := int(r.size.y / step)
		for j in m:
			var col2 := Color.WHITE if j % 2 == 0 else KK_BLUE
			draw_rect(Rect2(r.position.x, r.position.y + j * step, th, step), col2)
			draw_rect(Rect2(r.end.x - th, r.position.y + j * step, th, step), col2)


## Sisätilan piirto: lattia, pullohylly, tiski, baarimikko, jakkarat, pöydät, jukeboksi.
class InteriorView extends Node2D:
	const TILE := 16
	const ROOM_W := 22
	const ROOM_H := 13
	const NEON := Color(1.0, 0.25, 0.7)
	const KK_BLUE := Color(0.13, 0.4, 0.85)
	const WOOD := Color(0.45, 0.27, 0.14)
	const WOOD_DARK := Color(0.25, 0.14, 0.08)
	const BARTENDER := Vector2(176.0, 62.0)   # baarimikon jalkojen kohta
	const SERVE_SPOT := Rect2(120.0, 80.0, 112.0, 26.0)   # sama kuin ulkoluokassa
	const POOL_TABLE := Rect2(120.0, 124.0, 64.0, 30.0)

	var price := 0
	var menu: Array = []
	var music_on := false
	var exit_pos := Vector2.ZERO
	var _kind := 1          # 0 = olut, 1 = kossu, 2 = shotti

	var _t := 0.0
	var _pour_t := 0.0     # kaatoanimaatio (sekuntia jäljellä)
	var _glass_t := 0.0    # ryyppylasi tiskillä (sekuntia jäljellä)
	var _say_t := 0.0
	var _say_text := ""

	const POUR_TIME := 0.6
	const GLASS_TIME := 1.3

	## Baarimikon puhekupla
	func say(text: String, seconds: float) -> void:
		_say_text = text
		_say_t = seconds

	## Kaadetaan juoma tiskille. kind = DRINKS-listan rivi.
	func pour(kind: int = 1) -> void:
		_kind = kind
		_pour_t = POUR_TIME
		_glass_t = GLASS_TIME

	## Lasin paikka tiskillä (huoneen paikalliset koordinaatit)
	func glass_point() -> Vector2:
		return Vector2(BARTENDER.x - 12.0, 70.0)

	func _process(delta: float) -> void:
		_t += delta
		_pour_t = maxf(_pour_t - delta, 0.0)
		_glass_t = maxf(_glass_t - delta, 0.0)
		_say_t = maxf(_say_t - delta, 0.0)
		queue_redraw()

	func _draw() -> void:
		var font := ThemeDB.fallback_font
		_draw_floor()
		_draw_back_wall(font)
		_draw_counter()
		_draw_bartender(font)
		_draw_furniture()
		_draw_games(font)
		_draw_light_pools()
		draw_string(font, Vector2(exit_pos.x - 30.0, exit_pos.y - 20.0), "ULOS",
			HORIZONTAL_ALIGNMENT_CENTER, 60.0, 8, Color(1, 1, 1, 0.8))

	# --- lattia ---
	func _draw_floor() -> void:
		var fr := Rect2(TILE, 2 * TILE, (ROOM_W - 2) * TILE, (ROOM_H - 3) * TILE)
		draw_rect(fr, Color(0.30, 0.18, 0.11))
		var y := fr.position.y
		var row := 0
		while y < fr.end.y:
			draw_line(Vector2(fr.position.x, y), Vector2(fr.end.x, y), Color(0, 0, 0, 0.22), 1.0)
			var x := fr.position.x + float((row * 37) % 48)
			while x < fr.end.x:
				draw_line(Vector2(x, y), Vector2(x, y + 8.0), Color(0, 0, 0, 0.16), 1.0)
				x += 48.0
			y += 8.0
			row += 1
		# Henkilökunnan matto tiskin takana
		draw_rect(Rect2(fr.position.x, fr.position.y, fr.size.x, 2 * TILE), Color(0.10, 0.10, 0.13))

	# --- takaseinä: pullohylly, listataulu, neon ---
	func _draw_back_wall(font: Font) -> void:
		# Hyllylaudat ja pullot (ylärivi kokonaan Koskenkorvaa, alarivillä muutama muu pullo)
		for i in 17:
			_shelf_bottle(Vector2(100.0 + i * 9.0, 27.0), (i % 4) + 1 if i % 3 == 1 else 0)
		for i in 17:
			_shelf_bottle(Vector2(100.0 + i * 9.0, 13.0), 0)
		draw_rect(Rect2(92.0, 13.0, 168.0, 2.0), WOOD_DARK)
		draw_rect(Rect2(92.0, 27.0, 168.0, 2.0), WOOD_DARK)
		draw_rect(Rect2(90.0, 3.0, 2.0, 26.0), WOOD_DARK)
		draw_rect(Rect2(260.0, 3.0, 2.0, 26.0), WOOD_DARK)

		# Listataulu
		var board := Rect2(22.0, 4.0, 62.0, 24.0)
		draw_rect(board, Color(0.07, 0.12, 0.11))
		draw_rect(board, WOOD, false, 2.0)
		if menu.is_empty():
			draw_string(font, Vector2(board.position.x, board.position.y + 10.0), "KOSKENKORVA",
				HORIZONTAL_ALIGNMENT_CENTER, board.size.x, 7, Color(0.85, 0.93, 1.0))
			draw_string(font, Vector2(board.position.x, board.position.y + 20.0), "4 cl  %d $" % price,
				HORIZONTAL_ALIGNMENT_CENTER, board.size.x, 8, Color(1.0, 0.85, 0.3))
		else:
			for i in menu.size():
				var d: Dictionary = menu[i]
				var ly := board.position.y + 8.0 + i * 7.0
				draw_string(font, Vector2(board.position.x + 3.0, ly), str(d.name).to_upper(),
					HORIZONTAL_ALIGNMENT_LEFT, -1, 6, Color(0.85, 0.93, 1.0))
				draw_string(font, Vector2(board.position.x, ly), "%d $" % int(d.price),
					HORIZONTAL_ALIGNMENT_RIGHT, board.size.x - 3.0, 6, Color(1.0, 0.85, 0.3))

		# Neon
		var flick := 0.8 + 0.2 * sin(_t * 4.3)
		var neon := Color(NEON.r, NEON.g, NEON.b, flick)
		var sign_r := Rect2(272.0, 5.0, 58.0, 22.0)
		draw_rect(sign_r, Color(0.04, 0.03, 0.09))
		draw_rect(sign_r, neon, false, 1.0)
		var base := Vector2(sign_r.position.x, sign_r.position.y + 15.0)
		draw_string_outline(font, base, "BAARI", HORIZONTAL_ALIGNMENT_CENTER,
			sign_r.size.x, 12, 3, Color(NEON.r, NEON.g, NEON.b, 0.25 * flick))
		draw_string(font, base, "BAARI", HORIZONTAL_ALIGNMENT_CENTER, sign_r.size.x, 12, neon)

	## kind 0 = Koskenkorva, 1-4 = muut pullot. p = pullon pohjan keskikohta.
	func _shelf_bottle(p: Vector2, kind: int) -> void:
		if kind == 0:
			var glass := Color(0.85, 0.93, 1.0)
			draw_rect(Rect2(p.x - 3.0, p.y - 8.0, 6.0, 8.0), glass)
			draw_rect(Rect2(p.x - 1.0, p.y - 11.0, 2.0, 3.0), glass)
			draw_rect(Rect2(p.x - 1.5, p.y - 12.0, 3.0, 1.5), KK_BLUE)
			draw_rect(Rect2(p.x - 3.0, p.y - 6.0, 6.0, 4.5), Color.WHITE)
			draw_rect(Rect2(p.x - 3.0, p.y - 5.0, 6.0, 1.5), KK_BLUE)
		else:
			var cols := [Color(0.55, 0.32, 0.1), Color(0.2, 0.5, 0.3), Color(0.5, 0.12, 0.15), Color(0.3, 0.3, 0.4)]
			var c: Color = cols[(kind - 1) % cols.size()]
			draw_rect(Rect2(p.x - 3.0, p.y - 8.0, 6.0, 8.0), c)
			draw_rect(Rect2(p.x - 1.0, p.y - 11.0, 2.0, 3.0), c)
			draw_rect(Rect2(p.x - 1.5, p.y - 12.0, 3.0, 1.5), Color(0.1, 0.1, 0.1))
			draw_rect(Rect2(p.x - 3.0, p.y - 5.0, 6.0, 2.5), Color(0.9, 0.85, 0.7))

	# --- tiski ---
	func _draw_counter() -> void:
		var top := Rect2(TILE, 62.0, (ROOM_W - 2) * TILE, 16.0)
		draw_rect(top, WOOD)
		draw_line(Vector2(top.position.x, top.position.y + 1.0), Vector2(top.end.x, top.position.y + 1.0),
			Color(0.65, 0.42, 0.24), 2.0)
		# Etupaneeli + messinkinen jalkatuki
		draw_rect(Rect2(top.position.x, top.end.y, top.size.x, 8.0), WOOD_DARK)
		draw_line(Vector2(top.position.x, top.end.y + 5.0), Vector2(top.end.x, top.end.y + 5.0),
			Color(0.85, 0.7, 0.3, 0.8), 1.0)
		# Kassakone oikealla
		draw_rect(Rect2(292.0, 54.0, 16.0, 12.0), Color(0.3, 0.32, 0.36))
		draw_rect(Rect2(294.0, 56.0, 12.0, 4.0), Color(0.3, 0.9, 0.5))
		# Muutama lasi tiskillä
		for gx in [40.0, 52.0, 232.0, 250.0]:
			draw_rect(Rect2(gx, 66.0, 4.0, 5.0), Color(0.85, 0.92, 1.0, 0.55))
		# Hintalaput tiskin etupaneelissa jokaisen tilauspaikan kohdalla
		if not menu.is_empty():
			var font := ThemeDB.fallback_font
			var slot_w := SERVE_SPOT.size.x / menu.size()
			for i in menu.size():
				var d: Dictionary = menu[i]
				var x0 := SERVE_SPOT.position.x + slot_w * i
				draw_rect(Rect2(x0 + 3.0, 79.0, slot_w - 6.0, 6.0), Color(0.07, 0.12, 0.11))
				draw_string(font, Vector2(x0, 84.5), "%s %d$" % [str(d.name).to_upper(), int(d.price)],
					HORIZONTAL_ALIGNMENT_CENTER, slot_w, 5, Color(1.0, 0.85, 0.3))

	# --- baarimikko ---
	func _draw_bartender(font: Font) -> void:
		var bx := BARTENDER.x
		# Vartalo: valkoinen paita + musta liivi + rusetti
		draw_rect(Rect2(bx - 6.0, 46.0, 12.0, 14.0), Color.WHITE)
		draw_rect(Rect2(bx - 6.0, 46.0, 3.0, 14.0), Color(0.1, 0.1, 0.12))
		draw_rect(Rect2(bx + 3.0, 46.0, 3.0, 14.0), Color(0.1, 0.1, 0.12))
		draw_rect(Rect2(bx - 2.0, 46.5, 4.0, 2.0), Color(0.8, 0.12, 0.15))
		# Kädet tiskillä
		draw_rect(Rect2(bx - 9.0, 52.0, 3.0, 9.0), Color(0.95, 0.78, 0.62))
		draw_rect(Rect2(bx + 6.0, 52.0, 3.0, 9.0), Color(0.95, 0.78, 0.62))
		# Pää
		draw_circle(Vector2(bx, 41.0), 5.0, Color(0.95, 0.78, 0.62))
		draw_rect(Rect2(bx - 5.0, 35.5, 10.0, 3.0), Color(0.25, 0.15, 0.08))
		draw_rect(Rect2(bx - 2.5, 41.0, 1.2, 1.2), Color(0.1, 0.1, 0.1))
		draw_rect(Rect2(bx + 1.5, 41.0, 1.2, 1.2), Color(0.1, 0.1, 0.1))
		draw_line(Vector2(bx - 1.5, 44.0), Vector2(bx + 1.5, 44.0), Color(0.5, 0.2, 0.2), 1.0)

		# Kaato: pullo kallistuu lasin päälle
		var glass_pos := Vector2(bx - 12.0, 70.0)
		if _pour_t > 0.0:
			var prog := 1.0 - _pour_t / POUR_TIME
			var ang := sin(PI * prog) * 1.1
			draw_set_transform(Vector2(bx + 13.0, 56.0), -ang, Vector2.ONE)
			_shelf_bottle(Vector2.ZERO, 0)
			draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
			if prog > 0.25 and prog < 0.8:
				draw_line(Vector2(bx + 6.0, 50.0), glass_pos + Vector2(0.0, -2.0), Color(0.85, 0.95, 1.0, 0.8), 1.0)
		# Lasi tiskillä: täyttyy, sitten tyhjenee kun pelaaja kumoaa sen
		if _glass_t > 0.0:
			var full := _glass_t > 0.45
			match _kind:
				0:   # olut: korkea tuoppi, kullankeltainen + vaahto
					var g := Rect2(glass_pos.x - 3.0, glass_pos.y - 8.0, 6.0, 11.0)
					draw_rect(g, Color(0.85, 0.92, 1.0, 0.35))
					if full:
						draw_rect(Rect2(g.position.x + 0.5, g.position.y + 3.0, 5.0, 7.5), Color(0.95, 0.68, 0.15, 0.95))
						draw_rect(Rect2(g.position.x + 0.5, g.position.y + 1.0, 5.0, 2.5), Color(1.0, 0.98, 0.9))
					draw_rect(g, Color(1, 1, 1, 0.7), false, 1.0)
				2:   # shotti: pieni lasi, tumma salmiakki
					var g := Rect2(glass_pos.x - 2.0, glass_pos.y - 1.0, 4.0, 4.0)
					draw_rect(g, Color(0.85, 0.92, 1.0, 0.45))
					if full:
						draw_rect(Rect2(g.position.x + 0.5, g.position.y + 1.0, 3.0, 2.5), Color(0.12, 0.06, 0.08, 0.95))
					draw_rect(g, Color(1, 1, 1, 0.7), false, 1.0)
				_:   # kossu
					draw_rect(Rect2(glass_pos.x - 2.5, glass_pos.y - 3.0, 5.0, 6.0), Color(0.85, 0.92, 1.0, 0.45))
					if full:
						draw_rect(Rect2(glass_pos.x - 2.0, glass_pos.y - 0.5, 4.0, 3.0), Color(0.95, 0.98, 1.0, 0.9))
					draw_rect(Rect2(glass_pos.x - 2.5, glass_pos.y - 3.0, 5.0, 6.0), Color(1, 1, 1, 0.7), false, 1.0)

		# Puhekupla
		if _say_t > 0.0 and _say_text != "":
			var fs := 8
			var w := font.get_string_size(_say_text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x + 10.0
			var box := Rect2(bx - w * 0.5, 14.0, w, 14.0)
			draw_rect(box, Color(1, 1, 1, 0.95))
			draw_rect(box, Color(0, 0, 0, 0.9), false, 1.0)
			draw_colored_polygon(PackedVector2Array([
				Vector2(bx - 3.0, box.end.y), Vector2(bx + 3.0, box.end.y), Vector2(bx, box.end.y + 5.0)]),
				Color(1, 1, 1, 0.95))
			draw_string(font, Vector2(box.position.x + 5.0, box.position.y + 10.0), _say_text,
				HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color.BLACK)

	# --- jakkarat, pöydät, jukeboksi ---
	func _draw_furniture() -> void:
		# Tiskin jakkarat
		for sx in [40.0, 72.0, 104.0, 248.0, 280.0, 312.0]:
			_stool(Vector2(sx, 94.0))
		# Pöydät jakkaroineen
		for tx in [64.0, 288.0]:
			var tc := Vector2(tx, 150.0)
			_stool(tc + Vector2(-17.0, 0.0))
			_stool(tc + Vector2(17.0, 0.0))
			draw_circle(tc, 11.0, WOOD_DARK)
			draw_circle(tc, 10.0, WOOD)
			draw_circle(tc + Vector2(2.0, -1.0), 2.0, Color(0.85, 0.92, 1.0, 0.7))
		# Jukeboksi oikealla seinällä
		var jb := Rect2(304.0, 104.0, 24.0, 22.0)
		draw_rect(jb, Color(0.14, 0.1, 0.2))
		draw_rect(jb, Color(0.2, 0.9, 1.0, 0.9), false, 1.0)
		for i in 4:
			var h := 3.0 + 6.0 * (0.5 + 0.5 * sin(_t * (5.0 + i * 1.7) + i))
			if not music_on:
				h = 2.0
			draw_rect(Rect2(jb.position.x + 3.0 + i * 5.0, jb.position.y + 16.0 - h, 3.0, h),
				Color(1.0, 0.3, 0.7) if i % 2 == 0 else Color(0.3, 0.9, 1.0))

	## Biljardipöytä, tikkataulu, korttipakka ja portsari.
	func _draw_games(font: Font) -> void:
		var pt := POOL_TABLE
		draw_rect(pt.grow(1.0), Color(0.12, 0.06, 0.03))
		draw_rect(pt, WOOD_DARK)
		draw_rect(pt.grow(-3.0), Color(0.1, 0.45, 0.22))
		for corner in [pt.position + Vector2(3, 3), Vector2(pt.end.x - 3, pt.position.y + 3),
				Vector2(pt.position.x + 3, pt.end.y - 3), pt.end - Vector2(3, 3),
				Vector2(pt.get_center().x, pt.position.y + 3), Vector2(pt.get_center().x, pt.end.y - 3)]:
			draw_circle(corner, 2.0, Color(0.03, 0.03, 0.03))
		var balls := [Color(0.95, 0.85, 0.2), Color(0.8, 0.15, 0.15), Color(0.15, 0.3, 0.8), Color(0.1, 0.1, 0.1), Color(0.95, 0.5, 0.1)]
		for i in balls.size():
			draw_circle(pt.position + Vector2(36.0 + (i % 3) * 3.5, 11.0 + float(i / 3) * 4.0 + (i % 3) * 1.5), 1.6, balls[i])
		draw_circle(pt.position + Vector2(14.0, 15.0), 1.6, Color.WHITE)
		# Tikkataulu vasemmalla seinällä
		var dc := Vector2(9.0, 102.0)
		draw_circle(dc, 7.0, Color(0.1, 0.1, 0.1))
		draw_circle(dc, 6.0, Color(0.9, 0.85, 0.7))
		draw_circle(dc, 4.0, Color(0.15, 0.5, 0.25))
		draw_circle(dc, 2.2, Color(0.8, 0.15, 0.15))
		draw_circle(dc, 0.9, Color(0.1, 0.1, 0.1))
		# Korttipakka oikealla pöydällä
		var tc := Vector2(288.0, 150.0)
		draw_rect(Rect2(tc + Vector2(-6, -3), Vector2(5, 7)), Color.WHITE)
		draw_rect(Rect2(tc + Vector2(1, -3), Vector2(5, 7)), Color(0.85, 0.15, 0.2))
		# Portsari oven vieressä
		var bx := 206.0
		draw_rect(Rect2(bx - 6.0, 172.0, 12.0, 16.0), Color(0.08, 0.08, 0.1))
		draw_circle(Vector2(bx, 167.0), 5.0, Color(0.85, 0.68, 0.55))
		draw_rect(Rect2(bx - 4.0, 166.0, 8.0, 1.5), Color(0.05, 0.05, 0.05))
		draw_string(font, Vector2(bx - 20.0, 194.0), "PORTSARI", HORIZONTAL_ALIGNMENT_CENTER, 40.0, 5, Color(1, 1, 1, 0.6))

	func _stool(c: Vector2) -> void:
		draw_circle(c, 5.5, Color(0.1, 0.05, 0.05, 0.5))
		draw_circle(c, 5.0, Color(0.62, 0.1, 0.14))
		draw_arc(c, 5.0, 0.0, TAU, 14, Color(0.3, 0.04, 0.06), 1.0)

	# --- lämpimät valokiilat lattialla ---
	func _draw_light_pools() -> void:
		for lx in [96.0, 176.0, 256.0]:
			var c := Vector2(lx, 110.0)
			draw_circle(c, 56.0, Color(1.0, 0.8, 0.4, 0.035))
			draw_circle(c, 40.0, Color(1.0, 0.8, 0.4, 0.04))
			draw_circle(c, 24.0, Color(1.0, 0.85, 0.5, 0.05))
