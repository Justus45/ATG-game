extends Node2D
## Kaupungin palvelurakennus (ei sisätilaa): katto + kyltti ja E-kohde oven edessä.
## Ovella aukeaa valikko (HUD.show_menu). Aukioloajat tulevat Game-kellosta.
##
## Lajit (kind):
##   hospital  SAIRAALA         hoito, kipulääke; hävityn tappelun jälkeen herätään täältä
##   bank      PANKKI           talletus / nosto (pankin rahat säilyvät sammuessa ja putkassa)
##   shop      KAUPPA           ruokaa jääkaappiin, energiajuoma, kynä, veitsi
##   realtor   KIINTEISTÖT      päätavoite: osta oma baari
##   bus       LINJA-AUTOASEMA  toinen loppu: lippu pois kaupungista
##
## CityGenerator luo nämä (_make_service) ja kutsuu setup():ia.

const TILE := 16

const KINDS := {
	"hospital": {"name": "Sairaala", "title": "SAIRAALA", "roof": Color(0.88, 0.9, 0.92), "accent": Color(0.85, 0.15, 0.18), "text": Color(0.85, 0.15, 0.18), "open": [0, 0], "letter": "+"},
	"bank": {"name": "Pankki", "title": "PANKKI", "roof": Color(0.16, 0.24, 0.36), "accent": Color(0.95, 0.78, 0.3), "text": Color(0.95, 0.85, 0.45), "open": [9, 17], "letter": "$"},
	"shop": {"name": "Kauppa", "title": "KAUPPA", "roof": Color(0.2, 0.45, 0.25), "accent": Color(0.98, 0.6, 0.15), "text": Color(1.0, 0.95, 0.85), "open": [7, 23], "letter": "K"},
	"realtor": {"name": "Kiinteistövälitys", "title": "KIINTEISTÖT", "roof": Color(0.5, 0.42, 0.55), "accent": Color(0.95, 0.95, 0.95), "text": Color(1.0, 1.0, 1.0), "open": [9, 18], "letter": "M"},
	"bus": {"name": "Linja-autoasema", "title": "LINJA-AUTOASEMA", "roof": Color(0.22, 0.3, 0.5), "accent": Color(1.0, 0.85, 0.2), "text": Color(1.0, 0.9, 0.4), "open": [0, 0], "letter": "B"},
}

const HOSPITAL_BILL := 60
const HEAL_PRICE := 25

var kind := "shop"
var door_px := Vector2.ZERO
var roof := Rect2()
var map_color := Color.WHITE
var letter := "?"
var title := ""
var _info: Dictionary = {}


func setup(p_kind: String, p_roof: Rect2, door_center: Vector2) -> void:
	kind = p_kind
	_info = KINDS.get(kind, KINDS["shop"])
	title = str(_info.title)
	map_color = _info.accent
	letter = str(_info.letter)
	add_to_group("service")
	add_to_group(kind)
	global_position = Vector2.ZERO
	door_px = door_center
	roof = p_roof
	var ext := ExteriorView.new()
	ext.roof = p_roof
	ext.info = _info
	ext.kind = kind
	ext.door_front = door_center + Vector2(0.0, TILE)
	ext.z_index = 50
	add_child(ext)
	InteractSpot.create(self, door_center + Vector2(0.0, 17.0), Vector2(24.0, 22.0), _prompt, _use)


func is_open() -> bool:
	var o: Array = _info.open
	return Game.is_open(int(o[0]), int(o[1]))


func hours_text() -> String:
	var o: Array = _info.open
	if int(o[0]) == int(o[1]):
		return "auki aina"
	return "auki %02d–%02d" % [int(o[0]), int(o[1])]


func _prompt() -> String:
	if not is_open():
		return "%s – suljettu (%s)" % [display_name(), hours_text()]
	return "Paina E: %s (%s)" % [display_name(), hours_text()]


func _hud() -> Node:
	return get_tree().current_scene.get_node_or_null("Hud")


func _jobs() -> Node:
	return get_tree().get_first_node_in_group("job_manager")


func _menu(t: String, options: Array, cb: Callable) -> void:
	var hud := _hud()
	if hud and hud.has_method("show_menu"):
		hud.show_menu(t, options, cb)


func _use(player: Node2D) -> void:
	if not is_open():
		Sfx.play_ui("denied", -6.0)
		Game.msg("%s on kiinni (%s)." % [display_name(), hours_text()], 2.0)
		return
	match kind:
		"hospital":
			_menu("SAIRAALA\nElämät %d / %d" % [int(player.hp), int(player.get_max_hp())],
				["Hoida haavat (%d $)" % HEAL_PRICE, "Kipulääke krapulaan (10 $)"], _hospital_choice.bind(player))
		"bank":
			_bank_menu(player)
		"shop":
			_menu("KAUPPA – jääkaapissa %d annosta, nälkä %d %%" % [Game.fridge, int(Game.hunger)],
				["Einesateria jääkaappiin (6 $)", "Ruokakassi, 3 annosta (15 $)", "Makkara heti (4 $, nälkä -30)",
				 "Energiajuoma (3 $, väsymys -20)", "Kuulakärkikynä (1 $)", "Keittiöveitsi (20 $)"],
				_shop_choice.bind(player))
		"realtor":
			if Game.owns_bar:
				Game.msg("Välittäjä: \"Baari on jo sinun! Onnea yrittäjälle.\"", 3.0)
				return
			_menu("KIINTEISTÖT\nKaupungin baari myytävänä: %d $\nRahaa yhteensä %d $" % [Game.BAR_PRICE, player.money + Game.bank],
				["Osta baari (%d $)" % Game.BAR_PRICE], _realtor_choice)
		"bus":
			_menu("LINJA-AUTOASEMA\nYöbussi pois kaupungista: %d $" % Game.TICKET_PRICE,
				["Osta lippu ja lähde (%d $)" % Game.TICKET_PRICE], _bus_choice)


func display_name() -> String:
	return str(_info.get("name", title))


## Maksaa hinnan lompakosta. Palauttaa true jos rahat riittivät.
func _pay(player: Node2D, price: int) -> bool:
	if player.money < price:
		Sfx.play_ui("denied", -6.0)
		Game.msg("Ei tarpeeksi rahaa (%d $ / %d $)." % [player.money, price], 2.0)
		return false
	player.add_money(-price)
	return true


func _realtor_choice(i: int) -> void:
	if i == 0 and not Game.buy_bar():
		Sfx.play_ui("denied", -4.0)
		Game.msg("Välittäjä: \"Tule takaisin, kun sinulla on %d $.\"" % Game.BAR_PRICE, 3.0)


func _bus_choice(i: int) -> void:
	if i == 0 and not Game.buy_ticket():
		Sfx.play_ui("denied", -4.0)
		Game.msg("Lipunmyyjä: \"Lippu maksaa %d $.\"" % Game.TICKET_PRICE, 3.0)


func _hospital_choice(i: int, player: Node2D) -> void:
	if i == 0 and _pay(player, HEAL_PRICE):
		player.hp = player.get_max_hp()
		player._refresh_health_hud()
		Game.msg("Haavat hoidettu. Elämät täynnä.", 2.0)
	elif i == 1 and _pay(player, 10):
		player.hangover = 0.0
		player._refresh_drunk_hud(true)
		Game.msg("Kipulääke vei krapulan.", 2.0)


func _shop_choice(i: int, player: Node2D) -> void:
	match i:
		0:
			if _pay(player, 6):
				Game.fridge += 1
				Game.msg("Einesateria jääkaappiin.", 2.0)
		1:
			if _pay(player, 15):
				Game.fridge += 3
				Game.msg("Ruokakassi: 3 annosta jääkaappiin.", 2.0)
		2:
			if _pay(player, 4):
				Game.hunger = maxf(Game.hunger - 30.0, 0.0)
				Game.msg("Makkara meni hyvin.", 2.0)
		3:
			if _pay(player, 3):
				Game.fatigue = maxf(Game.fatigue - 20.0, 0.0)
				Game.msg("Energiajuoma piristää.", 2.0)
		4:
			_buy_weapon(player, "pen", 1)
		5:
			_buy_weapon(player, "knife", 20)


func _buy_weapon(player: Node2D, id: String, price: int) -> void:
	if player.has_weapon():
		Game.msg("Pudota ensin kädessä oleva ase (G).", 2.0)
		return
	if _pay(player, price):
		player.held_weapon.equip(id, "down")
		Game.msg("%s kädessä. Lyö välilyönnillä / hiirellä." % WeaponDB.display_name(id), 2.5)


# ----------------------------------------------------------------------------
#  PANKKI
# ----------------------------------------------------------------------------
func _bank_menu(player: Node2D) -> void:
	_menu("PANKKI\nLompakko %d $   Tili %d $\nPankin rahat eivät katoa sammuessa tai putkassa." % [player.money, Game.bank],
		["Talleta kaikki", "Talleta 100 $", "Nosta 100 $", "Nosta 500 $", "Nosta kaikki"],
		func(i: int) -> void: _bank_choice(player, i))


func _bank_choice(player: Node2D, i: int) -> void:
	var amount := 0
	match i:
		0:
			amount = player.money
		1:
			amount = mini(100, player.money)
		2:
			amount = -mini(100, Game.bank)
		3:
			amount = -mini(500, Game.bank)
		4:
			amount = -Game.bank
		_:
			return
	if amount == 0:
		Sfx.play_ui("denied", -6.0)
		Game.msg("Ei siirrettävää.", 1.5)
		return
	player.add_money(-amount)
	Game.bank += amount
	Sfx.play_ui("cash", -4.0)
	Game.msg("%s %d $. Tilillä nyt %d $." % ["Talletit" if amount > 0 else "Nostit", absi(amount), Game.bank], 2.5)
	_bank_menu(player)


# ----------------------------------------------------------------------------
#  SAIRAALA: pelaaja herää täältä hävityn tappelun jälkeen
# ----------------------------------------------------------------------------
## Siirtää pelaajan sairaalan ovelle ja perii laskun (lompakko, sitten pankki).
func admit(player: Node2D) -> int:
	for car in get_tree().get_nodes_in_group("player_vehicles"):
		if "is_driving" in car and car.is_driving:
			car.exit_car()
	var col := player.get_node_or_null("CollisionShape2D") as Node2D
	var off := col.position if col else Vector2.ZERO
	player.global_position = door_px + Vector2(0.0, 28.0) - off
	var cam := get_viewport().get_camera_2d()
	if cam:
		cam.global_position = door_px + Vector2(0.0, 28.0)
	var bill := HOSPITAL_BILL
	var from_wallet := mini(player.money, bill)
	player.add_money(-from_wallet)
	var rest := bill - from_wallet
	var from_bank := mini(Game.bank, rest)
	Game.bank -= from_bank
	Game.skip_minutes(180.0)
	return from_wallet + from_bank


## Katto, kyltti ja tunnus.
class ExteriorView extends Node2D:
	var roof := Rect2()
	var info: Dictionary = {}
	var kind := ""
	var door_front := Vector2.ZERO
	var _t := 0.0

	func _process(delta: float) -> void:
		_t += delta
		if int(_t * 4.0) != int((_t - delta) * 4.0):
			queue_redraw()

	func _draw() -> void:
		var font := ThemeDB.fallback_font
		var base: Color = info.get("roof", Color.GRAY)
		var accent: Color = info.get("accent", Color.WHITE)
		var text_c: Color = info.get("text", Color.WHITE)
		draw_rect(Rect2(roof.position.x, roof.end.y, roof.size.x, 3.0), Color(0, 0, 0, 0.28))
		draw_rect(roof, base)
		# saumat
		var x := roof.position.x + 16.0
		while x < roof.end.x:
			draw_line(Vector2(x, roof.position.y), Vector2(x, roof.end.y), Color(0, 0, 0, 0.08), 1.0)
			x += 16.0
		draw_rect(roof, accent, false, 2.0)
		draw_rect(roof.grow(-4.0), Color(accent, 0.35), false, 1.0)

		# tunnus katon keskellä
		var c := roof.get_center() + Vector2(0.0, -8.0)
		match kind:
			"hospital":
				draw_rect(Rect2(c - Vector2(9, 3), Vector2(18, 6)), accent)
				draw_rect(Rect2(c - Vector2(3, 9), Vector2(6, 18)), accent)
			"bank":
				draw_circle(c, 9.0, accent)
				draw_string(font, c + Vector2(-5, 5), "$", HORIZONTAL_ALIGNMENT_CENTER, 10, 14, base)
			"realtor":
				var blink := 0.6 + 0.4 * sin(_t * 3.0)
				draw_rect(Rect2(c - Vector2(16, 6), Vector2(32, 12)), Color(0.85, 0.15, 0.15, blink))
				draw_string(font, c + Vector2(-16, 4), "MYYNNISSÄ", HORIZONTAL_ALIGNMENT_CENTER, 32, 6, Color.WHITE)
			"bus":
				draw_rect(Rect2(c - Vector2(14, 6), Vector2(28, 12)), accent)
				draw_rect(Rect2(c - Vector2(12, 4), Vector2(24, 4)), Color(0.4, 0.6, 0.9))
				draw_circle(c + Vector2(-8, 6), 2.5, Color(0.1, 0.1, 0.1))
				draw_circle(c + Vector2(8, 6), 2.5, Color(0.1, 0.1, 0.1))
			_:
				draw_rect(Rect2(c - Vector2(12, 4), Vector2(24, 8)), accent)

		# kyltti
		var sign_r := Rect2(roof.position.x + 6.0, roof.end.y - 17.0, roof.size.x - 12.0, 13.0)
		draw_rect(sign_r, Color(0.05, 0.05, 0.08, 0.9))
		draw_rect(sign_r, accent, false, 1.0)
		var t: String = info.get("title", "")
		var fs := 9 if t.length() <= 10 else 7
		draw_string(font, Vector2(sign_r.position.x, sign_r.position.y + 10.0), t,
			HORIZONTAL_ALIGNMENT_CENTER, sign_r.size.x, fs, text_c)

		# ovimatto
		draw_rect(Rect2(door_front.x - 10.0, door_front.y - 6.0, 20.0, 9.0), Color(accent, 0.6))
