extends Node2D
## TORI: avoin kiveys kahdella kojulla.
##  - Mopo-Make myy mopon (Car2D.make_moped). Ostettu mopo pysäköidään kojun viereen.
##  - Vaate-Vuokko myy paitoja ja housuja (Game.SHIRTS / Game.PANTS), jotka näkyvät
##    pelaajan ulkoasussa (CharSprites.outfit_frames). Ostetut vaatteet voi vaihtaa ilmaiseksi.
## CityGenerator luo tämän palvelukortteliin (SERVICE_ORDER "market") ja kutsuu setup():ia.

const CS := preload("res://scripts/core/CharSprites.gd")
const CAR_SCENE: PackedScene = preload("res://scenes/entities/vehicles/car.tscn")
const CAR_SCRIPT := preload("res://scripts/entities/Car2D.gd")
const TILE := 16.0
const OPEN := 8
const CLOSE := 20

var kind := "market"
var door_px := Vector2.ZERO          ## minikartan merkki (aukion keskellä)
var map_color := Color(0.98, 0.55, 0.15)
var letter := "T"
var area := Rect2()
var stall_cells: Array[Rect2i] = []  ## CityGenerator merkitsee nämä ruudut esteiksi
var moped_spot := Vector2.ZERO
var car_spot := Vector2.ZERO          ## superauton (Furia V12) näyttelypaikka
var _moped_stall: Node2D
var _clothes_stall: Node2D
var _display: Node2D
var _check_t := 1.0


func display_name() -> String:
	return "Tori"


func is_open() -> bool:
	return Game.is_open(OPEN, CLOSE)


func hours_text() -> String:
	return "auki %02d–%02d" % [OPEN, CLOSE]


## inner = korttelin sisäosa ruutuina, px = sama pikseleinä (maailma)
func setup(inner: Rect2i, px: Rect2) -> void:
	add_to_group("service")
	add_to_group("market")
	y_sort_enabled = true
	global_position = Vector2.ZERO
	area = px
	door_px = px.get_center()
	# kojut 3x2 ruutua: vierekkäin, kapeassa korttelissa allekkain
	var a := Rect2i(inner.position + Vector2i(1, 1), Vector2i(3, 2))
	var b := Rect2i(Vector2i(inner.end.x - 4, inner.position.y + 1), Vector2i(3, 2))
	if inner.size.x < 9:
		b = Rect2i(Vector2i(inner.end.x - 4, inner.position.y + 4), Vector2i(3, 2))
	stall_cells = [a, b]
	var ra := _cell_rect(inner, px, a)
	var rb := _cell_rect(inner, px, b)
	_moped_stall = _make_stall(ra, "moped")
	_clothes_stall = _make_stall(rb, "clothes")
	# myytävä mopo kojun vieressä (tai alla)
	if inner.size.x >= 11:
		moped_spot = Vector2(ra.end.x + 18.0, ra.end.y - 6.0)
	else:
		moped_spot = Vector2(ra.get_center().x, ra.end.y + 30.0)
	_display = MopedDisplay.new()
	_display.position = moped_spot + Vector2(0.0, 6.0)
	_display.set("market", self)
	add_child(_display)
	# superauto korokkeella: aukion alareunan keskellä (kapeassa korttelissa oikeassa yläkulmassa)
	if inner.size.x >= 9:
		car_spot = Vector2(px.get_center().x, px.end.y - 26.0)
	else:
		car_spot = Vector2(px.end.x - 40.0, px.position.y + 30.0)
	var cd := CarDisplay.new()
	cd.position = car_spot + Vector2(0.0, 8.0)
	cd.set("market", self)
	add_child(cd)
	InteractSpot.create(self, car_spot + Vector2(0.0, 20.0), Vector2(40.0, 14.0), _car_prompt, _car_menu)
	# E-kohdat kojujen edessä
	InteractSpot.create(self, Vector2(ra.get_center().x, ra.end.y + 9.0), Vector2(44.0, 16.0), _moped_prompt, _moped_menu)
	InteractSpot.create(self, Vector2(rb.get_center().x, rb.end.y + 9.0), Vector2(44.0, 16.0), _clothes_prompt, _clothes_menu)
	InteractSpot.create(self, moped_spot + Vector2(0.0, 12.0), Vector2(30.0, 14.0), _moped_prompt, _moped_menu)


func _cell_rect(inner: Rect2i, px: Rect2, c: Rect2i) -> Rect2:
	return Rect2(px.position + Vector2(c.position - inner.position) * TILE, Vector2(c.size) * TILE)


func _make_stall(r: Rect2, stall_kind: String) -> Node2D:
	var st := Stall.new()
	st.position = Vector2(r.position.x, r.end.y)
	st.set("w", r.size.x)
	st.set("h", r.size.y)
	st.set("kind", stall_kind)
	st.set("market", self)
	add_child(st)
	# kiinteä koju
	var body := StaticBody2D.new()
	var cs := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = Vector2(r.size.x, r.size.y - 4.0)
	cs.shape = shape
	body.add_child(cs)
	add_child(body)
	body.global_position = r.get_center() + Vector2(0.0, 2.0)
	return st


func _process(delta: float) -> void:
	# Tallennettu mopo palautetaan torille (autoja ei tallenneta paikkoineen)
	_check_t -= delta
	if _check_t > 0.0:
		return
	_check_t = 3.0
	if Game.owns_moped and _my_moped() == null and not _moped_restored:
		_spawn_moped(true)
		_moped_restored = true
	if Game.owns_supercar and _my_car() == null and not _car_restored:
		_spawn_car(true)
		_car_restored = true


var _moped_restored := false
var _car_restored := false


func _my_car() -> Node2D:
	for m in get_tree().get_nodes_in_group("supercar"):
		if is_instance_valid(m) and not bool(m.get("exploded")):
			return m as Node2D
	return null


func _spawn_car(restore: bool = false) -> Node2D:
	var car := CAR_SCENE.instantiate() as Node2D
	get_parent().add_child(car)
	car.global_position = _home_spot(2, car_spot) if restore else car_spot
	car.call("make_supercar")
	return car


# ----------------------------------------------------------------------------
#  SUPERAUTO (Mopo-Make tuo tilauksesta)
# ----------------------------------------------------------------------------
func _car_prompt() -> String:
	if _my_car() != null:
		return "Furia V12 – sinun superautosi"
	if not is_open():
		return "Superauto (suljettu, %s)" % hours_text()
	return "Paina E: Furia V12 -superauto – %d $" % Game.SUPERCAR_PRICE


func _car_menu(player: Node2D) -> void:
	if _my_car() != null:
		Game.msg("Make: \"Pidä se ehjänä. Ei niitä ihan joka päivä tuoda Italiasta.\"", 3.0)
		return
	if not is_open():
		Game.msg("Make on lähtenyt kotiin. Auto odottaa aamuun.", 2.5)
		return
	_menu("MOPO-MAKE – FURIA V12\n\"Italialainen superauto, V12, kolmesataa heppaa ja vähän päälle. Kiihtyy ku raketti.\"\nHinta %d $  |  Lompakko %d $  |  Tili %d $" % [
		Game.SUPERCAR_PRICE, int(player.money), Game.bank],
		["Maksa käteisellä (%d $)" % Game.SUPERCAR_PRICE, "Maksa kortilla (%d $)" % Game.SUPERCAR_PRICE, "Ehkä joskus"],
		_car_choice.bind(player))


func _car_choice(i: int, player: Node2D) -> void:
	if i == 0:
		if int(player.money) < Game.SUPERCAR_PRICE:
			Sfx.play_ui("denied", -4.0)
			Game.msg("Make: \"Käteistä pitää olla %d $, kundi.\"" % Game.SUPERCAR_PRICE, 2.5)
			return
		player.add_money(-Game.SUPERCAR_PRICE)
	elif i == 1:
		if Game.bank < Game.SUPERCAR_PRICE:
			Sfx.play_ui("denied", -4.0)
			Game.msg("Kortti ei mennyt läpi – tilillä %d $." % Game.bank, 2.5)
			return
		Game.bank -= Game.SUPERCAR_PRICE
	else:
		return
	Game.owns_supercar = true
	_car_restored = true
	Sfx.play_ui("cash", -2.0)
	_spawn_car()
	Sfx.play("engine_start", car_spot, -2.0, 0.05, 0.7)
	Game.msg("Furia V12 on sun! Make: \"Avaimet virtalukossa. Älä aja sitä puuhun.\"", 4.0)


func _hud() -> Node:
	var sc := get_tree().current_scene
	return sc.get_node_or_null("Hud") if sc else null


func _menu(title: String, opts: Array, cb: Callable) -> void:
	var hud := _hud()
	if hud and hud.has_method("show_menu"):
		hud.show_menu(title, opts, cb)


## Ehjä oma mopo kaupungissa, tai null
func _my_moped() -> Node2D:
	for m in get_tree().get_nodes_in_group("moped"):
		if is_instance_valid(m) and not bool(m.get("exploded")):
			return m as Node2D
	return null


func _spawn_moped(restore: bool = false) -> Node2D:
	var car := CAR_SCENE.instantiate() as Node2D
	get_parent().add_child(car)
	car.global_position = _home_spot(1, moped_spot) if restore else moped_spot
	car.call("make_moped")
	return car


## Kartanon omistajan kulkuneuvot palautuvat kartanon pihaan
func _home_spot(i: int, fallback: Vector2) -> Vector2:
	if Game.owns_manor:
		var manor := get_tree().get_first_node_in_group("manor")
		if manor and manor.has_method("parking_spot"):
			return manor.call("parking_spot", i)
	return fallback


# ----------------------------------------------------------------------------
#  MOPO-MAKE
# ----------------------------------------------------------------------------
func _moped_prompt() -> String:
	if not is_open():
		return "Mopo-Make on lähtenyt kotiin (%s)" % hours_text()
	if _my_moped() != null:
		return "Paina E: juttele Mopo-Maken kanssa"
	return "Paina E: Mopo-Make – mopo %d $" % Game.MOPED_PRICE


func _moped_menu(player: Node2D) -> void:
	if not is_open():
		Game.msg("Koju on kiinni. Make tulee taas aamulla kahdeksalta.", 2.5)
		return
	if _my_moped() != null:
		Game.msg(["Make: \"No, miten se mopo kulkee? Muista: ei renkaita kattoon.\"",
			"Make: \"Viiskymppinen, mut kulkee ku ohjus. Melkein.\"",
			"Make: \"Kypärä päähän, kundi. Kytät tykkää.\""][randi() % 3], 3.0)
		return
	var lost := Game.owns_moped
	_menu("MOPO-MAKE\n\"%s\"\nMopo %d $  |  Lompakko %d $  |  Tili %d $" % [
		"Edellinen meni romuks? No, mul on toinen." if lost else "Viiskymppinen skootteri, juuri huollettu. Ketterä ku kissa liikenteessä.",
		Game.MOPED_PRICE, int(player.money), Game.bank],
		["Maksa käteisellä (%d $)" % Game.MOPED_PRICE, "Maksa kortilla (%d $)" % Game.MOPED_PRICE, "Ei kiitos"],
		_moped_choice.bind(player))


func _moped_choice(i: int, player: Node2D) -> void:
	if i == 0:
		if int(player.money) < Game.MOPED_PRICE:
			Sfx.play_ui("denied", -4.0)
			Game.msg("Make: \"Hilut ei riitä, kundi. %d $ on hinta.\"" % Game.MOPED_PRICE, 2.5)
			return
		player.add_money(-Game.MOPED_PRICE)
	elif i == 1:
		if Game.bank < Game.MOPED_PRICE:
			Sfx.play_ui("denied", -4.0)
			Game.msg("Kortti ei mennyt läpi – tilillä %d $." % Game.bank, 2.5)
			return
		Game.bank -= Game.MOPED_PRICE
	else:
		return
	Game.owns_moped = true
	_moped_restored = true
	Sfx.play_ui("cash", -4.0)
	_spawn_moped()
	Sfx.play("engine_start", moped_spot, -6.0, 0.05, 1.6)
	Game.msg("Mopo on sun! Se odottaa kojun vieressä – E kyytiin. Make: \"Ei renkaita kattoon!\"", 4.0)


# ----------------------------------------------------------------------------
#  VAATE-VUOKKO
# ----------------------------------------------------------------------------
func _clothes_prompt() -> String:
	if not is_open():
		return "Vaate-Vuokko on lähtenyt kotiin (%s)" % hours_text()
	return "Paina E: Vaate-Vuokko – vaatteet"


func _clothes_menu(player: Node2D) -> void:
	if not is_open():
		Game.msg("Koju on kiinni. Vuokko tulee taas aamulla kahdeksalta.", 2.5)
		return
	_menu("VAATE-VUOKKO\n\"Kulta, sä tarviit uuden lookin!\"\nLompakko %d $" % int(player.money),
		["Paidat ja takit", "Housut"], _clothes_cat.bind(player))


func _clothes_cat(i: int, player: Node2D) -> void:
	if i == 0:
		_list(player, "shirt")
	elif i == 1:
		_list(player, "pants")


func _catalog(slot: String) -> Dictionary:
	return Game.SHIRTS if slot == "shirt" else Game.PANTS


func _list(player: Node2D, slot: String) -> void:
	var cat := _catalog(slot)
	var ids: Array = cat.keys()
	var opts: Array = []
	for id: Variant in ids:
		var it: Array = cat[id]
		var sid := str(id)
		if str(Game.outfit.get(slot, "")) == sid:
			opts.append("%s (päällä)" % str(it[0]))
		elif Game.clothes_owned.has(sid):
			opts.append("%s (omistat – pue päälle)" % str(it[0]))
		else:
			opts.append("%s – %d $" % [str(it[0]), int(it[1])])
	_menu("VAATE-VUOKKO – %s\nLompakko %d $" % ["PAIDAT JA TAKIT" if slot == "shirt" else "HOUSUT", int(player.money)],
		opts, _pick.bind(player, slot, ids))


func _pick(i: int, player: Node2D, slot: String, ids: Array) -> void:
	if i < 0 or i >= ids.size():
		return
	var id := str(ids[i])
	var it: Array = _catalog(slot)[id]
	if str(Game.outfit.get(slot, "")) == id:
		Game.msg("Vuokko: \"Sehän on jo sun päällä, hassu!\"", 2.0)
		return
	if not Game.clothes_owned.has(id):
		var price := int(it[1])
		if int(player.money) < price:
			Sfx.play_ui("denied", -4.0)
			Game.msg("Vuokko: \"Voi kulta, rahat ei riitä. %d $.\"" % price, 2.5)
			return
		player.add_money(-price)
		Game.clothes_owned.append(id)
		Sfx.play_ui("cash", -4.0)
	Game.outfit[slot] = id
	Sfx.play_ui("clink", -8.0, 0.8)
	Game.msg("Vuokko: \"%s! Näytät ihan filmitähdeltä.\"" % str(it[0]), 2.5)
	_list(player, slot)


# ----------------------------------------------------------------------------
#  PIIRTO: KOJU (y-järjestys: solmu kojun etureunassa)
# ----------------------------------------------------------------------------
class Stall extends Node2D:
	const CS2 := preload("res://scripts/core/CharSprites.gd")
	var w := 48.0
	var h := 32.0
	var kind := "moped"
	var market: Node2D = null
	var _t := 0.0

	func _process(delta: float) -> void:
		_t += delta
		var cam := get_viewport().get_camera_2d()
		if cam == null or cam.get_screen_center_position().distance_to(global_position) < 520.0:
			queue_redraw()

	func _draw() -> void:
		var font := ThemeDB.fallback_font
		var open: bool = market != null and market.call("is_open")
		var stripe := Color(0.85, 0.15, 0.15) if kind == "moped" else Color(0.15, 0.4, 0.8)
		var wood := Color(0.5, 0.32, 0.17)
		var wood_d := Color(0.32, 0.2, 0.1)
		# varjo ja tolpat
		draw_rect(Rect2(2.0, -4.0, w, 6.0), Color(0, 0, 0, 0.22))
		for px: float in [2.0, w - 4.0]:
			draw_rect(Rect2(px, -h - 14.0, 2.0, h + 12.0), wood_d)
		# takaseinä (kangas)
		draw_rect(Rect2(3.0, -h - 4.0, w - 6.0, 18.0), Color(0.93, 0.9, 0.82))
		# myyjä tiskin takana (vain aukioloaikana)
		if open:
			var row := 3 if kind == "moped" else 15
			var look := 1 if fmod(_t, 7.0) < 5.0 else (0 if kind == "moped" else 3)
			var tex := CS2.npc(look, row)
			if tex:
				var t := tex
				if fmod(_t + w, 4.1) < 0.12:
					var bl := CS2.blink(tex)
					if bl:
						t = bl
				var breath := 1.0 + 0.04 * maxf(sin(_t * 0.8), 0.0)
				var feet := Vector2(w * 0.5, -14.0)
				draw_texture_rect(t, Rect2(feet - Vector2(8.0, 16.0 * breath), Vector2(16.0, 16.0 * breath)), false)
		# vaatekojun henkarit sivuilla
		if kind == "clothes":
			var cols: Array = []
			for id: Variant in Game.SHIRTS:
				var c: Color = (Game.SHIRTS[id] as Array)[2]
				cols.append(c if c.a > 0.0 else Color(0.55, 0.56, 0.6))
			draw_line(Vector2(4.0, -h - 1.0), Vector2(16.0, -h - 1.0), Color(0.6, 0.6, 0.65), 1.0)
			draw_line(Vector2(w - 16.0, -h - 1.0), Vector2(w - 4.0, -h - 1.0), Color(0.6, 0.6, 0.65), 1.0)
			for k in 4:
				_shirt_icon(Vector2(6.0 + k * 3.2, -h + 4.0), cols[k % cols.size()], 0.7)
				_shirt_icon(Vector2(w - 14.0 + k * 3.2, -h + 4.0), cols[(k + 4) % cols.size()], 0.7)
		# tiski
		var counter := Rect2(0.0, -14.0, w, 14.0)
		draw_rect(counter, wood)
		draw_rect(Rect2(counter.position, Vector2(w, 3.0)), wood.lightened(0.25))
		for k in range(1, 4):
			draw_line(Vector2(0.0, -14.0 + k * 3.5 + 2.0), Vector2(w, -14.0 + k * 3.5 + 2.0), wood_d, 1.0)
		draw_rect(counter, wood_d, false, 1.0)
		# tavarat tiskillä
		if kind == "moped":
			draw_circle(Vector2(9.0, -15.5), 3.5, Color(0.92, 0.92, 0.94))   # kypärä
			draw_rect(Rect2(10.0, -17.0, 3.0, 2.0), Color(0.2, 0.3, 0.5))
			draw_rect(Rect2(17.0, -18.0, 4.0, 5.0), Color(0.2, 0.5, 0.25))    # öljykanisteri
			draw_line(Vector2(w - 18.0, -15.0), Vector2(w - 9.0, -16.5), Color(0.7, 0.72, 0.78), 1.5)   # jakoavain
			draw_circle(Vector2(w - 7.0, -16.0), 6.0, Color(0.12, 0.12, 0.14))   # vararengas
			draw_circle(Vector2(w - 7.0, -16.0), 3.0, Color(0.55, 0.57, 0.62))
		else:
			var i := 0
			for id: Variant in Game.SHIRTS:
				var c: Color = (Game.SHIRTS[id] as Array)[2]
				if c.a <= 0.0:
					c = Color(0.55, 0.56, 0.6)
				var x := 4.0 + (i % 4) * 11.0
				var y := -16.0 - int(i / 4) * 2.0
				draw_rect(Rect2(x, y, 9.0, 3.0), c)
				draw_rect(Rect2(x, y, 9.0, 3.0), c.darkened(0.35), false, 0.5)
				i += 1
		# markiisi
		var aw := Rect2(-3.0, -h - 20.0, w + 6.0, 10.0)
		var sx := aw.position.x
		var n := 0
		while sx < aw.end.x:
			var sw := minf(6.0, aw.end.x - sx)
			draw_rect(Rect2(sx, aw.position.y, sw, aw.size.y), stripe if n % 2 == 0 else Color(0.97, 0.96, 0.92))
			sx += 6.0
			n += 1
		var x2 := aw.position.x
		var m := 0
		while x2 < aw.end.x - 1.0:
			draw_colored_polygon(PackedVector2Array([Vector2(x2, aw.end.y), Vector2(x2 + 6.0, aw.end.y), Vector2(x2 + 3.0, aw.end.y + 3.0)]),
				stripe if m % 2 == 0 else Color(0.97, 0.96, 0.92))
			x2 += 6.0
			m += 1
		draw_rect(aw, Color(0, 0, 0, 0.35), false, 1.0)
		# kyltti
		var sign_r := Rect2(w * 0.5 - 22.0, -h - 30.0, 44.0, 10.0)
		draw_rect(sign_r, Color(0.98, 0.95, 0.85))
		draw_rect(sign_r, wood_d, false, 1.0)
		draw_string(font, sign_r.position + Vector2(0.0, 8.0), "MOPO-MAKE" if kind == "moped" else "VAATE-VUOKKO", HORIZONTAL_ALIGNMENT_CENTER, sign_r.size.x, 7, stripe.darkened(0.2))
		if not open:
			draw_string_outline(font, Vector2(0.0, -4.0), "SULJETTU", HORIZONTAL_ALIGNMENT_CENTER, w, 7, 3, Color(0, 0, 0, 0.8))
			draw_string(font, Vector2(0.0, -4.0), "SULJETTU", HORIZONTAL_ALIGNMENT_CENTER, w, 7, Color(1.0, 0.85, 0.5))

	func _shirt_icon(p: Vector2, c: Color, s: float) -> void:
		var pts := PackedVector2Array([p + Vector2(-2, 0) * s, p + Vector2(2, 0) * s, p + Vector2(4, 2) * s, p + Vector2(3, 3) * s,
			p + Vector2(2, 2.5) * s, p + Vector2(2, 8) * s, p + Vector2(-2, 8) * s, p + Vector2(-2, 2.5) * s, p + Vector2(-3, 3) * s, p + Vector2(-4, 2) * s])
		draw_colored_polygon(pts, c)


## Myytävä mopo jalustalla hintalapun kanssa (piilossa, kun oma mopo on jo olemassa).
class MopedDisplay extends Node2D:
	const CAR := preload("res://scripts/entities/Car2D.gd")
	var market: Node2D = null
	var _t := 0.0

	func _process(delta: float) -> void:
		_t += delta
		var want: bool = market != null and market.call("_my_moped") == null
		if want != visible:
			visible = want
		if want:
			var cam := get_viewport().get_camera_2d()
			if cam == null or cam.get_screen_center_position().distance_to(global_position) < 520.0:
				queue_redraw()

	func _draw() -> void:
		var sf: SpriteFrames = CAR.moped_frames(false)
		if sf == null or not sf.has_animation(&"car_right"):
			return
		var tex := sf.get_frame_texture(&"car_right", 0)
		draw_set_transform(Vector2(0.0, -1.0), 0.0, Vector2(1.0, 0.35))
		draw_circle(Vector2.ZERO, 8.0, Color(0, 0, 0, 0.25))
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		draw_texture_rect(tex, Rect2(Vector2(-8.0, -14.0), Vector2(16.0, 16.0)), false)
		var bob := sin(_t * 3.0) * 1.0
		var tag := Rect2(-17.0, -24.0 + bob, 34.0, 11.0)
		draw_rect(tag, Color(1.0, 0.92, 0.2))
		draw_rect(tag, Color(0.85, 0.15, 0.15), false, 1.0)
		draw_string(ThemeDB.fallback_font, tag.position + Vector2(0.0, 8.5), "%d $" % Game.MOPED_PRICE, HORIZONTAL_ALIGNMENT_CENTER, tag.size.x, 8, Color(0.1, 0.1, 0.1))


## Superauto korokkeella (piilossa, kun oma superauto on jo kaupungissa).
class CarDisplay extends Node2D:
	const CAR := preload("res://scripts/entities/Car2D.gd")
	var market: Node2D = null
	var _t := 0.0

	func _process(delta: float) -> void:
		_t += delta
		var want: bool = market != null and market.call("_my_car") == null
		if want != visible:
			visible = want
		if want:
			var cam := get_viewport().get_camera_2d()
			if cam == null or cam.get_screen_center_position().distance_to(global_position) < 520.0:
				queue_redraw()

	func _draw() -> void:
		var sf: SpriteFrames = CAR.supercar_frames()
		if sf == null or not sf.has_animation(&"car_right"):
			return
		var tex := sf.get_frame_texture(&"car_right", 0)
		var sz := tex.get_size()
		# pyöreä näyttelykoroke ja valot
		draw_set_transform(Vector2(0.0, -2.0), 0.0, Vector2(1.0, 0.4))
		draw_circle(Vector2.ZERO, 22.0, Color(0.15, 0.15, 0.18))
		draw_circle(Vector2.ZERO, 20.0, Color(0.3, 0.3, 0.34))
		draw_circle(Vector2.ZERO, 18.0, Color(1.0, 0.9, 0.5, 0.12 + 0.06 * sin(_t * 2.0)))
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		draw_texture_rect(tex, Rect2(Vector2(-sz.x * 0.5, -sz.y - 2.0), sz), false)
		# kiilto liukuu yli
		var gx := fmod(_t * 18.0, sz.x + 30.0) - 15.0 - sz.x * 0.5
		draw_line(Vector2(gx, -sz.y), Vector2(gx + 4.0, -2.0), Color(1, 1, 1, 0.25), 2.0)
		var tag := Rect2(-24.0, -sz.y - 16.0, 48.0, 11.0)
		draw_rect(tag, Color(0.08, 0.08, 0.1))
		draw_rect(tag, Color(1.0, 0.8, 0.1), false, 1.0)
		draw_string(ThemeDB.fallback_font, tag.position + Vector2(0.0, 8.5), "%d $" % Game.SUPERCAR_PRICE, HORIZONTAL_ALIGNMENT_CENTER, tag.size.x, 8, Color(1.0, 0.85, 0.2))
