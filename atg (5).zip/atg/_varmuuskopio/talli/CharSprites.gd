extends RefCounted
## Yksityiskohtaiset hahmokuvat (32x32 px / ruutu), jotka piirretään pelissä
## 16x16-kokoisina (ImageTexture.set_size_override). Näin hahmoissa on
## kaksinkertainen tarkkuus, mutta mittasuhteet, offsetit ja osumalaatikot
## pysyvät täsmälleen ennallaan.
##
## Kuvat tuottaa _varmuuskopio/gen_characters_hd.py.
## Sarakkeet: 0 vasen, 1 alas, 2 ylös, 3 oikea. Rivit: tyyppi * 3 + askel.

const NPC_SHEET: Texture2D = preload("res://assets/sprites/player/characters_hd.png")
const POLICE_SHEET: Texture2D = preload("res://assets/sprites/police/police_officer_hd.png")
## Pelaajan aseasennot: rivit 0-2 yksi käsi, 3-5 kaksi kättä (sarakkeet kuten yllä)
const ARMED_PATH := "res://assets/sprites/player/player_armed_hd.png"
## Pelaajan hahmon ensimmäinen rivi characters.png:ssä
const PLAYER_ROW := 12
const SRC := 32
const DST := 16

static var _cache := {}
static var _imgs := {}


static func frame(sheet: Texture2D, col: int, row: int) -> Texture2D:
	var key := Vector3i(sheet.get_instance_id(), col, row)
	if _cache.has(key):
		return _cache[key]
	var img: Image = _imgs.get(sheet.get_instance_id())
	if img == null:
		img = sheet.get_image()
		if img.is_compressed():
			img.decompress()
		img.convert(Image.FORMAT_RGBA8)
		_imgs[sheet.get_instance_id()] = img
	var sub := img.get_region(Rect2i(col * SRC, row * SRC, SRC, SRC))
	var t := ImageTexture.create_from_image(sub)
	t.set_size_override(Vector2i(DST, DST))
	t.set_meta("cs_col", col)   # 2 = selin: ei silmiä (räpsytys ohitetaan)
	_cache[key] = t
	return t


# ----------------------------------------------------------------------------
#  BAARIN HENKILÖKUNTA (staff_hd.png, _varmuuskopio/gen_staff_hd.py)
# ----------------------------------------------------------------------------
## Asut: 0 tarjoilija (valkoinen paita, musta liivi, rusetti), 1 ovimies (musta), 2 kokki (valkoinen)
## Hahmotyypit 0-2 (samat kasvot kuin NPC-tyypeillä 0-2). Rivit: (asu*3 + tyyppi)*3 + askel.
const STAFF_PATH := "res://assets/sprites/player/staff_hd.png"
const WAITER := 0
const BOUNCER := 1
const CHEF := 2
static var _staff_sheet: Texture2D = null


static func staff(outfit: int, kind: int, col: int, step: int = 0) -> Texture2D:
	if _staff_sheet == null and ResourceLoader.exists(STAFF_PATH):
		_staff_sheet = load(STAFF_PATH) as Texture2D
	if _staff_sheet == null:
		return npc(col, kind * 3 + step)   # kuvaa ei vielä tuotu: tavallinen NPC
	return frame(_staff_sheet, col, (outfit * 3 + kind) * 3 + step)


# ----------------------------------------------------------------------------
#  SILMIEN RÄPSYTYS JA ÄÄRIVIIVA (IdleLife.gd, baarin piirrot)
# ----------------------------------------------------------------------------
static var _blink_cache := {}
static var _mask_cache := {}


## Sama kuva silmät kiinni (null, jos silmiä ei löydy, esim. selkä tai kypärä).
static func blink(tex: Texture2D) -> Texture2D:
	if tex == null:
		return null
	var id := tex.get_instance_id()
	if _blink_cache.has(id):
		return _blink_cache[id]
	var out: Texture2D = null
	if not (tex.has_meta("cs_col") and int(tex.get_meta("cs_col")) == 2):
		var img := tex.get_image()
		if img:
			img = img.duplicate() as Image
			if img.is_compressed():
				img.decompress()
			img.convert(Image.FORMAT_RGBA8)
			if _close_eyes(img):
				var t := ImageTexture.create_from_image(img)
				t.set_size_override(Vector2i(tex.get_size()))
				out = t
	_blink_cache[id] = out
	return out


## Hahmon siluetti valkoisena (ääriviivaa varten: piirretään 1 px siirroilla sävytettynä).
static func mask(tex: Texture2D) -> Texture2D:
	if tex == null:
		return null
	var id := tex.get_instance_id()
	if _mask_cache.has(id):
		return _mask_cache[id]
	var out: Texture2D = null
	var img := tex.get_image()
	if img:
		img = img.duplicate() as Image
		if img.is_compressed():
			img.decompress()
		img.convert(Image.FORMAT_RGBA8)
		for y in img.get_height():
			for x in img.get_width():
				var a := img.get_pixel(x, y).a
				img.set_pixel(x, y, Color(1, 1, 1, 1.0 if a > 0.5 else 0.0))
		var t := ImageTexture.create_from_image(img)
		t.set_size_override(Vector2i(tex.get_size()))
		out = t
	_mask_cache[id] = out
	return out


static func _skin(c: Color) -> bool:
	if c.a < 0.5:
		return false
	var r := c.r8
	var g := c.g8
	var b := c.b8
	return (r > 190 and g > 110 and r > b + 45) or (r >= 100 and r <= 175 and g >= 55 and g <= 115 and b >= 30 and b <= 80 and r > g and g > b)


static func _lum(c: Color) -> float:
	return 0.3 * c.r8 + 0.59 * c.g8 + 0.11 * c.b8


## Etsii pupillit (tumma piste, alla ihoa, yllä värikäs iiris / valkuainen) ja piirtää
## silmäluomen: yläpuoli iholla, pupillin rivi tummalla viivalla.
static func _close_eyes(img: Image) -> bool:
	if img.get_height() != 32:
		return false
	var pupils: Array[Vector2i] = []
	for y in range(7, 16):
		for x in range(1, img.get_width() - 1):
			var c := img.get_pixel(x, y)
			if c.a < 0.5 or absi(c.r8 - 26) + absi(c.g8 - 22) + absi(c.b8 - 34) > 28:
				continue
			var below := img.get_pixel(x, y + 1)
			var above := img.get_pixel(x, y - 1)
			if not _skin(below):
				continue
			if above.a < 0.5 or _skin(above) or _lum(above) < 62.0:
				continue
			pupils.append(Vector2i(x, y))
	if pupils.is_empty():
		return false
	for p in pupils:
		var skin := img.get_pixel(p.x, p.y + 1)
		var lid := Color(skin.r * 0.45, skin.g * 0.4, skin.b * 0.4, 1.0)
		for xx in range(p.x - 1, p.x + 2):
			var a := img.get_pixel(xx, p.y - 1)
			if a.a > 0.5 and (not _skin(a) or _lum(a) > _lum(skin) + 15.0):
				img.set_pixel(xx, p.y - 1, skin)
		for xx in range(p.x - 1, p.x + 2):
			if img.get_pixel(xx, p.y).a > 0.5:
				img.set_pixel(xx, p.y, lid)
	return true


## Jalankulkijat, baarin asiakkaat, katujengit ja pelaaja (characters.png:n järjestys)
static func npc(col: int, row: int) -> Texture2D:
	return frame(NPC_SHEET, col, row)


static func police(col: int, row: int) -> Texture2D:
	return frame(POLICE_SHEET, col, row)


## Pelaajan animaatiot aseasennossa (pose 1 tai 2). frames = Player.tscn:n alkuperäiset ruudut.
static func armed_frames(frames: SpriteFrames, pose: int) -> SpriteFrames:
	var out := frames.duplicate() as SpriteFrames
	if not ResourceLoader.exists(ARMED_PATH):
		return upgrade_frames(frames)
	var sheet := load(ARMED_PATH) as Texture2D
	for anim in out.get_animation_names():
		for i in out.get_frame_count(anim):
			var t := out.get_frame_texture(anim, i)
			if t is AtlasTexture:
				var r: Rect2 = (t as AtlasTexture).region
				var col := int(round(r.position.x / 17.0))
				var row := int(round(r.position.y / 17.0))
				var tex: Texture2D
				if row >= PLAYER_ROW and row < PLAYER_ROW + 3:
					tex = frame(sheet, col, (pose - 1) * 3 + row - PLAYER_ROW)
				else:
					tex = npc(col, row)
				out.set_frame(anim, i, tex, out.get_frame_duration(anim, i))
	return out


# ----------------------------------------------------------------------------
#  PELAAJAN ULKOASU: vaatteiden värit ja kevlarliivi
#  Lähtökuva on aina alkuperäinen (harmaa paita, mustat housut), joten paita, housut
#  ja liivi tunnistetaan sen väreistä luotettavasti ja väritetään sävyt säilyttäen.
# ----------------------------------------------------------------------------
static var _look_cache := {}
const VEST_BASE := Color(0.2, 0.24, 0.15)
const VEST_STRAP := Color(0.09, 0.1, 0.08)
const SHIRT_REF := 142.0     ## alkuperäisen paidan keskisävyn kirkkaus (0-255)
const PANTS_REF := 46.0      ## housujen keskisävy


## Alkuperäisen paidan harmaa (sinertävä, vähän kylläinen) – ei ihoa, housuja eikä ääriviivaa.
static func _shirt(c: Color) -> bool:
	var l := _lum(c)
	var br := c.b8 - c.r8
	return l > 75.0 and l < 215.0 and br >= 6 and br <= 32 and absi(c.g8 - c.r8) <= 12


## Alkuperäiset tummat housut (vyötärö mukaan, solki ja kengät eivät).
static func _pants(c: Color) -> bool:
	var l := _lum(c)
	var br := c.b8 - c.r8
	return l > 28.0 and l < 85.0 and br >= 4 and br <= 20 and absi(c.g8 - c.r8) <= 6


static func _tint(target: Color, c: Color, ref: float) -> Color:
	var k := clampf(_lum(c) / ref, 0.55, 1.55)
	return Color(minf(target.r * k, 1.0), minf(target.g * k, 1.0), minf(target.b * k, 1.0), 1.0)


## Hahmokuva annetuilla vaatteilla (a = 0: alkuperäinen väri) ja liivillä. Välimuistissa.
static func outfit(tex: Texture2D, shirt: Color, pants: Color, vest: bool, mask: bool = false) -> Texture2D:
	if tex == null:
		return tex
	var key := "%d|%s|%s|%d|%d" % [tex.get_instance_id(), shirt.to_html(), pants.to_html(), int(vest), int(mask)]
	if _look_cache.has(key):
		return _look_cache[key]
	var img := tex.get_image()
	if img == null:
		return tex
	if img.is_compressed():
		img.decompress()
	img.convert(Image.FORMAT_RGBA8)
	var w := img.get_width()
	var h := img.get_height()
	var sc := float(h) / 32.0
	var col := int(tex.get_meta("cs_col", 1))
	# liivi: edestä ja takaa vain vartalo (hihat näkyvät), sivulta koko torso
	var vx0 := 0
	var vx1 := w - 1
	if col == 1 or col == 2:
		vx0 = int(10.0 * sc)
		vx1 = int(21.0 * sc)
	var vy0 := int(17.0 * sc)
	var vy1 := int(24.0 * sc)
	for y in range(int(16.0 * sc), int(29.0 * sc)):
		for x in w:
			var c := img.get_pixel(x, y)
			if c.a < 0.5:
				continue
			if y <= vy1 and _shirt(c):
				if vest and y >= vy0 and x >= vx0 and x <= vx1:
					var v := _tint(VEST_BASE, c, SHIRT_REF)
					if y == vy1 - int(2.0 * sc) or y == vy0 + int(1.0 * sc):
						v = VEST_STRAP   # tarranauhat / olkahihnat
					img.set_pixel(x, y, v)
				elif shirt.a > 0.0:
					img.set_pixel(x, y, _tint(shirt, c, SHIRT_REF))
			elif y >= int(25.0 * sc) and pants.a > 0.0 and _pants(c):
				img.set_pixel(x, y, _tint(pants, c, PANTS_REF))
	if mask:
		_balaclava(img, col, sc)
	var out := ImageTexture.create_from_image(img)
	out.set_size_override(Vector2i(tex.get_size()))
	if tex.has_meta("cs_col"):
		out.set_meta("cs_col", tex.get_meta("cs_col"))
	_look_cache[key] = out
	return out


## Kommandopipo: pään iho mustaksi neulokseksi, silmäaukko jää (edestä ja sivulta).
const KNIT := Color(0.14, 0.14, 0.16)

static func _balaclava(img: Image, col: int, sc: float) -> void:
	var w := img.get_width()
	var s0 := int(8.0 * sc)
	var s1 := int(11.0 * sc)
	for y in range(int(2.0 * sc), int(17.0 * sc)):
		for x in w:
			var c := img.get_pixel(x, y)
			if c.a < 0.5 or not _skin(c):
				continue
			if y >= s0 and y <= s1:
				if col == 1 and x >= int(10.0 * sc) and x <= int(21.0 * sc):
					continue
				if col == 0 and x >= int(8.0 * sc) and x <= int(16.0 * sc):
					continue
				if col == 3 and x >= int(15.0 * sc) and x <= int(23.0 * sc):
					continue
			var l := _lum(c)
			var k := 0.45 if l < 120.0 else clampf(l / 180.0, 0.5, 1.4)
			var v := Color(KNIT.r * k, KNIT.g * k, KNIT.b * k, 1.0)
			if int(y / sc) % 3 == 0:
				v = v.darkened(0.2)   # neulosraidat
			img.set_pixel(x, y, v)


## Pelaajan animaatiot uusilla vaatteilla / liivillä / pipolla.
static func outfit_frames(frames: SpriteFrames, shirt: Color, pants: Color, vest: bool, mask: bool = false) -> SpriteFrames:
	var out := frames.duplicate() as SpriteFrames
	for anim in out.get_animation_names():
		for i in out.get_frame_count(anim):
			out.set_frame(anim, i, outfit(out.get_frame_texture(anim, i), shirt, pants, vest, mask), out.get_frame_duration(anim, i))
	return out


## Vaihtaa AnimatedSprite2D:n vanhat 16 px characters.png-ruudut (1 px väli)
## vastaaviin tarkkoihin kuviin.
static func upgrade_frames(frames: SpriteFrames) -> SpriteFrames:
	var out := frames.duplicate() as SpriteFrames
	for anim in out.get_animation_names():
		for i in out.get_frame_count(anim):
			var t := out.get_frame_texture(anim, i)
			if t is AtlasTexture:
				var r: Rect2 = (t as AtlasTexture).region
				var col := int(round(r.position.x / 17.0))
				var row := int(round(r.position.y / 17.0))
				out.set_frame(anim, i, npc(col, row), out.get_frame_duration(anim, i))
	return out


## Istuva hahmo: vain yläruumis (pää ja torso), jalat rajattu pois (terassin tuolit, pöydät).
static var _seat_cache := {}

static func seated(tex: Texture2D) -> Texture2D:
	if tex == null:
		return null
	var id := tex.get_instance_id()
	if _seat_cache.has(id):
		return _seat_cache[id]
	var out: Texture2D = null
	var img := tex.get_image()
	if img and img.get_height() == 32:
		img = img.duplicate() as Image
		if img.is_compressed():
			img.decompress()
		img.convert(Image.FORMAT_RGBA8)
		var sub := img.get_region(Rect2i(0, 0, 32, 23))
		var t := ImageTexture.create_from_image(sub)
		t.set_size_override(Vector2i(16, 12))
		if tex.has_meta("cs_col"):
			t.set_meta("cs_col", tex.get_meta("cs_col"))
		out = t
	_seat_cache[id] = out
	return out



# ----------------------------------------------------------------------------
#  KALLE (kalle_hd.png, _varmuuskopio/gen_kalle_hd.py): skinhead nahkatakissa, tatuoinnit
# ----------------------------------------------------------------------------
const KALLE_PATH := "res://assets/sprites/player/kalle_hd.png"
static var _kalle_sheet: Texture2D = null

static func kalle(col: int, step: int = 0) -> Texture2D:
	if _kalle_sheet == null and ResourceLoader.exists(KALLE_PATH):
		_kalle_sheet = load(KALLE_PATH) as Texture2D
	if _kalle_sheet == null:
		return npc(col, 9 + step)   # kuvaa ei vielä tuotu
	return frame(_kalle_sheet, col, step)


# ----------------------------------------------------------------------------
#  KARTANON JUHLAVIERAAT: naishahmo (tyyppi 1) eri hiusten- ja mekonväreillä
# ----------------------------------------------------------------------------
static var _lady_cache := {}


static func lady(col: int, step: int, hair: Color, dress: Color) -> Texture2D:
	var key := "%d|%d|%s|%s" % [col, step, hair.to_html(), dress.to_html()]
	if _lady_cache.has(key):
		return _lady_cache[key]
	var base := npc(col, 3 + step)
	if base == null:
		return null
	var img := base.get_image()
	if img.is_compressed():
		img.decompress()
	img.convert(Image.FORMAT_RGBA8)
	var w := img.get_width()
	var sc := float(img.get_height()) / 32.0
	for y in img.get_height():
		var ry := float(y) / sc
		for x in w:
			var c := img.get_pixel(x, y)
			if c.a < 0.5:
				continue
			var h := c.h * 360.0
			if ry < 20.0 and c.s >= 0.55 and ((h >= 5.0 and h <= 40.0) or c.v < 0.4):
				img.set_pixel(x, y, _tint(hair, c, 150.0))   # hiukset
			elif ry >= 17.0 and ry < 29.0:
				var red := c.s > 0.45 and (h >= 345.0 or h <= 10.0) and c.v > 0.45
				var jeans := h >= 220.0 and h <= 245.0 and c.s > 0.3 and c.v > 0.45
				if red or jeans:
					img.set_pixel(x, y, _tint(dress, c, 107.0))   # mekko
	var t := ImageTexture.create_from_image(img)
	t.set_size_override(Vector2i(base.get_size()))
	t.set_meta("cs_col", col)
	_lady_cache[key] = t
	return t
