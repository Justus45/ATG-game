# Mopon kuvat (2x tarkkuus): assets/sprites/vehicles/moped_hd.png
# Sarakkeet: 0 vasen, 1 alas, 2 ylös, 3 oikea; ruudun koko 48x48 (piirretään 24x24)
from PIL import Image, ImageDraw
S = 48
RED = (200, 38, 36); RED_D = (140, 22, 24); RED_L = (236, 92, 80)
BLK = (24, 22, 28); TIRE = (34, 34, 40); HUB = (150, 152, 160); CHR = (200, 204, 212)
SEAT = (40, 36, 40); PANTS = (40, 42, 52); JACK = (52, 50, 58); JACK_L = (82, 80, 90)
HELM = (230, 230, 232); HELM_D = (170, 172, 180); VISOR = (40, 60, 95); SKIN = (246, 188, 145)
LIGHT = (255, 238, 150); TAIL = (230, 40, 40)

def side(rider=True):
	im = Image.new('RGBA', (S, S), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
	gy = 42
	for cx in (12, 36):
		d.ellipse((cx-6, gy-12, cx+6, gy), fill=BLK)
		d.ellipse((cx-4, gy-10, cx+4, gy-2), fill=TIRE)
		d.ellipse((cx-2, gy-8, cx+2, gy-4), fill=HUB)
	# runko
	d.polygon([(5, 26), (21, 25), (22, 34), (8, 35)], fill=RED)
	d.line([(6, 26), (20, 25)], fill=RED_L)
	d.rectangle((20, 32, 31, 35), fill=RED_D)            # lattia
	d.polygon([(28, 18), (33, 17), (34, 35), (29, 35)], fill=RED)   # jalkasuoja
	d.line([(29, 18), (29, 34)], fill=RED_L)
	d.polygon([(31, 28), (41, 29), (40, 31), (32, 31)], fill=RED_D)  # etulokasuoja
	d.line([(34, 12), (36, 30)], fill=CHR, width=1)       # ohjausputki
	d.rectangle((31, 11, 37, 12), fill=BLK)               # ohjaustanko
	d.rectangle((37, 14, 39, 17), fill=LIGHT)             # ajovalo
	d.rectangle((4, 27, 5, 29), fill=TAIL)
	d.rectangle((7, 23, 20, 25), fill=SEAT)               # penkki
	if not rider:
		return im
	# kuski
	d.polygon([(17, 22), (26, 23), (27, 26), (17, 26)], fill=PANTS)   # reisi
	d.polygon([(24, 24), (27, 24), (27, 32), (24, 32)], fill=PANTS)   # sääri
	d.rectangle((24, 32, 29, 33), fill=BLK)               # kenkä
	d.polygon([(13, 11), (21, 10), (22, 23), (14, 24)], fill=JACK)    # vartalo
	d.line([(14, 12), (14, 22)], fill=JACK_L)
	d.polygon([(19, 13), (32, 11), (33, 13), (20, 16)], fill=JACK)    # käsi
	d.rectangle((32, 10, 34, 13), fill=SKIN)
	d.ellipse((12, 1, 23, 12), fill=HELM)                 # kypärä
	d.arc((12, 1, 23, 12), 90, 200, fill=HELM_D)
	d.rectangle((19, 5, 23, 8), fill=VISOR)
	return im

def front(back, rider=True):
	im = Image.new('RGBA', (S, S), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
	cx = 24
	# takarengas / eturengas alhaalla
	d.rectangle((cx-3, 34, cx+2, 45), fill=BLK); d.rectangle((cx-2, 35, cx+1, 44), fill=TIRE)
	# runko
	if back:
		d.polygon([(cx-6, 22), (cx+5, 22), (cx+4, 36), (cx-5, 36)], fill=RED)
		d.rectangle((cx-3, 33, cx+2, 35), fill=TAIL)
		d.rectangle((cx-5, 20, cx+4, 24), fill=SEAT)
	else:
		d.polygon([(cx-6, 18), (cx+5, 18), (cx+4, 36), (cx-5, 36)], fill=RED)   # jalkasuoja
		d.line([(cx-5, 19), (cx-5, 35)], fill=RED_L)
		d.rectangle((cx-3, 29, cx+2, 33), fill=RED_D)
		d.ellipse((cx-3, 13, cx+2, 18), fill=LIGHT)      # ajovalo
	d.rectangle((cx-11, 14, cx+10, 15), fill=BLK)        # ohjaustanko
	if not rider:
		return im
	# kuski
	d.polygon([(cx-8, 12), (cx+7, 12), (cx+6, 27), (cx-7, 27)], fill=JACK)
	d.line([(cx-7, 13), (cx-7, 26)], fill=JACK_L)
	if not back:
		d.rectangle((cx-10, 13, cx-8, 16), fill=SKIN); d.rectangle((cx+7, 13, cx+9, 16), fill=SKIN)
		d.rectangle((cx-7, 26, cx-4, 33), fill=PANTS); d.rectangle((cx+3, 26, cx+6, 33), fill=PANTS)
	else:
		d.rectangle((cx-10, 14, cx-8, 17), fill=JACK); d.rectangle((cx+7, 14, cx+9, 17), fill=JACK)
	d.ellipse((cx-6, 0, cx+5, 12), fill=HELM)
	d.arc((cx-6, 0, cx+5, 12), 20, 160, fill=HELM_D)
	if not back:
		d.rectangle((cx-4, 4, cx+3, 8), fill=VISOR)
	else:
		d.line([(cx-1, 1), (cx-1, 11)], fill=RED)
	return im

# rivi 0: kuski kyydissä, rivi 1: pysäköity (ei kuskia)
sheet = Image.new('RGBA', (S * 4, S * 2), (0, 0, 0, 0))
for row, rider in ((0, True), (1, False)):
	r = side(rider)
	sheet.paste(r.transpose(Image.FLIP_LEFT_RIGHT), (0, S * row))
	sheet.paste(front(False, rider), (S, S * row))
	sheet.paste(front(True, rider), (S * 2, S * row))
	sheet.paste(r, (S * 3, S * row))
sheet.save('assets/sprites/vehicles/moped_hd.png')
prev = Image.new('RGBA', (S * 4, S * 2), (110, 110, 115, 255)); prev.paste(sheet, (0, 0), sheet)
prev.resize((S * 12, S * 6), Image.NEAREST).save('_varmuuskopio/tori/moped_preview.png')
print('ok')
