extends Control
## Varustepaikka (inventory slot) ruudun vasemmassa alakulmassa.
## Näyttää kädessä olevan aseen kuvakkeen ja nimen. Tyhjänä paikka on himmeä.

const BOX := Vector2(76.0, 76.0)
const ICON_SIZE := 48.0
const GOLD := Color(0.98, 0.8, 0.15)

var weapon_id := ""

var _icon: Texture2D = null
var _style := StyleBoxFlat.new()
var _name_label: Label
var _hint_label: Label


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	custom_minimum_size = Vector2(BOX.x, 118.0)

	_style.bg_color = Color(0.08, 0.09, 0.13, 0.8)
	_style.set_border_width_all(3)
	_style.set_corner_radius_all(8)

	_name_label = _make_label(Vector2(0.0, 79.0), 15)
	_hint_label = _make_label(Vector2(0.0, 98.0), 12)
	_hint_label.modulate = Color(1, 1, 1, 0.7)
	set_weapon("")


func _make_label(pos: Vector2, font_size: int) -> Label:
	var l := Label.new()
	l.position = pos
	l.size = Vector2(220.0, 20.0)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 4)
	add_child(l)
	return l


## id = aseen tunnus WeaponDB:ssä, tyhjä merkkijono = ei asetta.
func set_weapon(id: String) -> void:
	weapon_id = id
	if id == "":
		_icon = null
		_name_label.text = "Ei asetta"
		_name_label.modulate = Color(1, 1, 1, 0.55)
		_hint_label.text = ""
	else:
		_icon = WeaponDB.icon(id)
		_name_label.text = WeaponDB.display_name(id)
		_name_label.modulate = Color.WHITE
		_hint_label.text = "[G] pudota   [R] ryöstä"
	queue_redraw()


func _draw() -> void:
	_style.border_color = GOLD if weapon_id != "" else Color(0.45, 0.47, 0.55)
	draw_style_box(_style, Rect2(Vector2.ZERO, BOX))
	if _icon:
		var p := (BOX - Vector2(ICON_SIZE, ICON_SIZE)) * 0.5
		draw_texture_rect(_icon, Rect2(p, Vector2(ICON_SIZE, ICON_SIZE)), false)
	var font := ThemeDB.fallback_font
	draw_string(font, Vector2(8.0, 17.0), "1", HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color(1, 1, 1, 0.6))
