extends RefCounted
## Yksityiskohtaiset hahmokuvat (32x32 px / ruutu), jotka piirretään pelissä
## 16x16-kokoisina (ImageTexture.set_size_override). Näin hahmoissa on
## kaksinkertainen tarkkuus, mutta mittasuhteet, offsetit ja osumalaatikot
## pysyvät täsmälleen ennallaan.
##
## Kuvat tuottaa _varmuuskopio/gen_characters_hd.py.
## Sarakkeet: 0 vasen, 1 alas, 2 ylös, 3 oikea. Rivit: tyyppi * 3 + askel.

const NPC_SHEET: Texture2D = preload("res://assets/sprites/player/characters_hd.png")
const POLICE_SHEET: Texture2D = preload("res://assets/sprites/police/police_officer_hd.png")
const SRC := 32
const DST := 16

static var _cache := {}
static var _imgs := {}


static func frame(sheet: Texture2D, col: int, row: int) -> Texture2D:
	var key := Vector3i(sheet.get_instance_id(), col, row)
	if _cache.has(key):
		return _cache[key]
	var img: Image = _imgs.get(sheet.get_instance_id())
	if img == null:
		img = sheet.get_image()
		if img.is_compressed():
			img.decompress()
		img.convert(Image.FORMAT_RGBA8)
		_imgs[sheet.get_instance_id()] = img
	var sub := img.get_region(Rect2i(col * SRC, row * SRC, SRC, SRC))
	var t := ImageTexture.create_from_image(sub)
	t.set_size_override(Vector2i(DST, DST))
	_cache[key] = t
	return t


## Jalankulkijat, baarin asiakkaat, katujengit ja pelaaja (characters.png:n järjestys)
static func npc(col: int, row: int) -> Texture2D:
	return frame(NPC_SHEET, col, row)


static func police(col: int, row: int) -> Texture2D:
	return frame(POLICE_SHEET, col, row)


## Vaihtaa AnimatedSprite2D:n vanhat 16 px characters.png-ruudut (1 px väli)
## vastaaviin tarkkoihin kuviin.
static func upgrade_frames(frames: SpriteFrames) -> SpriteFrames:
	var out := frames.duplicate() as SpriteFrames
	for anim in out.get_animation_names():
		for i in out.get_frame_count(anim):
			var t := out.get_frame_texture(anim, i)
			if t is AtlasTexture:
				var r: Rect2 = (t as AtlasTexture).region
				var col := int(round(r.position.x / 17.0))
				var row := int(round(r.position.y / 17.0))
				out.set_frame(anim, i, npc(col, row), out.get_frame_duration(anim, i))
	return out
