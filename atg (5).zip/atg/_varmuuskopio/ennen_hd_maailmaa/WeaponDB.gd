class_name WeaponDB
extends RefCounted
## Kaikkien aseiden tiedot yhdessä paikassa. Uusi ase = uusi rivi tähän + sprite-arkki
## (7 ruutua à 16 px: poiminta, oikea, vasen, ylös, alas, suuliekki, luoti).

const CELL := 16

const DATA := {
	"pistol": {
		"name": "Pistooli",
		"price": 0,              # dollaria; 0 = ilmainen
		"sheet": "res://assets/sprites/weapons/pistol.png",
		"fire_interval": 0.25,
		"damage": 1,
		"bullet_speed": 450.0,
		"range": 320.0,
		"spread": 0.0,
	},
	"rifle": {
		"name": "Rynnäkkökivääri",
		"price": 300,            # asekaupan hinta
		"sheet": "res://assets/sprites/weapons/rifle.png",
		"fire_interval": 0.09,   # sarjatuli
		"damage": 2,
		"bullet_speed": 620.0,
		"range": 440.0,
		"spread": 0.05,          # radiaaneja, pieni hajonta
	},
	"shotgun": {
		"name": "Haulikko",
		"price": 450,
		"sheet": "res://assets/sprites/weapons/shotgun.png",
		"fire_interval": 0.85,
		"damage": 1,
		"bullet_speed": 420.0,
		"range": 190.0,
		"spread": 0.2,
		"pellets": 6,            # hauleja per laukaus
	},
	# --- Lähiaseet: melee = true. damage = iskun voima, reach = ulottuvuus (px).
	# lethal = tekee oikeaa vahinkoa (veitsi), muuten isku on kuin vahva lyönti.
	"knife": {
		"name": "Veitsi",
		"price": 0,
		"sheet": "res://assets/sprites/weapons/knife.png",
		"fire_interval": 0.4, "damage": 2, "bullet_speed": 0.0, "range": 0.0, "spread": 0.0,
		"melee": true, "reach": 24.0, "lethal": true,
	},
	"bottle": {
		"name": "Pullo",
		"price": 0,
		"sheet": "res://assets/sprites/weapons/bottle.png",
		"fire_interval": 0.5, "damage": 2, "bullet_speed": 0.0, "range": 0.0, "spread": 0.0,
		"melee": true, "reach": 24.0, "durability": 4,
	},
	"cue": {
		"name": "Biljardikeppi",
		"price": 0,
		"sheet": "res://assets/sprites/weapons/cue.png",
		"fire_interval": 0.65, "damage": 2, "bullet_speed": 0.0, "range": 0.0, "spread": 0.0,
		"melee": true, "reach": 36.0, "durability": 12,
	},
	"pen": {
		"name": "Kuulakärkikynä",
		"price": 0,
		"sheet": "res://assets/sprites/weapons/pen.png",
		"fire_interval": 0.25, "damage": 1, "bullet_speed": 0.0, "range": 0.0, "spread": 0.0,
		"melee": true, "reach": 20.0,
	},
}


static func get_data(id: String) -> Dictionary:
	return DATA.get(id, DATA["pistol"])


static func display_name(id: String) -> String:
	return get_data(id).name


## Yksittäinen 16x16-ruutu aseen sprite-arkista.
static func cell(id: String, index: int) -> AtlasTexture:
	var t := AtlasTexture.new()
	t.atlas = load(get_data(id).sheet) as Texture2D
	t.region = Rect2(index * CELL, 0, CELL, CELL)
	return t


## Kuvake poimintaan ja varustepaikkaan.
static func icon(id: String) -> Texture2D:
	return cell(id, 0)
