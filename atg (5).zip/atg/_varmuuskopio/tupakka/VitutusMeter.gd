extends Control
## Vitutusmittari ruudun vasemmassa yläkulmassa rahojen alla.
## Kasvoikoni (kulmat kurtussa, kun vituttaa), palkki vihreästä punaiseen ja prosentti.
## Täysi mittari tärisee. Lukee arvon suoraan Game.vitutus-muuttujasta.

const W := 200.0
const H := 30.0
var _t := 0.0
var _shown := 0.0


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func _process(delta: float) -> void:
	_t += delta
	_shown = move_toward(_shown, Game.vitutus, delta * 60.0)
	queue_redraw()


func _draw() -> void:
	var font := ThemeDB.fallback_font
	var k := clampf(_shown / 100.0, 0.0, 1.0)
	var shake := Vector2.ZERO
	if _shown >= 90.0:
		shake = Vector2(sin(_t * 47.0), cos(_t * 39.0)) * 1.2
	draw_set_transform(shake, 0.0, Vector2.ONE)
	var bg := StyleBoxFlat.new()
	bg.bg_color = Color(0, 0, 0, 0.6)
	bg.set_corner_radius_all(8)
	draw_style_box(bg, Rect2(Vector2.ZERO, Vector2(W, H)))
	# kasvot
	var c := Vector2(15.0, H * 0.5)
	var face := Color(0.98, 0.85, 0.35).lerp(Color(0.95, 0.25, 0.2), k)
	draw_circle(c, 10.0, face)
	draw_arc(c, 10.0, 0.0, TAU, 20, Color(0, 0, 0, 0.6), 1.5)
	var brow := lerpf(0.0, 3.5, k)
	draw_line(c + Vector2(-6, -4 - brow * 0.3), c + Vector2(-2, -3 + brow * 0.5), Color(0.1, 0.05, 0.05), 1.5)
	draw_line(c + Vector2(6, -4 - brow * 0.3), c + Vector2(2, -3 + brow * 0.5), Color(0.1, 0.05, 0.05), 1.5)
	draw_circle(c + Vector2(-3.5, -0.5), 1.2, Color(0.1, 0.05, 0.05))
	draw_circle(c + Vector2(3.5, -0.5), 1.2, Color(0.1, 0.05, 0.05))
	var mouth_y := c.y + 5.0
	var curve := lerpf(-2.0, 2.5, k)   # hymy -> mutristus
	draw_polyline(PackedVector2Array([Vector2(c.x - 4, mouth_y + curve * 0.2), Vector2(c.x, mouth_y - curve), Vector2(c.x + 4, mouth_y + curve * 0.2)]), Color(0.1, 0.05, 0.05), 1.5)
	if k >= 0.75:
		# suuttumusmerkki otsassa
		var v := c + Vector2(7, -9)
		draw_line(v, v + Vector2(3, -2), Color(0.8, 0.0, 0.0), 1.5)
		draw_line(v, v + Vector2(-1, -3), Color(0.8, 0.0, 0.0), 1.5)
	# palkki
	var bar := Rect2(32.0, 15.0, W - 42.0, 9.0)
	draw_rect(bar, Color(0.15, 0.15, 0.18))
	var col := Color(0.3, 0.85, 0.35).lerp(Color(1.0, 0.8, 0.2), clampf(k * 2.0, 0.0, 1.0)).lerp(Color(0.95, 0.15, 0.15), clampf(k * 2.0 - 1.0, 0.0, 1.0))
	draw_rect(Rect2(bar.position, Vector2(bar.size.x * k, bar.size.y)), col)
	draw_rect(bar, Color(1, 1, 1, 0.5), false, 1.0)
	var label := "VITUTUS"
	if k >= 1.0:
		label = "PINNA PALAA!"
	elif k >= 0.8:
		label = "VITUTTAA SIKANA"
	elif k >= 0.5:
		label = "VITUTTAA"
	draw_string_outline(font, Vector2(32.0, 12.0), label, HORIZONTAL_ALIGNMENT_LEFT, -1, 11, 3, Color(0, 0, 0, 0.9))
	draw_string(font, Vector2(32.0, 12.0), label, HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color(1, 1, 1) if k < 0.8 else Color(1.0, 0.6, 0.55))
	var pct := "%d %%" % roundi(_shown)
	draw_string_outline(font, Vector2(0.0, 12.0), pct, HORIZONTAL_ALIGNMENT_RIGHT, W - 10.0, 11, 3, Color(0, 0, 0, 0.9))
	draw_string(font, Vector2(0.0, 12.0), pct, HORIZONTAL_ALIGNMENT_RIGHT, W - 10.0, 11, Color.WHITE)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
