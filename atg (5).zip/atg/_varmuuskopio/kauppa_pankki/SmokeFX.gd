extends Node2D
## Tupakka suussa: hehkuva pää, savukiehkurat ja uloshengitys. Lisätään hahmon kuvan
## (Sprite2D / AnimatedSprite2D) lapseksi, joten seuraa hahmoa ja sen suuntaa.
##  - duration < 0: polttaa loputtomiin (Kalle, tupakoivat NPC:t), muuten sammuu ja poistuu.
##  - on_drag: kutsutaan jokaisella henkosella (pelaajan vitutus laskee).
## Suunta luetaan kuvan metatiedosta "cs_col" (CharSprites): 0 vasen, 1 alas, 2 ylös, 3 oikea.

# --- SÄÄDÄ NÄITÄ ---
const DRAG_EVERY := 2.6        ## henkosten väli (s)
const DRAG_TIME := 0.7         ## henkosen kesto: pää hehkuu kirkkaammin
const WISP_EVERY := 0.22       ## ohut savu tupakan päästä (s)

var sprite: Node2D = null
var duration := -1.0
var on_drag: Callable = Callable()
var active := true

var _t := 0.0
var _life := 0.0
var _drag_t := 0.8
var _drag := 0.0
var _wisp_t := 0.0
var _puffs: Array = []          # [{p, v, age, max, r}]
var _ending := false


func _ready() -> void:
	z_index = 1
	_drag_t = randf_range(0.4, DRAG_EVERY)


func stop() -> void:
	_ending = true


func is_burning() -> bool:
	return active and not _ending


func _col() -> int:
	var tex: Texture2D = null
	if sprite is Sprite2D:
		tex = (sprite as Sprite2D).texture
	elif sprite is AnimatedSprite2D:
		var a := sprite as AnimatedSprite2D
		if a.sprite_frames and a.sprite_frames.has_animation(a.animation):
			tex = a.sprite_frames.get_frame_texture(a.animation, a.frame)
	if tex and tex.has_meta("cs_col"):
		return int(tex.get_meta("cs_col"))
	return 1


## Kuvan vasen yläkulma paikallisissa koordinaateissa (16x16 hahmo)
func _top_left() -> Vector2:
	var off: Vector2 = sprite.get("offset") if sprite and sprite.get("offset") != null else Vector2.ZERO
	var centered: bool = bool(sprite.get("centered")) if sprite else true
	return off - (Vector2(8, 8) if centered else Vector2.ZERO)


## Suun kohta ja tupakan suunta
func _mouth() -> Array:
	var tl := _top_left()
	match _col():
		0:
			return [tl + Vector2(4.5, 7.4), Vector2(-1, 0.25)]
		3:
			return [tl + Vector2(11.5, 7.4), Vector2(1, 0.25)]
		2:
			return [tl + Vector2(8.0, 4.0), Vector2.ZERO]   # selin: vain savu näkyy pään yllä
	return [tl + Vector2(8.6, 7.4), Vector2(0.6, 0.8)]


func _process(delta: float) -> void:
	_t += delta
	if not is_instance_valid(sprite) or not sprite.is_visible_in_tree():
		queue_redraw()
		return
	if duration >= 0.0 and not _ending:
		_life += delta
		if _life >= duration:
			_ending = true
	var m: Array = _mouth()
	var mouth: Vector2 = m[0]
	var dir: Vector2 = m[1]
	var tip := mouth + dir * 3.0
	if not _ending:
		# henkoset
		_drag_t -= delta
		if _drag > 0.0:
			_drag -= delta
			if _drag <= 0.0:
				_exhale(mouth, dir)
		elif _drag_t <= 0.0:
			_drag_t = DRAG_EVERY * randf_range(0.8, 1.3)
			_drag = DRAG_TIME
			if on_drag.is_valid():
				on_drag.call()
		# ohut savu tupakan päästä
		_wisp_t -= delta
		if _wisp_t <= 0.0:
			_wisp_t = WISP_EVERY
			_puffs.append({"p": tip + Vector2(0, -0.5), "v": Vector2(randf_range(-1.5, 1.5), -7.0), "age": 0.0, "max": 1.4, "r": 0.6})
	# savun liike (tuuli puhaltaa)
	var wind := Game.wind * 6.0
	for p: Dictionary in _puffs:
		p["age"] = float(p.age) + delta
		var v: Vector2 = p.v
		v.x = lerpf(v.x, wind, delta * 0.8)
		v.y = lerpf(v.y, -5.0, delta * 0.6)
		p["v"] = v
		p["p"] = (p.p as Vector2) + v * delta
	_puffs = _puffs.filter(func(p: Dictionary) -> bool: return float(p.age) < float(p.max))
	if _ending and _puffs.is_empty():
		active = false
		queue_free()
		return
	queue_redraw()


func _exhale(mouth: Vector2, dir: Vector2) -> void:
	for k in 4:
		var d := (dir if dir != Vector2.ZERO else Vector2(0, -1)).rotated(randf_range(-0.4, 0.4))
		_puffs.append({"p": mouth + Vector2(0, -0.5), "v": d * randf_range(8.0, 14.0) + Vector2(0, -4.0), "age": 0.0,
			"max": randf_range(1.4, 2.2), "r": randf_range(1.0, 1.6)})


func _draw() -> void:
	if not is_instance_valid(sprite):
		return
	# savu
	for p: Dictionary in _puffs:
		var k := float(p.age) / float(p.max)
		var r := float(p.r) + k * 3.0
		draw_circle(p.p, r, Color(0.85, 0.85, 0.88, 0.35 * (1.0 - k)))
	if _ending:
		return
	var m: Array = _mouth()
	var mouth: Vector2 = m[0]
	var dir: Vector2 = m[1]
	if dir == Vector2.ZERO:
		return
	# tupakka ja hehkuva pää
	var tip := mouth + dir * 3.0
	draw_line(mouth, tip, Color(0.96, 0.95, 0.9), 1.0)
	draw_line(mouth, mouth + dir * 0.9, Color(0.85, 0.55, 0.25), 1.0)   # filtteri
	var glow := 0.55 + 0.45 * (1.0 if _drag > 0.0 else 0.3 + 0.2 * sin(_t * 9.0))
	draw_circle(tip, 0.7, Color(1.0, 0.35 + 0.3 * glow, 0.1, 1.0))
	draw_circle(tip, 2.2, Color(1.0, 0.45, 0.15, 0.25 * glow))
