extends Node2D
## Kaupan ja pankin sisätilat (ServiceBuilding luo). Ovesta E vie sisään, sisällä ovelta ulos.
##
##  KAUPPA:  kylmäkaapit takaseinällä, kaksi hyllyriviä tuotteineen, hedelmä- ja vihannestiski,
##           kassa liukuhihnoineen, myyjä ja tupakkakaappi kassan takana, ostoskorit, tarjous-
##           julisteet, turvaportit ja loisteputkien valo. Asiakkaita hyllyjen välissä.
##           Kassalla E: kaupan valikko (ruoka, juomat, tupakka, veitsi...).
##  PANKKI:  marmorilattia ja punainen matto, tummat puupaneelit ja kultaiset kirjaimet,
##           kello, tiski lasiseinineen ja kolmella virkailijalla, holvin ovi, odotustila
##           nojatuoleineen, vuoronumeronäyttö ja -automaatti, pankkiautomaatti ja vartija.
##           Tiskillä tai pankkiautomaatilla E: pankin valikko.
## Sisätila sijaitsee kartan ulkopuolella (kuten koti, baari ja asekauppa). Sulkemisaikana
## henkilökunta ohjaa ulos.

const CS := preload("res://scripts/core/CharSprites.gd")
const TILE := 16
const W := 320.0
const H := 192.0
const ORIGINS := {"shop": Vector2(-3400.0, -1000.0), "bank": Vector2(-3400.0, 600.0)}

var building: Node2D = null      # ServiceBuilding
var kind := "shop"
## Onko pelaaja sisällä (minikartta piiloutuu, sää ja pimeys eivät näy)
var inside := false
var origin := Vector2.ZERO

var _busy := false
var _saved_limits := {}
var _fade: ColorRect
var _view: Node2D
## Ostoskori (kauppa): tuote-id:t, maksetaan kassalla. Ovesta ulos maksamatta = juoksuostokset.
var basket: Array[String] = []
var alarm_t := 0.0
var _basket_label: Label
const BASKET_MAX := 12
## Kaupan ryöstö (Kallen keikka): ampuma-ase esillä kassalla, kestää ROB_TIME sekuntia
const ROB_TIME := 14.0
const ROB_SPOT := Vector2(258.0, 146.0)
const ROB_RANGE := 46.0
var robbing := false
var rob_t := 0.0
var _rob_alarm := false
const WEAPON_ITEMS := ["pen", "knife"]


func setup(b: Node2D, p_kind: String) -> void:
	building = b
	kind = p_kind
	add_to_group("indoor_room")
	origin = ORIGINS.get(kind, Vector2(-3400.0, -1000.0))
	position = origin
	z_index = -10   # hahmot (pelaaja) piirtyvät sisustuksen päälle
	# tausta
	var bg := ColorRect.new()
	bg.color = Color(0.02, 0.02, 0.04)
	bg.position = Vector2(-1500.0, -1500.0)
	bg.size = Vector2(3000.0 + W, 3000.0 + H)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bg.z_index = -20
	add_child(bg)
	_view = (ShopView.new() if kind == "shop" else BankView.new()) as Node2D
	_view.set("room", self)
	add_child(_view)
	# seinät
	for r: Rect2 in [Rect2(0, 0, W, 32), Rect2(0, 0, 16, H), Rect2(W - 16, 0, 16, H), Rect2(0, H - 16, W, 16)]:
		_block(r)
	for r: Rect2 in _view.call("solids"):
		_block(r)
	# ovi ulos
	InteractSpot.create(self, origin + Vector2(W * 0.5, H - 26.0), Vector2(26.0, 18.0), Callable(self, "_door_prompt"), Callable(self, "_exit_door"))
	# palvelupisteet ja hyllyt
	for spot: Array in _view.call("spots"):
		var sp: Vector2 = spot[1]
		InteractSpot.create(self, origin + (spot[0] as Vector2), sp, spot[2], spot[3])
	# häivytys
	var layer := CanvasLayer.new()
	layer.layer = 100
	add_child(layer)
	_fade = ColorRect.new()
	_fade.color = Color(0, 0, 0, 0)
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(_fade)
	_fade.set_anchors_preset(Control.PRESET_FULL_RECT)
	if kind == "shop":
		var ui := CanvasLayer.new()
		ui.layer = 5
		add_child(ui)
		_basket_label = Label.new()
		_basket_label.position = Vector2(20.0, 188.0)
		_basket_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var ls := LabelSettings.new()
		ls.font_size = 13
		ls.outline_size = 4
		ls.outline_color = Color(0, 0, 0, 0.9)
		ls.font_color = Color(1.0, 0.95, 0.75)
		_basket_label.label_settings = ls
		_basket_label.visible = false
		ui.add_child(_basket_label)
		_refresh_basket()


func _block(r: Rect2) -> void:
	var body := StaticBody2D.new()
	var cs := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = r.size
	cs.shape = shape
	body.add_child(cs)
	add_child(body)
	body.position = r.get_center()


func _process(delta: float) -> void:
	if alarm_t > 0.0:
		alarm_t -= delta
	if _basket_label:
		_basket_label.visible = inside
	if not inside or _busy:
		return
	var p := get_tree().get_first_node_in_group("player") as Node2D
	if robbing:
		_update_robbery(p, delta)
	# turvaverkko: pelaaja siirretty muualle (esim. pidätys)
	if p and p.global_position.distance_to(origin) > 1200.0:
		inside = false
		robbing = false
		basket.clear()
		_refresh_basket()
		_set_camera_limits(false)
		return
	if building and building.has_method("is_open") and not building.is_open():
		Game.msg("%s: \"Suljetaan! Tervetuloa huomenna.\"" % ("Myyjä" if kind == "shop" else "Vartija"), 2.5)
		if not basket.is_empty():
			basket.clear()
			_refresh_basket()
		leave(p)


# ----------------------------------------------------------------------------
#  SISÄÄN JA ULOS
# ----------------------------------------------------------------------------
func enter(player: Node2D) -> void:
	await _move(player, true)


func leave(player: Node2D) -> void:
	if player:
		await _move(player, false)


func _move(player: Node2D, to_inside: bool) -> void:
	if _busy or player == null:
		return
	_busy = true
	player.set_physics_process(false)
	player.set_process_unhandled_input(false)
	if "velocity" in player:
		player.velocity = Vector2.ZERO
	var hud := get_tree().current_scene.get_node_or_null("Hud")
	if hud:
		hud.hide_instruction()
	Sfx.play("door_open", player.global_position, -6.0, 0.1)
	await _fade_to(1.0)
	if to_inside:
		inside = true
		_set_camera_limits(true)
		_move_player(player, origin + Vector2(W * 0.5, H - 40.0))
		if kind == "shop":
			Sfx.play("phone", origin + Vector2(W * 0.5, H - 30.0), -16.0, 0.0, 1.8)   # ovikello
	else:
		inside = false
		_set_camera_limits(false)
		_move_player(player, building.door_px + Vector2(0.0, 28.0))
	await _fade_to(0.0)
	player.set_physics_process(true)
	player.set_process_unhandled_input(true)
	_busy = false


func _fade_to(alpha: float) -> void:
	var tw := create_tween()
	tw.tween_property(_fade, "color:a", alpha, 0.18)
	await tw.finished


func _move_player(player: Node2D, target: Vector2) -> void:
	var col := player.get_node_or_null("CollisionShape2D") as Node2D
	var off := col.position if col else Vector2.ZERO
	player.global_position = target - off
	var cam := get_viewport().get_camera_2d()
	if cam:
		cam.global_position = target


func _set_camera_limits(in_room: bool) -> void:
	var cam := get_viewport().get_camera_2d()
	if cam == null:
		return
	if in_room:
		if _saved_limits.is_empty():
			_saved_limits = {"l": cam.limit_left, "t": cam.limit_top, "r": cam.limit_right, "b": cam.limit_bottom}
		var r := Rect2(origin, Vector2(W, H)).grow(260.0)
		cam.limit_left = int(r.position.x)
		cam.limit_top = int(r.position.y)
		cam.limit_right = int(r.end.x)
		cam.limit_bottom = int(r.end.y)
	elif not _saved_limits.is_empty():
		cam.limit_left = _saved_limits.l
		cam.limit_top = _saved_limits.t
		cam.limit_right = _saved_limits.r
		cam.limit_bottom = _saved_limits.b
		_saved_limits = {}


## Palvelupisteen toiminto: avaa rakennuksen valikon (kauppa / pankki)
func open_menu(player: Node2D) -> void:
	if building and building.has_method("open_menu"):
		building.open_menu(player)


# ----------------------------------------------------------------------------
#  OSTOSKORI, KASSA JA JUOKSUOSTOKSET
# ----------------------------------------------------------------------------
func _hud() -> Node:
	var sc := get_tree().current_scene
	return sc.get_node_or_null("Hud") if sc else null


func _item_name(id: String) -> String:
	return str(building.call("item_name", id)) if building else id


func _item_price(id: String) -> int:
	return int(building.call("item_price", id)) if building else 0


func basket_total() -> int:
	var t := 0
	for id: String in basket:
		t += _item_price(id)
	return t


func _basket_lines() -> String:
	var counts := {}
	var order: Array[String] = []
	for id: String in basket:
		if not counts.has(id):
			counts[id] = 0
			order.append(id)
		counts[id] = int(counts[id]) + 1
	var parts: Array[String] = []
	for id: String in order:
		var n := int(counts[id])
		parts.append(("%dx %s" % [n, _item_name(id)]) if n > 1 else _item_name(id))
	return ", ".join(parts)


func _refresh_basket() -> void:
	if _basket_label == null:
		return
	if robbing:
		_basket_label.text = "RYÖSTÖ: myyjä tyhjentää kassaa... %d %%\nPysy kassalla ase esillä!" % roundi(rob_t / ROB_TIME * 100.0)
	elif basket.is_empty():
		_basket_label.text = "OSTOSKORI: tyhjä\nOta tuotteita hyllyistä (E), maksa kassalla"
	else:
		_basket_label.text = "OSTOSKORI  %d $\n%s" % [basket_total(), _basket_lines()]


## Hyllyn E-toiminto: tuote koriin
func take_item(player: Node2D, id: String) -> void:
	if basket.size() >= BASKET_MAX:
		Sfx.play_ui("denied", -8.0)
		Game.msg("Kori on täynnä. Käy kassalla.", 1.8)
		return
	if id in WEAPON_ITEMS:
		if player.has_method("has_weapon") and player.has_weapon():
			Sfx.play_ui("denied", -8.0)
			Game.msg("Kädet täynnä – pudota ensin ase (G).", 2.0)
			return
		for w: String in WEAPON_ITEMS:
			if basket.has(w):
				Sfx.play_ui("denied", -8.0)
				Game.msg("Korissa on jo yksi teräase.", 1.8)
				return
	basket.append(id)
	Sfx.play_ui("clink", -10.0, 1.4)
	Game.msg("%s koriin (%d $). Korissa yhteensä %d $." % [_item_name(id), _item_price(id), basket_total()], 1.6)
	_refresh_basket()


func register_prompt() -> String:
	if basket.is_empty():
		return "Paina E: kassa (tupakka tiskin takaa)"
	return "Paina E: kassa – maksa %d $ käteisellä tai kortilla" % basket_total()


func _door_prompt() -> String:
	if kind == "shop" and not basket.is_empty():
		return "Paina E: lähde maksamatta (%d $)... juoksuostokset!" % basket_total()
	return "Paina E poistuaksesi"


## Kassan valikko
func checkout(player: Node2D) -> void:
	var hud := _hud()
	if hud == null or not hud.has_method("show_menu"):
		return
	var total := basket_total()
	var title := "KASSA\n"
	if basket.is_empty():
		title += "Kori on tyhjä. Ota tuotteita hyllyistä."
	else:
		title += "%s\nYhteensä %d $" % [_basket_lines(), total]
	title += "\nLompakko %d $  |  Tili %d $" % [int(player.money), Game.bank]
	var cig := _item_price("cigs")
	var opts: Array = [
		"Maksa käteisellä (%d $)" % total,
		"Maksa kortilla (%d $)" % total,
		"Tupakka-aski tiskin takaa koriin (%d $, taskussa %d)" % [cig, Game.cigarettes],
		"Palauta tuotteet hyllyyn",
	]
	if _can_rob(player):
		opts.append("RYÖSTÄ KASSA (ase esiin)")
	hud.show_menu(title, opts, _checkout_choice.bind(player))


func _checkout_choice(i: int, player: Node2D) -> void:
	match i:
		0:
			_pay_basket(player, false)
		1:
			_pay_basket(player, true)
		2:
			if basket.size() >= BASKET_MAX:
				Game.msg("Kori on täynnä.", 1.8)
				return
			basket.append("cigs")
			Sfx.play_ui("clink", -10.0, 1.2)
			_refresh_basket()
			checkout(player)
		3:
			if not basket.is_empty():
				basket.clear()
				_refresh_basket()
				Game.msg("Tuotteet palautettu hyllyyn.", 1.6)
		4:
			_start_robbery(player)


# ----------------------------------------------------------------------------
#  KAUPAN RYÖSTÖ
# ----------------------------------------------------------------------------
func _story() -> Node:
	return get_tree().get_first_node_in_group("story")


## Ryöstö on mahdollinen Kallen keikan jälkeen, ampuma-ase kädessä.
func _can_rob(player: Node2D) -> bool:
	if kind != "shop" or robbing:
		return false
	var st := _story()
	if st == null or not st.has_method("rob_unlocked") or not st.rob_unlocked():
		return false
	return player.has_method("has_ranged_weapon") and player.has_ranged_weapon()


func rob_progress() -> float:
	return rob_t / ROB_TIME


func _start_robbery(player: Node2D) -> void:
	if not _can_rob(player):
		return
	if int(Game.story.get("rob_day", -1)) == Game.day:
		Game.msg("Myyjä: \"Kassa on jo tyhjä! Te kävitte jo tänään!\"", 2.5)
		return
	basket.clear()
	robbing = true
	rob_t = 0.0
	_rob_alarm = false
	Sfx.play_ui("denied", -2.0, 0.7)
	Game.msg("Sinä: \"Kassa tyhjäks, heti!\"  Myyjä: \"Älä ammu! Mä teen sen, mä teen sen!\"", 3.0)
	_refresh_basket()


func _update_robbery(p: Node2D, delta: float) -> void:
	var ok: bool = p != null and p.has_method("has_ranged_weapon") and p.has_ranged_weapon() \
		and p.global_position.distance_to(origin + ROB_SPOT) < ROB_RANGE
	if not ok:
		robbing = false
		Game.msg("Ryöstö keskeytyi – myyjä sulki kassan.", 2.5)
		_refresh_basket()
		return
	var before := rob_t
	rob_t += delta
	if int(before) != int(rob_t):
		Sfx.play_ui("coin", -14.0, 0.9 + randf() * 0.3)
		_refresh_basket()
	# myyjä painaa salaa hälytysnappia
	if not _rob_alarm and rob_t >= ROB_TIME * 0.35:
		_rob_alarm = true
		Game.msg("Myyjä painoi hälytysnappia tiskin alla! Poliisi on tulossa.", 3.0)
		Sfx.play("siren", origin + Vector2(W * 0.5, H - 30.0), -10.0, 0.0, 1.8)
		var pm := get_tree().get_first_node_in_group("police_manager")
		if pm and pm.has_method("report_crime"):
			pm.report_crime(5, true)
	if rob_t >= ROB_TIME:
		_finish_robbery(p)


func _finish_robbery(p: Node2D) -> void:
	robbing = false
	var cash := randi_range(220, 380)
	p.add_money(cash)
	Game.story["rob_day"] = Game.day
	Game.add_rep("criminals", 4)
	Game.add_vitutus(Game.VITUTUS_CRIME * 2.0)
	Sfx.play_ui("cash", -2.0)
	var pm := get_tree().get_first_node_in_group("police_manager")
	if pm and pm.has_method("report_crime"):
		pm.report_crime(4, true)
	Game.msg("Kassa tyhjä: +%d $! Häivy ennen kuin kytät tulee!" % cash, 3.0)
	var st := _story()
	if st and st.has_method("on_shop_robbed"):
		st.on_shop_robbed(cash)
	_refresh_basket()


func _strip_weapons(player: Node2D) -> void:
	if not (player.has_method("has_weapon") and player.has_weapon()):
		return
	for w: String in WEAPON_ITEMS:
		if basket.has(w):
			basket.erase(w)
			Game.msg("Kädet täynnä – %s jäi hyllyyn." % _item_name(w), 2.0)


func _pay_basket(player: Node2D, card: bool) -> void:
	if basket.is_empty():
		Game.msg("Myyjä: \"Ei mitään maksettavaa. Hyllyistä saa ottaa!\"", 2.0)
		return
	_strip_weapons(player)
	var total := basket_total()
	if card:
		if Game.bank < total:
			Sfx.play_ui("denied", -4.0)
			Game.msg("Kortti hylätty – tilillä vain %d $ (tarvitaan %d $)." % [Game.bank, total], 2.5)
			return
		Game.bank -= total
	else:
		if int(player.money) < total:
			Sfx.play_ui("denied", -4.0)
			Game.msg("Käteinen ei riitä (%d $ / %d $). Kokeile korttia." % [int(player.money), total], 2.5)
			return
		player.add_money(-total)
	Sfx.play_ui("cash", -4.0)
	var lines := _basket_lines()
	_apply_basket(player)
	Game.msg("%s maksettu (%d $): %s. Myyjä: \"Kiitos, tervetuloa uudelleen!\"" % ["Kortilla" if card else "Käteisellä", total, lines], 3.0)


func _apply_basket(player: Node2D) -> void:
	var items: Array = basket.duplicate()
	basket.clear()
	for id: Variant in items:
		if building and building.has_method("apply_item"):
			building.apply_item(player, str(id))
	_refresh_basket()


## Oven E-toiminto: maksamaton kori = juoksuostokset
func _exit_door(player: Node2D) -> void:
	if robbing:
		robbing = false
		Game.msg("Lähdit kesken ryöstön – kassa jäi tyhjentämättä.", 2.5)
		_refresh_basket()
	if kind != "shop" or basket.is_empty():
		leave(player)
		return
	if _busy:
		return
	var total := basket_total()
	var lines := _basket_lines()
	alarm_t = 2.5
	Sfx.play("siren", origin + Vector2(W * 0.5, H - 30.0), -6.0, 0.0, 1.8)
	Sfx.play_ui("denied", -2.0, 1.5)
	Game.msg("Myyjä: \"HEI! Toi on maksamatta!\" – hälytysportit piippaa!", 2.0)
	await leave(player)
	# saalis kulkee mukana: kotona ruoat jääkaappiin, esineet lattialle (Home.gd)
	for id: String in basket:
		Game.loot.append(id)
	basket.clear()
	_refresh_basket()
	Sfx.play("siren", building.door_px, -4.0, 0.0, 1.8)
	Game.add_vitutus(Game.VITUTUS_CRIME)
	var pm := get_tree().get_first_node_in_group("police_manager")
	if pm and pm.has_method("report_crime"):
		pm.report_crime(3 if total >= 15 else 2)
	Game.msg("Juoksuostokset (%d $): %s. Poliisi on perässä – vie saalis kotiin!" % [total, lines], 3.5)


# ----------------------------------------------------------------------------
#  YHTEISET PIIRTOAPUVÄLINEET
# ----------------------------------------------------------------------------
class RoomView extends Node2D:
	const CS := preload("res://scripts/core/CharSprites.gd")
	const W := 320.0
	const H := 192.0
	var room: Node2D = null
	var _t := 0.0

	func _process(delta: float) -> void:
		_t += delta
		if room and room.get("inside"):
			queue_redraw()

	func solids() -> Array:
		return []

	func spots() -> Array:
		return []

	func _text(pos: Vector2, txt: String, width: float, fs: int, col: Color, outline := Color(0, 0, 0, 0.85)) -> void:
		var font := ThemeDB.fallback_font
		draw_string_outline(font, pos, txt, HORIZONTAL_ALIGNMENT_CENTER, width, fs, 3, outline)
		draw_string(font, pos, txt, HORIZONTAL_ALIGNMENT_CENTER, width, fs, col)

	## NPC-hahmo jalkojen kohdalle (räpsyttää silmiään)
	func _char(feet: Vector2, tex: Texture2D, id: int) -> void:
		if tex == null:
			return
		var t := tex
		if fmod(_t + id * 1.31, 3.7 + id * 0.4) < 0.12:
			var b := CS.blink(tex)
			if b:
				t = b
		var breath := 1.0 + 0.04 * maxf(sin(_t * 0.8 + id * 2.0), 0.0)
		var sz := tex.get_size()
		draw_set_transform(feet + Vector2(0, -0.5), 0.0, Vector2(1.0, 0.4))
		draw_circle(Vector2.ZERO, 5.0, Color(0, 0, 0, 0.25))
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		draw_texture_rect(t, Rect2(feet - Vector2(sz.x * 0.5, sz.y * breath), Vector2(sz.x, sz.y * breath)), false)

	func _door(label: String) -> void:
		var d := Rect2(W * 0.5 - 12.0, H - 16.0, 24.0, 16.0)
		draw_rect(d, Color(0.55, 0.75, 0.85, 0.75))
		draw_rect(d, Color(0.3, 0.32, 0.36), false, 2.0)
		draw_line(Vector2(W * 0.5, d.position.y), Vector2(W * 0.5, d.end.y), Color(0.3, 0.32, 0.36), 1.0)
		draw_rect(Rect2(W * 0.5 - 14.0, H - 28.0, 28.0, 10.0), Color(0.25, 0.25, 0.28))   # ovimatto
		_text(Vector2(W * 0.5 - 30.0, H - 31.0), label, 60.0, 7, Color.WHITE)


# ----------------------------------------------------------------------------
#  KAUPPA
# ----------------------------------------------------------------------------
class ShopView extends RoomView:
	const FRIDGES := Rect2(20.0, 32.0, 176.0, 20.0)
	const GONDOLA_A := Rect2(56.0, 74.0, 18.0, 64.0)
	const GONDOLA_B := Rect2(116.0, 74.0, 18.0, 64.0)
	const FRUIT := Rect2(184.0, 72.0, 48.0, 26.0)
	const COUNTER := Rect2(228.0, 124.0, 62.0, 14.0)
	const TOBACCO := Rect2(290.0, 60.0, 14.0, 52.0)
	const CANDY := Rect2(214.0, 140.0, 12.0, 22.0)

	func solids() -> Array:
		return [FRIDGES, GONDOLA_A, GONDOLA_B, FRUIT, COUNTER, TOBACCO, CANDY]

	func spots() -> Array:
		var take := Callable(room, "take_item")
		return [
			[Vector2(258.0, 150.0), Vector2(40.0, 18.0), Callable(room, "register_prompt"), Callable(room, "checkout")],
			[Vector2(64.0, 60.0), Vector2(84.0, 14.0), "Paina E: Energiajuoma koriin (3 $, väsymys -20)", take.bind("energy")],
			[Vector2(152.0, 60.0), Vector2(84.0, 14.0), "Paina E: Makkara koriin (4 $, nälkä -30)", take.bind("sausage")],
			[Vector2(47.0, 106.0), Vector2(14.0, 56.0), "Paina E: Einesateria koriin (6 $, jääkaappiin)", take.bind("meal")],
			[Vector2(83.0, 106.0), Vector2(14.0, 56.0), "Paina E: Ruokakassi koriin (15 $, 3 annosta jääkaappiin)", take.bind("bag")],
			[Vector2(107.0, 106.0), Vector2(14.0, 56.0), "Paina E: Kuulakärkikynä koriin (1 $)", take.bind("pen")],
			[Vector2(143.0, 106.0), Vector2(14.0, 56.0), "Paina E: Keittiöveitsi koriin (20 $)", take.bind("knife")],
			[Vector2(208.0, 106.0), Vector2(48.0, 14.0), "Paina E: Omena koriin (1 $, nälkä -8)", take.bind("apple")],
		]

	## Hintalappu hyllyn reunassa
	func _tag(c: Vector2, nm: String, price: int) -> void:
		var r := Rect2(c - Vector2(11.0, 4.0), Vector2(22.0, 9.0))
		draw_rect(r, Color(1.0, 0.92, 0.2))
		draw_rect(r, Color(0.85, 0.15, 0.15), false, 1.0)
		draw_string(ThemeDB.fallback_font, r.position + Vector2(0, 7.5), "%d $" % price, HORIZONTAL_ALIGNMENT_CENTER, r.size.x, 7, Color(0.1, 0.1, 0.1))
		_text(Vector2(c.x - 20.0, r.position.y - 1.0), nm, 40.0, 5, Color.WHITE)

	func _draw() -> void:
		# lattia: vaaleat laatat kiiltoineen
		var fr := Rect2(16, 32, W - 32, H - 48)
		draw_rect(fr, Color(0.86, 0.87, 0.84))
		var x := fr.position.x
		while x < fr.end.x:
			draw_line(Vector2(x, fr.position.y), Vector2(x, fr.end.y), Color(0.74, 0.75, 0.72), 1.0)
			x += 16.0
		var y := fr.position.y
		while y < fr.end.y:
			draw_line(Vector2(fr.position.x, y), Vector2(fr.end.x, y), Color(0.74, 0.75, 0.72), 1.0)
			y += 16.0
		for k in 5:
			draw_line(Vector2(40.0 + k * 60.0, fr.position.y), Vector2(20.0 + k * 60.0, fr.end.y), Color(1, 1, 1, 0.12), 3.0)
		# seinät: kerma + vihreä raita, sivuseinät
		draw_rect(Rect2(0, 0, W, 32), Color(0.93, 0.9, 0.82))
		draw_rect(Rect2(0, 22, W, 5), Color(0.15, 0.55, 0.3))
		draw_rect(Rect2(0, 27, W, 2), Color(0.98, 0.6, 0.15))
		draw_rect(Rect2(0, 32, 16, H - 32), Color(0.88, 0.85, 0.77))
		draw_rect(Rect2(W - 16, 32, 16, H - 32), Color(0.88, 0.85, 0.77))
		draw_rect(Rect2(0, H - 16, W, 16), Color(0.88, 0.85, 0.77))
		# kaupan nimi ja tarjousjulisteet
		_text(Vector2(100.0, 17.0), "K A U P P A", 120.0, 13, Color(0.15, 0.55, 0.3), Color(1, 1, 1, 0.9))
		for px: float in [30.0, 230.0, 270.0]:
			var pr := Rect2(px, 3.0, 26.0, 17.0)
			draw_rect(pr, Color(1.0, 0.92, 0.2))
			draw_rect(pr, Color(0.85, 0.15, 0.15), false, 1.0)
			draw_string(ThemeDB.fallback_font, pr.position + Vector2(0, 8), "TARJOUS", HORIZONTAL_ALIGNMENT_CENTER, pr.size.x, 5, Color(0.85, 0.1, 0.1))
			draw_string(ThemeDB.fallback_font, pr.position + Vector2(0, 15), ["0,99", "2 x 1", "-30%"][int(px) % 3], HORIZONTAL_ALIGNMENT_CENTER, pr.size.x, 7, Color(0.1, 0.1, 0.1))
		_fridges()
		_gondola(GONDOLA_A, 1)
		_gondola(GONDOLA_B, 2)
		_fruit()
		# hintalaput (tuotteet otetaan hyllystä E:llä)
		_tag(Vector2(64.0, 58.0), "ENERGIAJUOMA", 3)
		_tag(Vector2(152.0, 58.0), "MAKKARA", 4)
		_tag(Vector2(50.0, 145.0), "ATERIA", 6)
		_tag(Vector2(80.0, 145.0), "KASSI", 15)
		_tag(Vector2(110.0, 145.0), "KYNÄ", 1)
		_tag(Vector2(140.0, 145.0), "VEITSI", 20)
		_tag(Vector2(208.0, 106.0), "OMENA", 1)
		# ostoskorit oven vieressä
		for k in 3:
			var bp := Vector2(36.0, 158.0 - k * 2.0)
			draw_rect(Rect2(bp, Vector2(16, 8)), Color(0.85, 0.15, 0.15))
			draw_rect(Rect2(bp, Vector2(16, 8)), Color(0.55, 0.05, 0.05), false, 1.0)
		draw_line(Vector2(38, 150), Vector2(50, 150), Color(0.3, 0.3, 0.3), 1.0)
		# asiakkaat hyllyjen välissä
		_char(Vector2(96.0, 112.0), CS.npc(0, 6), 11)
		var walk := sin(_t * 0.4) * 22.0
		var cust_dir := 1 if cos(_t * 0.4) > 0.0 else 2
		_char(Vector2(158.0, 118.0 + walk), CS.npc(cust_dir, 15 + (1 + int(_t * 5.0) % 2)), 12)
		_counter()
		# turvaportit ja ovi
		var alarm := room != null and float(room.get("alarm_t")) > 0.0 and fmod(_t * 6.0, 1.0) < 0.5
		for gx: float in [W * 0.5 - 20.0, W * 0.5 + 18.0]:
			draw_rect(Rect2(gx, H - 34.0, 3.0, 16.0), Color(1.0, 0.15, 0.1) if alarm else Color(0.75, 0.77, 0.8))
			draw_rect(Rect2(gx, H - 34.0, 3.0, 16.0), Color(0.4, 0.42, 0.46), false, 1.0)
		_door("ULOS")
		# loisteputket: kylmä valo
		for lx: float in [70.0, 160.0, 250.0]:
			draw_circle(Vector2(lx, 100.0), 60.0, Color(0.9, 0.95, 1.0, 0.05))

	func _fridges() -> void:
		var r := FRIDGES
		draw_rect(r.grow(1.0), Color(0.6, 0.62, 0.66))
		var doors := 8
		var dw := r.size.x / doors
		var cols := [Color(0.95, 0.95, 0.95), Color(0.9, 0.2, 0.2), Color(0.2, 0.55, 0.9), Color(0.95, 0.75, 0.2), Color(0.3, 0.75, 0.4)]
		for d in doors:
			var dr := Rect2(r.position.x + d * dw + 1.0, r.position.y + 1.0, dw - 2.0, r.size.y - 2.0)
			draw_rect(dr, Color(0.55, 0.85, 1.0, 0.9))
			for row in 3:
				for k in 4:
					var c: Color = cols[(d + row + k) % cols.size()]
					draw_rect(Rect2(dr.position.x + 1.5 + k * (dr.size.x - 3.0) / 4.0, dr.position.y + 2.0 + row * 6.0, 2.5, 4.0), c)
			draw_rect(dr, Color(1, 1, 1, 0.25 + 0.05 * sin(_t * 2.0 + d)), false, 1.0)
			draw_line(Vector2(dr.end.x - 2.0, dr.position.y + 6.0), Vector2(dr.end.x - 2.0, dr.position.y + 12.0), Color(0.85, 0.85, 0.9), 1.0)
		draw_rect(Rect2(r.position.x, r.position.y - 2.0, r.size.x, 2.0), Color(0.6, 0.85, 1.0, 0.8))   # valolista

	func _gondola(r: Rect2, seed_i: int) -> void:
		draw_rect(Rect2(r.position + Vector2(1, 2), r.size), Color(0, 0, 0, 0.25))
		draw_rect(r, Color(0.78, 0.8, 0.82))
		draw_rect(Rect2(r.get_center().x - 1.0, r.position.y, 2.0, r.size.y), Color(0.55, 0.57, 0.6))
		var rng := RandomNumberGenerator.new()
		rng.seed = seed_i * 97
		var y := r.position.y + 3.0
		while y < r.end.y - 4.0:
			for side in 2:
				var x := r.position.x + 1.0 + side * (r.size.x * 0.5)
				while x < r.position.x + (side + 1) * r.size.x * 0.5 - 2.0:
					var c := Color.from_hsv(rng.randf(), rng.randf_range(0.5, 0.9), rng.randf_range(0.6, 0.95))
					draw_rect(Rect2(x, y, 2.0, 5.0), c)
					x += 2.6
			draw_line(Vector2(r.position.x, y + 6.0), Vector2(r.end.x, y + 6.0), Color(0.5, 0.52, 0.55), 1.0)
			y += 9.0
		draw_rect(Rect2(r.position.x - 1.0, r.position.y - 6.0, r.size.x + 2.0, 6.0), Color(0.15, 0.55, 0.3))
		draw_string(ThemeDB.fallback_font, Vector2(r.position.x - 1.0, r.position.y - 1.5), ["", "LEIPÄ", "HERKUT"][seed_i], HORIZONTAL_ALIGNMENT_CENTER, r.size.x + 2.0, 4, Color.WHITE)

	func _fruit() -> void:
		var r := FRUIT
		draw_rect(Rect2(r.position + Vector2(1, 2), r.size), Color(0, 0, 0, 0.25))
		var crates := [[Color(0.85, 0.15, 0.15), Color(1.0, 0.4, 0.35)], [Color(0.98, 0.85, 0.2), Color(1.0, 0.95, 0.5)], [Color(1.0, 0.55, 0.1), Color(1.0, 0.75, 0.35)], [Color(0.3, 0.7, 0.25), Color(0.55, 0.85, 0.4)]]
		for i in 4:
			var cr := Rect2(r.position.x + (i % 2) * 24.0, r.position.y + int(i / 2) * 13.0, 23.0, 12.0)
			draw_rect(cr, Color(0.6, 0.4, 0.22))
			draw_rect(cr, Color(0.4, 0.25, 0.12), false, 1.0)
			for k in 7:
				var fp := cr.position + Vector2(3.0 + (k % 4) * 5.0, 3.5 + int(k / 4) * 4.0)
				var cc: Array = crates[i]
				draw_circle(fp, 2.0, cc[0])
				draw_circle(fp + Vector2(-0.6, -0.6), 0.7, cc[1])
		_text(Vector2(r.position.x - 6.0, r.position.y - 2.0), "HEDELMÄT", r.size.x + 12.0, 5, Color(0.3, 0.75, 0.3))

	func _counter() -> void:
		# tupakkakaappi myyjän takana
		var tc := TOBACCO
		draw_rect(tc, Color(0.2, 0.2, 0.22))
		for row in 6:
			for k in 2:
				var pk := Rect2(tc.position.x + 1.5 + k * 6.0, tc.position.y + 2.0 + row * 8.5, 5.0, 7.0)
				draw_rect(pk, Color(0.95, 0.95, 0.92))
				draw_rect(Rect2(pk.position, Vector2(5, 2.5)), [Color(0.8, 0.12, 0.12), Color(0.15, 0.3, 0.7), Color(0.15, 0.5, 0.25)][(row + k) % 3] as Color)
		draw_rect(tc, Color(0.1, 0.1, 0.1), false, 1.0)
		# myyjä kassan takana (ryöstössä kädet ylhäällä, rahat tiskille)
		_char(Vector2(262.0, 124.0), CS.staff(CS.WAITER, 1, 1, 0), 13)
		if room and bool(room.get("robbing")):
			var skin := Color(0.96, 0.74, 0.57)
			var sh := sin(_t * 30.0) * 0.4
			draw_line(Vector2(258.0 + sh, 117.0), Vector2(256.0 + sh, 109.0), skin, 1.6)
			draw_line(Vector2(266.0 - sh, 117.0), Vector2(268.0 - sh, 109.0), skin, 1.6)
			draw_circle(Vector2(256.0 + sh, 108.5), 1.2, skin)
			draw_circle(Vector2(268.0 - sh, 108.5), 1.2, skin)
			var k := clampf(float(room.call("rob_progress")), 0.0, 1.0)
			for i in int(k * 6.0):
				draw_rect(Rect2(232.0 + i * 5.0, 125.0, 4.0, 2.5), Color(0.35, 0.7, 0.35))
				draw_rect(Rect2(232.0 + i * 5.0, 125.0, 4.0, 2.5), Color(0.15, 0.4, 0.15), false, 0.5)
		# kassapöytä, liukuhihna, kassakone ja karkkihylly
		var c := COUNTER
		draw_rect(Rect2(c.position + Vector2(1, 2), c.size), Color(0, 0, 0, 0.3))
		draw_rect(c, Color(0.75, 0.77, 0.8))
		var belt := Rect2(c.position.x + 2.0, c.position.y + 3.0, 32.0, 8.0)
		draw_rect(belt, Color(0.12, 0.12, 0.14))
		var off := fmod(_t * 8.0, 4.0)
		var bx := belt.position.x + off
		while bx < belt.end.x:
			draw_line(Vector2(bx, belt.position.y), Vector2(bx, belt.end.y), Color(0.25, 0.25, 0.28), 1.0)
			bx += 4.0
		draw_rect(Rect2(belt.position.x + 6.0, belt.position.y + 1.0, 5.0, 4.0), Color(0.95, 0.8, 0.2))
		draw_rect(Rect2(belt.position.x + 14.0, belt.position.y + 2.0, 3.0, 5.0), Color(0.2, 0.5, 0.9))
		var reg := Rect2(c.position.x + 40.0, c.position.y - 6.0, 16.0, 12.0)
		draw_rect(reg, Color(0.25, 0.26, 0.3))
		draw_rect(Rect2(reg.position + Vector2(2, 2), Vector2(12, 4)), Color(0.3, 0.95, 0.5))
		var cd := CANDY
		draw_rect(cd, Color(0.6, 0.62, 0.66))
		for k in 6:
			draw_rect(Rect2(cd.position.x + 2.0 + (k % 2) * 4.0, cd.position.y + 2.0 + int(k / 2) * 6.5, 3.5, 5.0), Color.from_hsv(k * 0.17, 0.8, 0.95))
		_text(Vector2(c.position.x - 4.0, c.end.y + 9.0), "KASSA", c.size.x + 8.0, 6, Color(1.0, 0.95, 0.6))


# ----------------------------------------------------------------------------
#  PANKKI
# ----------------------------------------------------------------------------
class BankView extends RoomView:
	const COUNTER := Rect2(40.0, 62.0, 240.0, 16.0)
	const ATM := Rect2(268.0, 140.0, 20.0, 22.0)
	const CHAIRS := Rect2(24.0, 120.0, 52.0, 14.0)
	const TICKET := Rect2(40.0, 152.0, 10.0, 14.0)
	const PLANT := Rect2(24.0, 140.0, 12.0, 12.0)

	func solids() -> Array:
		return [COUNTER, ATM, CHAIRS, TICKET, PLANT]

	func spots() -> Array:
		var menu := Callable(room, "open_menu")
		return [
			[Vector2(160.0, 88.0), Vector2(150.0, 14.0), "Paina E: asioi pankkivirkailijan kanssa", menu],
			[Vector2(ATM.get_center().x - 14.0, ATM.get_center().y), Vector2(14.0, 22.0), "Paina E: pankkiautomaatti", menu],
			[Vector2(TICKET.get_center().x + 12.0, TICKET.get_center().y), Vector2(14.0, 18.0), "Paina E: ota vuoronumero",
				func(_p: Node2D) -> void: Game.msg("Vuoronumero %d. Mene tiskille, tänään ei ole jonoa." % (40 + randi() % 50), 2.0)],
		]

	func _draw() -> void:
		# marmorilattia ja punainen matto
		var fr := Rect2(16, 32, W - 32, H - 48)
		draw_rect(fr, Color(0.9, 0.86, 0.78))
		var cy := fr.position.y
		var r := 0
		while cy < fr.end.y:
			var cx := fr.position.x
			var c := 0
			while cx < fr.end.x:
				if (r + c) % 2 == 0:
					draw_rect(Rect2(cx, cy, minf(24.0, fr.end.x - cx), minf(24.0, fr.end.y - cy)), Color(0.82, 0.77, 0.68))
				cx += 24.0
				c += 1
			cy += 24.0
			r += 1
		var rng := RandomNumberGenerator.new()
		rng.seed = 33
		for k in 30:
			var a := Vector2(rng.randf_range(fr.position.x, fr.end.x), rng.randf_range(fr.position.y, fr.end.y))
			draw_line(a, a + Vector2(rng.randf_range(-14, 14), rng.randf_range(-6, 6)), Color(0.65, 0.6, 0.55, 0.3), 1.0)
		var carpet := Rect2(W * 0.5 - 16.0, 80.0, 32.0, H - 96.0)
		draw_rect(carpet, Color(0.55, 0.06, 0.1))
		draw_rect(carpet.grow(-2.0), Color(0.85, 0.68, 0.3), false, 1.0)
		# seinät: tummat puupaneelit, kultalista
		draw_rect(Rect2(0, 0, W, 32), Color(0.28, 0.16, 0.09))
		var px := 4.0
		while px < W:
			draw_rect(Rect2(px, 4.0, 22.0, 18.0), Color(0.34, 0.2, 0.11), false, 1.0)
			px += 26.0
		draw_rect(Rect2(0, 27, W, 3), Color(0.85, 0.68, 0.3))
		draw_rect(Rect2(0, 32, 16, H - 32), Color(0.26, 0.15, 0.08))
		draw_rect(Rect2(W - 16, 32, 16, H - 32), Color(0.26, 0.15, 0.08))
		draw_rect(Rect2(0, H - 16, W, 16), Color(0.26, 0.15, 0.08))
		_text(Vector2(110.0, 19.0), "P A N K K I", 100.0, 12, Color(0.95, 0.8, 0.35), Color(0.1, 0.05, 0.02, 0.9))
		# seinäkello (pelin aika)
		var cc := Vector2(40.0, 14.0)
		draw_circle(cc, 9.0, Color(0.85, 0.68, 0.3))
		draw_circle(cc, 7.5, Color(0.97, 0.95, 0.9))
		var hrs := fmod(Game.minutes / 60.0, 12.0)
		var mins := fmod(Game.minutes, 60.0)
		draw_line(cc, cc + Vector2.from_angle(-PI * 0.5 + hrs / 12.0 * TAU) * 4.0, Color(0.1, 0.1, 0.1), 1.5)
		draw_line(cc, cc + Vector2.from_angle(-PI * 0.5 + mins / 60.0 * TAU) * 6.0, Color(0.1, 0.1, 0.1), 1.0)
		# taulu
		var art := Rect2(64.0, 4.0, 30.0, 20.0)
		draw_rect(art.grow(1.5), Color(0.85, 0.68, 0.3))
		draw_rect(art, Color(0.35, 0.55, 0.75))
		draw_rect(Rect2(art.position.x, art.position.y + 12.0, art.size.x, 8.0), Color(0.25, 0.45, 0.25))
		draw_circle(art.position + Vector2(22, 6), 3.0, Color(1.0, 0.9, 0.5))
		# holvin ovi takaseinällä
		var vc := Vector2(262.0, 16.0)
		draw_circle(vc, 14.0, Color(0.45, 0.47, 0.5))
		draw_circle(vc, 12.0, Color(0.62, 0.64, 0.68))
		draw_circle(vc, 4.0, Color(0.4, 0.42, 0.45))
		for k in 6:
			var a := k * TAU / 6.0 + _t * 0.05
			draw_line(vc + Vector2.from_angle(a) * 4.0, vc + Vector2.from_angle(a) * 9.0, Color(0.85, 0.85, 0.88), 1.5)
		draw_rect(Rect2(vc.x + 13.0, vc.y - 6.0, 3.0, 12.0), Color(0.35, 0.36, 0.4))
		# virkailijat tiskin takana (tiski peittää jalat)
		for i in 3:
			_char(Vector2(90.0 + i * 70.0, 70.0), CS.staff(CS.WAITER, i % 3, 1, 0), 21 + i)
		# tiski ja lasiseinät
		var ct := COUNTER
		draw_rect(Rect2(ct.position + Vector2(1, 2), ct.size), Color(0, 0, 0, 0.3))
		draw_rect(ct, Color(0.4, 0.24, 0.12))
		draw_rect(Rect2(ct.position, Vector2(ct.size.x, 3.0)), Color(0.85, 0.82, 0.78))
		draw_line(Vector2(ct.position.x, ct.end.y - 3.0), Vector2(ct.end.x, ct.end.y - 3.0), Color(0.85, 0.68, 0.3), 1.0)
		draw_rect(Rect2(ct.position.x, 36.0, ct.size.x, 26.0), Color(0.7, 0.85, 0.95, 0.18))
		for i in 4:
			var gx := ct.position.x + i * 80.0
			draw_rect(Rect2(gx - 1.0, 36.0, 2.0, 26.0), Color(0.85, 0.68, 0.3))
		for i in 3:
			var wx := ct.position.x + 40.0 + i * 80.0
			draw_rect(Rect2(wx - 6.0, 38.0, 12.0, 6.0), Color(0.05, 0.05, 0.08))
			draw_string(ThemeDB.fallback_font, Vector2(wx - 6.0, 43.0), str(i + 1), HORIZONTAL_ALIGNMENT_CENTER, 12.0, 6, Color(1.0, 0.3, 0.2))
			draw_line(Vector2(wx - 14.0, 40.0), Vector2(wx + 14.0, 58.0), Color(1, 1, 1, 0.2), 1.0)   # heijastus
		# vuoronumeronäyttö
		# odotustila: nojatuolit, kasvi, esitetelineet
		var ch := CHAIRS
		for k in 3:
			var cr := Rect2(ch.position.x + k * 18.0, ch.position.y, 16.0, ch.size.y)
			draw_rect(cr, Color(0.15, 0.1, 0.08))
			draw_rect(cr.grow(-2.0), Color(0.45, 0.12, 0.12))
		_char(Vector2(ch.position.x + 26.0, ch.position.y + 4.0), CS.npc(1, 0), 25)
		var pl := PLANT
		draw_rect(Rect2(pl.position + Vector2(2, 5), Vector2(8, 7)), Color(0.6, 0.32, 0.18))
		draw_circle(pl.get_center() + Vector2(0, -2), 7.0, Color(0.15, 0.45, 0.22))
		draw_circle(pl.get_center() + Vector2(-2, -4), 4.0, Color(0.25, 0.6, 0.3))
		# vuoronumeroautomaatti ja näyttö
		var tk := TICKET
		draw_rect(tk, Color(0.3, 0.32, 0.36))
		draw_rect(Rect2(tk.position + Vector2(2, 2), Vector2(6, 3)), Color(1.0, 0.3, 0.2))
		draw_rect(Rect2(tk.position + Vector2(3, 9), Vector2(4, 3)), Color(0.95, 0.95, 0.95))
		var nd := Rect2(278.0, 36.0, 22.0, 12.0)
		draw_rect(nd, Color(0.05, 0.05, 0.06))
		draw_string(ThemeDB.fallback_font, nd.position + Vector2(0, 9), "%03d" % (40 + int(_t / 20.0) % 60), HORIZONTAL_ALIGNMENT_CENTER, nd.size.x, 8, Color(1.0, 0.25, 0.15))
		# pankkiautomaatti
		var at := ATM
		draw_rect(Rect2(at.position + Vector2(1, 2), at.size), Color(0, 0, 0, 0.3))
		draw_rect(at, Color(0.55, 0.58, 0.62))
		draw_rect(Rect2(at.position + Vector2(3, 3), Vector2(14, 8)), Color(0.15, 0.4, 0.75))
		draw_rect(Rect2(at.position + Vector2(4, 4), Vector2(12, 1)), Color(0.6, 0.85, 1.0, 0.6 + 0.4 * sin(_t * 2.0)))
		for k in 6:
			draw_rect(Rect2(at.position.x + 4.0 + (k % 3) * 4.0, at.position.y + 13.0 + int(k / 3) * 3.0, 3.0, 2.0), Color(0.85, 0.85, 0.88))
		_text(Vector2(at.position.x - 8.0, at.position.y - 2.0), "OTTO", at.size.x + 16.0, 5, Color(0.6, 0.85, 1.0))
		# jonotusköydet
		for k in 4:
			var qp := Vector2(W * 0.5 - 24.0, 96.0 + k * 18.0)
			draw_rect(Rect2(qp + Vector2(-1, -6), Vector2(2.5, 7)), Color(0.85, 0.68, 0.3))
			if k < 3:
				draw_line(qp + Vector2(0, -5), qp + Vector2(0, 13), Color(0.6, 0.05, 0.12), 1.5)
		# vartija oven vieressä
		_char(Vector2(W * 0.5 + 30.0, H - 22.0), CS.staff(CS.BOUNCER, 0, 1, 0), 26)
		_door("ULOS")
		# lämmin valo
		for lx: float in [80.0, 160.0, 240.0]:
			draw_circle(Vector2(lx, 110.0), 56.0, Color(1.0, 0.88, 0.6, 0.05))
