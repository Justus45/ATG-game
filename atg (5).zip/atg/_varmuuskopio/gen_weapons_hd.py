"""ATG: aseet 2x-tarkkuudella ja oikeassa mittakaavassa pelaajan käteen.

Jokaisesta aseesta tehdään arkki assets/sprites/weapons/<id>_hd.png:
7 ruutua à 48x48 px (piirretään pelissä 24x24 kokoisina):
  0 poiminta/kuvake, 1 oikea, 2 vasen, 3 ylös, 4 alas, 5 suuliekki (lähiaseilla isku), 6 luoti
Ruudun keskipiste on HeldWeapon-solmun kohta (pelaajan keskeltä 3 px vasemmalle),
ja ase sijoitetaan niin, että sen kahva osuu pelaajan HD-kuvan käteen.

Tulostaa myös suuliekin paikat (HD_MUZZLE) WeaponDB.gd:tä varten.
Ajo: python gen_weapons_hd.py <projektin juuri>
"""
import os, sys
from PIL import Image

C = 48
OUT = (28, 26, 38)
PAL = {
    "w": (214, 218, 232), "l": (150, 156, 176), "m": (100, 104, 124), "d": (62, 64, 82), "e": (38, 38, 48),
    "y": (208, 146, 84), "o": (162, 100, 54), "b": (110, 64, 36),
    "G": (74, 172, 96), "g": (40, 120, 62), "h": (172, 236, 184), "c": (236, 226, 190), "W": (244, 244, 240),
    "s": (190, 198, 214), "S": (246, 248, 252),
    "n": (52, 86, 198), "N": (124, 154, 238),
    "u": (232, 198, 124), "U": (184, 134, 74), "t": (70, 112, 214),
}

ART = {
    "pistol": {
        "side": ["wwwwwwww",
                 "llllllll",
                 "eemmmmmd",
                 "ee.d....",
                 "ee......"],
        "grip": (1, 3), "tip": (7, 1),
        "top": ["eewwwwww",
                "eemmmmmd"],
        "tgrip": (1, 1), "ttip": (7, 0),
    },
    "rifle": {
        "side": ["........mm......m..",
                 "yyo....wwwwwwwyyy..",
                 "yooooolllllllloooll",
                 "bbbbbbmmmmdmmmbbb..",
                 "...bb.eed.dd.......",
                 "......ee..dd.......",
                 "...........dd......"],
        "grip": (6, 4), "tip": (18, 2), "sup": (11, 3),
        "top": ["yyyyyywwwwwwwyyyyll",
                "bbbbbbmmmmmmmbbbbmm"],
        "tgrip": (6, 1), "ttip": (18, 0), "tsup": (11, 1),
    },
    "shotgun": {
        "side": ["yyo.....wwwwwwwwwwww",
                 "yooooommmmmmmmmmmmml",
                 "bbbbbbdmmmyyyyyy....",
                 "...bbeed..bbbbbb....",
                 "......ee............"],
        "grip": (6, 3), "tip": (19, 1), "sup": (11, 2),
        "top": ["yyyyyywwwwwwwwwwwwww",
                "bbbbbbmmmmyyyyyymmmm"],
        "tgrip": (6, 1), "ttip": (19, 0), "tsup": (11, 1),
    },
    "knife": {
        "side": [".....SSSSS..",
                 "eeeedsssssSS",
                 "eeee.ssss..."],
        "grip": (1, 1), "tip": (11, 1),
        "top": ["eeeedssssssS"],
        "tgrip": (1, 0), "ttip": (11, 0),
    },
    "bottle": {
        "side": [".....gggggggg",
                 "Wgg.gGGhhhGGg",
                 "Wgggggcccccgg",
                 "Wgg.gGGGGGGGg",
                 ".....gggggggg"],
        "grip": (2, 2), "tip": (12, 2),
        "top": [".....gggggggg",
                "Wgg.gGGhhhGGg",
                "Wgggggcccccgg",
                "Wgg.gGGGGGGGg",
                ".....gggggggg"],
        "tgrip": (2, 2), "ttip": (12, 2),
    },
    "cue": {
        "side": ["UUUUUUUUuuuuuuuuuuuuuuuuuuuW",
                 "bbbbbbbbUUUUUUUUUUUUUUUUUUUt"],
        "grip": (6, 1), "tip": (27, 0), "sup": (11, 1),
        "top": ["UUUUUUUUuuuuuuuuuuuuuuuuuuuW",
                "bbbbbbbbUUUUUUUUUUUUUUUUUUUt"],
        "tgrip": (6, 1), "ttip": (27, 0), "tsup": (11, 1),
    },
    "pen": {
        "side": ["WNNNNNs",
                 "Wnnnnn."],
        "grip": (2, 1), "tip": (6, 0),
        "top": ["WNNNNNs",
                "Wnnnnn."],
        "tgrip": (2, 1), "ttip": (6, 0),
    },
}
GUNS = {"pistol", "rifle", "shotgun"}
TWO_HANDED = {"rifle", "shotgun", "cue"}
SKIN = [(150, 82, 66), (222, 146, 110), (246, 188, 145), (255, 212, 176)]

# Pelaajan HD-kuvan (32x32) käden kohta kussakin suunnassa -> ruudun koordinaatit.
# Ruudun (48x48) keskipiste = pelaajan HD-kuvan piste (10, 16).
def P2C(x, y):
    return (x + 14, y + 8)


# Käden (kahvan) paikka pelaajan aseasennoissa (player_armed_hd.png)
# 1 = yhden käden ote, 2 = kahden käden ote. Oikea = vasemman peilikuva.
HAND = {
    1: {"left": P2C(7, 19), "right": P2C(24, 19), "down": P2C(18, 23), "up": P2C(25, 19)},
    2: {"left": P2C(9, 21), "right": P2C(22, 21), "down": P2C(17, 23), "up": P2C(25, 19)},
}


def grid(rows):
    w = max(len(r) for r in rows)
    return [r.ljust(w, ".") for r in rows]


def rot_cw(rows, pt):
    rows = grid(rows)
    h, w = len(rows), len(rows[0])
    out = ["".join(rows[h - 1 - x][y] for x in range(h)) for y in range(w)]
    return out, (h - 1 - pt[1], pt[0])


def rot_ccw(rows, pt):
    rows = grid(rows)
    h, w = len(rows), len(rows[0])
    out = ["".join(rows[x][w - 1 - y] for x in range(h)) for y in range(w)]
    return out, (pt[1], w - 1 - pt[0])


def mirror(rows, pt):
    rows = grid(rows)
    w = len(rows[0])
    return [r[::-1] for r in rows], (w - 1 - pt[0], pt[1])


def paint(img, rows, ox, oy):
    px = img.load()
    for y, r in enumerate(grid(rows)):
        for x, ch in enumerate(r):
            if ch != "." and ch in PAL and 0 <= ox + x < img.width and 0 <= oy + y < img.height:
                px[ox + x, oy + y] = PAL[ch] + (255,)


def outline(img):
    px = img.load()
    W, H = img.size
    add = []
    for y in range(H):
        for x in range(W):
            if px[x, y][3]:
                continue
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                if 0 <= x + dx < W and 0 <= y + dy < H and px[x + dx, y + dy][3]:
                    add.append((x, y))
                    break
    for x, y in add:
        px[x, y] = OUT + (255,)


def draw_hand(img, cx, cy, vertical):
    """Kämmen kahvan päälle (3x2 vaaka-aseelle, 2x3 pystyaseelle)."""
    px = img.load()
    pts = [(cx - 1 + i, cy + j) for j in range(2) for i in range(3)] if not vertical else \
          [(cx + i, cy - 1 + j) for j in range(3) for i in range(2)]
    for x, y in pts:
        if 0 <= x < C and 0 <= y < C:
            px[x, y] = SKIN[2] + (255,)
    # varjo alareunaan, valo vasempaan yläkulmaan
    xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
    for x, y in pts:
        if y == max(ys):
            px[x, y] = SKIN[1] + (255,)
    px[min(xs), min(ys)] = SKIN[3] + (255,)


def place(rows, grip, tip, hand, sup=None, vertical=False):
    img = Image.new("RGBA", (C, C), (0, 0, 0, 0))
    ox, oy = hand[0] - grip[0], hand[1] - grip[1]
    paint(img, rows, ox, oy)
    draw_hand(img, hand[0], hand[1], vertical)
    if sup is not None:
        draw_hand(img, ox + sup[0], oy + sup[1], vertical)
    outline(img)
    return img, (ox + tip[0], oy + tip[1])


def flash_img():
    img = Image.new("RGBA", (C, C), (0, 0, 0, 0))
    rows = ["....o........",
            "..o.yo..o....",
            ".oyyWyyyo....",
            "oyWWWWWWyyoo.",
            ".oyyWyyyo....",
            "..o.yo..o....",
            "....o........"]
    pal = {"W": (255, 252, 220), "y": (255, 214, 96), "o": (255, 144, 48)}
    px = img.load()
    for y, r in enumerate(rows):
        for x, ch in enumerate(r):
            if ch in pal:
                px[x, C // 2 - 3 + y] = pal[ch] + (255,)
    return img


def arc_img():
    import math
    img = Image.new("RGBA", (C, C), (0, 0, 0, 0))
    px = img.load()
    for i in range(40):
        a = -1.1 + 2.2 * i / 39
        x = int(round(C / 2 + 9 * math.cos(a)))
        y = int(round(C / 2 + 9 * math.sin(a)))
        px[x, y] = (236, 240, 248, 200)
    return img


def bullet_img():
    img = Image.new("RGBA", (C, C), (0, 0, 0, 0))
    paint(img, ["dyyW", "dooy"], C // 2 - 2, C // 2 - 1)
    return img


def build(wid):
    a = ART[wid]
    sheet = Image.new("RGBA", (C * 7, C), (0, 0, 0, 0))
    muz = {}
    # 0: kuvake (vaakasuora, keskitetty)
    side = grid(a["side"])
    icon = Image.new("RGBA", (C, C), (0, 0, 0, 0))
    paint(icon, side, (C - len(side[0])) // 2, (C - len(side)) // 2)
    outline(icon)
    sheet.alpha_composite(icon, (0, 0))
    # 1 oikea, 2 vasen, 3 ylös, 4 alas
    two = wid in TWO_HANDED
    H = HAND[2 if two else 1]
    sp, tsp = a.get("sup") if two else None, a.get("tsup") if two else None
    img, t = place(a["side"], a["grip"], a["tip"], H["right"], sp)
    sheet.alpha_composite(img, (C * 1, 0)); muz["right"] = t
    rows, g = mirror(a["side"], a["grip"])
    _, tp = mirror(a["side"], a["tip"])
    s2 = mirror(a["side"], sp)[1] if sp else None
    img, t = place(rows, g, tp, H["left"], s2)
    sheet.alpha_composite(img, (C * 2, 0)); muz["left"] = t
    rows, g = rot_ccw(a["top"], a["tgrip"])
    _, tp = rot_ccw(a["top"], a["ttip"])
    img, t = place(rows, g, tp, H["up"], None, True)     # tukikäsi vartalon takana piilossa
    sheet.alpha_composite(img, (C * 3, 0)); muz["up"] = t
    rows, g = rot_cw(a["top"], a["tgrip"])
    _, tp = rot_cw(a["top"], a["ttip"])
    s2 = rot_cw(a["top"], tsp)[1] if tsp else None
    img, t = place(rows, g, tp, H["down"], s2, True)
    sheet.alpha_composite(img, (C * 4, 0)); muz["down"] = t
    sheet.alpha_composite(flash_img() if wid in GUNS else arc_img(), (C * 5, 0))
    sheet.alpha_composite(bullet_img(), (C * 6, 0))
    # suun paikka maailman pikseleinä HeldWeapon-solmusta (ruudun keskipisteestä)
    world = {k: (round((v[0] + 0.5 - C / 2) / 2, 2), round((v[1] + 0.5 - C / 2) / 2, 2)) for k, v in muz.items()}
    return sheet, world


if __name__ == "__main__":
    root = sys.argv[1] if len(sys.argv) > 1 else "."
    lines = []
    for wid in ART:
        sheet, world = build(wid)
        sheet.save(os.path.join(root, "assets/sprites/weapons/%s_hd.png" % wid))
        d = ", ".join('"%s": Vector2(%s, %s)' % (k, world[k][0], world[k][1]) for k in ("right", "left", "up", "down"))
        lines.append('\t"%s": {%s},' % (wid, d))
    print("const HD_MUZZLE := {\n" + "\n".join(lines) + "\n}")
