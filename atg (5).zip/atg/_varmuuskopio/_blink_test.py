from PIL import Image
def dist(a,b): return sum(abs(a[i]-b[i]) for i in range(3))
def lum(c): return 0.3*c[0]+0.59*c[1]+0.11*c[2]
def skinlike(c): return c[3]>128 and ((c[0]>190 and c[1]>110 and c[0]>c[2]+45) or (100<=c[0]<=175 and 55<=c[1]<=115 and 30<=c[2]<=80 and c[0]>c[1]>c[2]))
def blink(fr):
    fr=fr.copy(); W,H=fr.size; px=fr.load()
    pupils=[]
    for y in range(7,16):
        for x in range(1,W-1):
            c=px[x,y]
            if c[3]<128 or dist(c,(26,22,34))>28: continue
            a=px[x,y-1]; b=px[x,y+1]
            if not skinlike(b): continue
            if a[3]<128 or skinlike(a) or lum(a)<62: continue
            pupils.append((x,y))
    if not pupils: return None
    for (x,y) in pupils:
        skin=px[x,y+1]
        lid=(int(skin[0]*0.45),int(skin[1]*0.4),int(skin[2]*0.4),255)
        for xx in range(x-1,x+2):
            if px[xx,y-1][3]>128 and not skinlike(px[xx,y-1]): px[xx,y-1]=skin
            elif px[xx,y-1][3]>128 and lum(px[xx,y-1])>lum(skin)+15: px[xx,y-1]=skin
        for xx in range(x-1,x+2):
            if px[xx,y][3]>128: px[xx,y]=lid
    return fr
import sys
out=Image.new('RGBA',(32*8,32*14),(120,140,120,255))
sheets=['assets/sprites/player/characters_hd.png','assets/sprites/police/police_officer_hd.png','assets/sprites/player/player_armed_hd.png']
r=0
for s in sheets:
    im=Image.open(s).convert('RGBA')
    for t in range(0,im.size[1]//32,3):
        if r>=14: break
        for col in range(4):
            fr=im.crop((col*32,t*32,col*32+32,t*32+32))
            out.alpha_composite(fr,(col*64,r*32))
            b=blink(fr)
            if b: out.alpha_composite(b,(col*64+32,r*32))
        r+=1
out.resize((out.size[0]*3,out.size[1]*3),Image.NEAREST).save('_varmuuskopio/_blink_preview.png')
print('rows',r)
