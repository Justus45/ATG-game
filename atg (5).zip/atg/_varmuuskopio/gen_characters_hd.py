"""ATG: yksityiskohtaisemmat hahmot (32x32 / ruutu).

Piirtää jokaisen hahmon osista (pää, hiukset, vartalo, kädet, jalat, kengät...),
varjostaa osat automaattisesti (valo vasemmalta ylhäältä), lisää yksityiskohdat
(silmät, suu, napit, vyö, merkit) ja ääriviivan.

Tuottaa:
  assets/sprites/player/characters_hd.png   4 x 18 ruutua (kuten characters.png)
  assets/sprites/police/police_officer_hd.png 4 x 3 ruutua (kuten police_officer.png)
Sarakkeet: vasen, alas, ylös, oikea. Rivit: seiso, askel A, askel B.

Ajo: python gen_characters_hd.py <projektin juuri>
"""
import sys, os
from PIL import Image

N = 32

# ------------------------------------------------------------------ PALETTI
# jokainen ramppi: [viiva, varjo, perus, valo, kiilto]
P = {
 "skin":    [(150, 82, 66), (222, 146, 110), (246, 188, 145), (255, 212, 176), (255, 232, 208)],
 "skin_t":  [(140, 76, 56), (206, 128, 88), (234, 168, 120), (248, 196, 150), (255, 222, 186)],
 "skin_d":  [(62, 34, 28), (110, 64, 44), (150, 94, 62), (180, 122, 82), (210, 152, 108)],
 "ginger":  [(104, 44, 28), (172, 78, 38), (214, 116, 58), (238, 156, 86), (252, 196, 128)],
 "auburn":  [(86, 30, 26), (146, 58, 36), (190, 92, 50), (222, 128, 70), (244, 170, 108)],
 "grey_h":  [(72, 70, 98), (122, 120, 154), (160, 158, 190), (194, 194, 216), (228, 228, 240)],
 "black_h": [(14, 14, 20), (30, 30, 40), (48, 48, 60), (74, 74, 90), (108, 108, 128)],
 "brown_h": [(40, 24, 18), (72, 44, 30), (102, 66, 44), (132, 92, 62), (168, 126, 90)],
 "green":   [(22, 66, 50), (40, 116, 84), (62, 160, 118), (104, 194, 148), (158, 224, 186)],
 "khaki":   [(104, 90, 64), (164, 150, 110), (202, 190, 144), (224, 216, 176), (242, 238, 208)],
 "brown":   [(46, 28, 22), (86, 54, 38), (124, 80, 54), (158, 108, 72), (190, 140, 100)],
 "red":     [(84, 22, 32), (146, 42, 46), (192, 70, 70), (222, 108, 96), (242, 150, 128)],
 "jeans":   [(44, 46, 86), (84, 90, 146), (116, 122, 180), (150, 154, 204), (190, 192, 228)],
 "orange":  [(106, 52, 22), (176, 94, 38), (216, 136, 58), (240, 172, 88), (252, 208, 140)],
 "olive":   [(26, 58, 40), (42, 98, 60), (62, 134, 80), (92, 164, 100), (132, 196, 130)],
 "hat_y":   [(116, 70, 18), (194, 126, 28), (238, 174, 48), (252, 208, 88), (255, 240, 170)],
 "hivis":   [(128, 46, 18), (206, 86, 28), (246, 124, 40), (255, 162, 78), (255, 204, 138)],
 "work":    [(48, 50, 84), (90, 94, 140), (122, 126, 172), (154, 158, 200), (192, 194, 224)],
 "silver":  [(110, 112, 124), (170, 174, 186), (210, 214, 222), (232, 236, 240), (252, 252, 255)],
 "tee":     [(50, 52, 62), (98, 102, 116), (138, 142, 156), (174, 178, 190), (210, 212, 222)],
 "dark":    [(18, 18, 24), (38, 40, 48), (58, 60, 70), (84, 86, 98), (116, 118, 132)],
 "white":   [(96, 96, 108), (176, 176, 188), (222, 222, 230), (242, 242, 246), (255, 255, 255)],
 "band":    [(118, 28, 22), (196, 58, 40), (238, 96, 62), (255, 140, 100), (255, 188, 158)],
 "peach":   [(108, 58, 30), (178, 100, 52), (220, 142, 82), (240, 174, 112), (250, 206, 160)],
 "lilac":   [(56, 52, 96), (100, 96, 150), (136, 132, 186), (166, 162, 208), (200, 198, 230)],
 "navy":    [(12, 16, 36), (24, 30, 64), (38, 48, 96), (56, 70, 128), (88, 108, 168)],
 "blue":    [(28, 38, 88), (52, 72, 148), (78, 104, 190), (112, 140, 220), (162, 188, 242)],
 "black":   [(8, 8, 12), (22, 22, 30), (38, 38, 48), (62, 62, 76), (110, 110, 128)],
 "gold":    [(108, 72, 28), (164, 112, 38), (212, 160, 56), (240, 204, 96), (252, 238, 166)],
 "wine":    [(60, 18, 26), (100, 30, 38), (136, 44, 52), (170, 66, 70), (200, 100, 100)],
}
INK = (24, 20, 30)
EYE_W = (250, 248, 244)
PUPIL = (26, 22, 34)
MOUTH = (150, 62, 60)


def spans(rows):
    """{y: [(x0,x1), ...]} tai {y: (x0,x1)} -> pikselijoukko"""
    s = set()
    for y, r in rows.items():
        if isinstance(r, tuple):
            r = [r]
        for x0, x1 in r:
            for x in range(x0, x1 + 1):
                s.add((x, y))
    return s


def vl(x, y0, y1, c):
    return [(x, y, c) for y in range(y0, y1 + 1)]


def hl(y, x0, x1, c):
    return [(x, y, c) for x in range(x0, x1 + 1)]


def rect(x0, y0, x1, y1):
    return {(x, y) for x in range(x0, x1 + 1) for y in range(y0, y1 + 1)}


def shift(px, dx=0, dy=0):
    return {(x + dx, y + dy) for x, y in px}


class Part:
    def __init__(self, px, ramp, z, dim=0, flat=False, gloss=False):
        self.px = set(px)
        self.ramp = P[ramp] if isinstance(ramp, str) else ramp
        self.z = z
        self.dim = dim        # 1 = kauempana oleva raaja, tummempi
        self.flat = flat      # ei reunavaloja (pienet osat)
        self.gloss = gloss    # kiiltävä (kypärä, lippa, kengät)


def render(parts, decals):
    order = sorted(range(len(parts)), key=lambda i: parts[i].z)
    own = {}
    for i in order:
        for p in parts[i].px:
            if 0 <= p[0] < N and 0 <= p[1] < N:
                own[p] = i
    img = Image.new("RGBA", (N, N), (0, 0, 0, 0))
    pix = img.load()
    for (x, y), i in own.items():
        pt = parts[i]
        up, dn = own.get((x, y - 1)), own.get((x, y + 1))
        lf, rt = own.get((x - 1, y)), own.get((x + 1, y))

        def outside(q):
            return q is None or parts[q].z < pt.z and q != i

        def front(q):
            return q is not None and q != i and parts[q].z > pt.z

        s = 2
        if not pt.flat:
            top = outside(up) and up != i
            left = outside(lf) and lf != i
            right = outside(rt) and rt != i
            bot = outside(dn) and dn != i
            if top or left:
                s = 3
            if right or bot:
                s = 1 if not (top and not bot) else 2
            if top and left and pt.gloss:
                s = 4
        # varjo: edessä oleva osa yläpuolella tai sivulla
        if front(up):
            s = min(s, 1)
        elif front(lf) or front(rt) or front(dn):
            s = min(s, 1) if s <= 2 else 2
        s = max(0, s - pt.dim)
        pix[x, y] = pt.ramp[s] + (255,)
    for d in decals:
        x, y, c = d[0], d[1], d[2]
        if 0 <= x < N and 0 <= y < N and ((x, y) in own or (len(d) > 3 and d[3])):
            pix[x, y] = tuple(c[:3]) + (255,)
    # ääriviiva (sel-out): naapuriosan tummin sävy, vedettynä kohti mustetta
    out = img.copy()
    op = out.load()
    for y in range(N):
        for x in range(N):
            if pix[x, y][3]:
                continue
            best = None
            for dx, dy in ((0, -1), (-1, 0), (1, 0), (0, 1)):
                q = own.get((x + dx, y + dy))
                if q is None:
                    continue
                c = parts[q].ramp[0]
                if best is None or sum(c) < sum(best):
                    best = c
            if best:
                k = 0.35
                op[x, y] = tuple(int(best[j] * (1 - k) + INK[j] * k) for j in range(3)) + (255,)
    return out


# ------------------------------------------------------------------ RUNKO
# geometria alas (eteen) katsovalle; sivu = vasemmalle; oikea peilataan
HEAD_F = spans({4: (12, 19), 5: (10, 21), 6: (9, 22), 7: (9, 22), 8: (9, 22), 9: (9, 22), 10: (9, 22),
                11: (9, 22), 12: (9, 22), 13: (9, 22), 14: (10, 21), 15: (11, 20), 16: (13, 18)})
HEAD_S = spans({4: (11, 18), 5: (10, 20), 6: (9, 21), 7: (9, 21), 8: (9, 21), 9: (9, 21), 10: (9, 21),
                11: (8, 21), 12: (8, 21), 13: (9, 21), 14: (9, 20), 15: (10, 19), 16: (11, 17)})


class Char:
    def __init__(self, **k):
        self.skin = "skin"
        self.iris = (70, 110, 170)
        self.hair = None          # tyyli
        self.hair_c = "ginger"
        self.shirt = "green"
        self.sleeve = "short"     # short / long
        self.pants = "khaki"
        self.shoes = "brown"
        self.female = False
        self.__dict__.update(k)


def body(ch, view, f, pose=0):
    """view: 'f' eteen, 'b' taakse, 's' vasemmalle. f: 0 seiso, 1/2 askel.
    pose: 0 kädet vapaana, 1 ase yhdessä kädessä, 2 ase kahdessa kädessä."""
    parts, dec = [], []
    sk = ch.skin
    if view in "fb":
        head = HEAD_F
        parts.append(Part(head, sk, 50))
        parts.append(Part(rect(14, 16, 17, 17), sk, 20, dim=1, flat=True))   # kaula
        if view == "f" or ch.hair in ("bald", "hat", "cap", "thin"):
            parts.append(Part({(8, 10), (8, 11), (8, 12), (7, 11)}, sk, 45, flat=True))
            parts.append(Part({(23, 10), (23, 11), (23, 12), (24, 11)}, sk, 45, flat=True))
            dec += [(8, 11, P[sk][1]), (23, 11, P[sk][1])]
        # vartalo
        torso = spans({17: (12, 19), 18: (11, 20), 19: (11, 20), 20: (11, 20), 21: (11, 20),
                       22: (11, 20), 23: (11, 20), 24: (11, 20)})
        parts.append(Part(torso, ch.shirt, 30))
        # kädet: f1 vasen taakse (ylös), oikea eteen (alas)
        dyl = {0: 0, 1: -1, 2: 1}[f]
        dyr = -dyl
        sides = (("l", dyl), ("r", dyr))
        if pose:
            sides = (("l", dyl),) if pose == 1 else ()
            aim_arms_fb(ch, view, pose, parts)
        for side, dy in sides:
            x0 = 8 if side == "l" else 21
            sl = spans({18: (x0 + (1 if side == "l" else 0), x0 + (2 if side == "l" else 1))}) | rect(x0, 19, x0 + 2, 20)
            if ch.sleeve == "long":
                sl |= rect(x0, 21, x0 + 2, 22 + dy)
                hand = rect(x0, 23 + dy, x0 + 2, 24 + dy)
                parts.append(Part(sl, ch.shirt, 35))
                parts.append(Part(hand, sk, 36))
            else:
                parts.append(Part(sl, ch.shirt, 36))
                arm = rect(x0, 21, x0 + 2, 24 + dy)
                parts.append(Part(arm, sk, 35))
            # hihansuu / kämmen
            dec.append((x0 + 1, 24 + dy, P[sk][1]))
        # lantio + jalat
        parts.append(Part(rect(11, 25, 20, 26), ch.pants, 25))
        for side in ("l", "r"):
            x0, x1 = (11, 15) if side == "l" else (16, 20)
            lift = (f == 1 and side == "l") or (f == 2 and side == "r")
            if lift:
                parts.append(Part(rect(x0, 27, x1, 27), ch.pants, 24))
                sh = rect(x0, 28, x1, 29)
            else:
                parts.append(Part(rect(x0, 27, x1, 28), ch.pants, 24))
                sh = rect(x0, 29, x1, 30) | ({(x0 - 1, 30)} if side == "l" else {(x1 + 1, 30)})
            parts.append(Part(sh, ch.shoes, 26, gloss=True))
            sole_y = max(y for _, y in sh)
            for x, y in sh:
                if y == sole_y:
                    dec.append((x, y, P[ch.shoes][1] if ch.shoes != "white" else P["dark"][3]))
        # housujen keskisauma
        for y in range(26, 29):
            dec.append((15, y, P[ch.pants][1]))
    else:  # sivu, vasemmalle
        parts.append(Part(HEAD_S, sk, 50))
        parts.append(Part(rect(13, 16, 16, 17), sk, 20, dim=1, flat=True))
        if ch.hair in ("bald", "hat", "cap", "thin", "short", "beard"):
            dec += [(15, 10, P[sk][3]), (16, 10, P[sk][1]), (16, 11, P[sk][1]), (15, 12, P[sk][1]), (16, 12, P[sk][1])]
        torso = spans({17: (12, 18), 18: (11, 19), 19: (11, 19), 20: (11, 19), 21: (11, 19),
                       22: (11, 19), 23: (11, 19), 24: (11, 19)})
        parts.append(Part(torso, ch.shirt, 30))
        # käsi: 0 = alas, 1 = lähempi käsi taakse, 2 = eteen
        def arm(dx_end, z, dim):
            sl = rect(14, 18, 16, 20)
            if dx_end < 0:
                lower = {(13, 21), (14, 21), (15, 21), (12, 22), (13, 22), (14, 22), (11, 23), (12, 23), (13, 23)}
                hand = {(10, 24), (11, 24), (12, 24), (11, 23)}
            elif dx_end > 0:
                lower = {(15, 21), (16, 21), (17, 21), (16, 22), (17, 22), (18, 22), (17, 23), (18, 23), (19, 23)}
                hand = {(18, 24), (19, 24), (20, 24), (19, 23)}
            else:
                lower = rect(14, 21, 16, 23)
                hand = rect(14, 24, 16, 24)
            if ch.sleeve == "long":
                parts.append(Part(sl | lower - hand, ch.shirt, z, dim=dim))
                parts.append(Part(hand, sk, z + 1, dim=dim))
            else:
                parts.append(Part(sl, ch.shirt, z + 1, dim=dim))
                parts.append(Part(lower | hand, sk, z, dim=dim))
        near = {0: 0, 1: 1, 2: -1}[f]
        if pose == 1:
            # ase ojennetussa kädessä rinnan korkeudella
            parts.append(Part(rect(13, 18, 16, 20), ch.shirt, 41))
            parts.append(Part(rect(8, 19, 12, 20), sk, 40))
        elif pose == 2:
            # lähempi käsi kahvalla, kauempi käsi tukee edempää
            parts.append(Part(rect(13, 18, 16, 20), ch.shirt, 41))
            parts.append(Part({(12, 20), (11, 20), (12, 21), (11, 21), (10, 21)}, sk, 40))
            parts.append(Part(rect(6, 20, 10, 21), sk, 10, dim=1))
        else:
            if f:
                arm(-near, 10, 1)      # kauempi käsi vartalon takana
            arm(near, 40, 0)
        parts.append(Part(rect(12, 25, 18, 26), ch.pants, 25))

        def leg(kind, z, dim):
            if kind == "stand":
                lg = rect(13, 27, 17, 28)
                sh = spans({29: (12, 17), 30: (11, 17)})
            elif kind == "fwd":
                lg = {(12, 27), (13, 27), (14, 27), (15, 27), (11, 28), (12, 28), (13, 28), (14, 28)}
                sh = spans({29: (10, 14), 30: (9, 14)})
            else:  # taakse, kantapää ylhäällä
                lg = {(15, 27), (16, 27), (17, 27), (18, 27), (16, 28), (17, 28), (18, 28), (19, 28)}
                sh = spans({28: (17, 20), 29: (16, 20)}) - {(20, 28)} | {(21, 29)}
            parts.append(Part(lg, ch.pants, z, dim=dim))
            parts.append(Part(sh, ch.shoes, z + 1, dim=dim, gloss=True))
            sy = max(y for _, y in sh)
            for x, y in sh:
                if y == sy:
                    dec.append((x, y, P[ch.shoes][1] if ch.shoes != "white" else P["dark"][3]))
        if f == 0:
            leg("stand", 24, 0)
        else:
            leg("back" if f == 1 else "fwd", 12, 1)   # kauempi jalka
            leg("fwd" if f == 1 else "back", 24, 0)
    return parts, dec


def aim_arms_fb(ch, view, pose, parts):
    sk = ch.skin
    if view == "f":
        # kuvan oikea käsi koukistuu eteen kahvalle
        parts.append(Part({(20, 18), (21, 18), (20, 19), (21, 19), (22, 19), (20, 20), (21, 20), (22, 20)}, ch.shirt, 36))
        parts.append(Part({(19, 21), (20, 21), (21, 21), (18, 22), (19, 22), (20, 22)}, sk, 37))
        if pose == 2:
            parts.append(Part({(9, 18), (10, 18)} | rect(8, 19, 10, 20), ch.shirt, 36))
            parts.append(Part({(9, 21), (10, 21), (10, 22), (11, 22), (11, 23), (12, 23), (12, 24), (13, 24),
                               (13, 25), (14, 25), (14, 26), (15, 26)}, sk, 37))
    else:
        # selkä: käsi(vars)i nousee eteen, kyynärvarsi vartalon takana piilossa
        parts.append(Part(rect(21, 18, 23, 20), ch.shirt, 36))
        parts.append(Part({(24, 19), (24, 20)}, sk, 37))
        if pose == 2:
            parts.append(Part(rect(8, 18, 10, 20) - {(8, 18)}, ch.shirt, 36))
            parts.append(Part({(7, 19), (7, 20)}, sk, 37))


def face(ch, view, parts, dec):
    sk = P[ch.skin]
    if view == "f":
        for ex in (11, 18):
            dec += [(ex, 10, EYE_W), (ex + 1, 10, ch.iris), (ex + 2, 10, EYE_W),
                    (ex + 1, 11, PUPIL), (ex, 11, sk[3]), (ex + 2, 11, sk[2])]
            lash = (60, 30, 30)
            dec += [(ex, 9, lash), (ex + 1, 9, lash), (ex + 2, 9, lash)]
            if ch.female:
                dec += [((ex - 1) if ex == 11 else (ex + 3), 9, lash), (ex + 1, 11, PUPIL)]
            brow = P[ch.hair_c][0] if ch.hair not in ("bald",) else sk[0]
            if not ch.female:
                dec += [(ex, 8, brow), (ex + 1, 8, brow), (ex + 2, 8, brow)]
            else:
                dec += [(ex + (0 if ex == 11 else 1), 7, brow), (ex + (1 if ex == 11 else 2), 7, brow)]
        # nenä
        dec += [(16, 12, sk[1]), (15, 12, sk[3]), (16, 13, sk[1])]
        # suu
        if ch.female:
            dec += [(15, 14, (196, 80, 82)), (16, 14, (196, 80, 82)), (14, 14, sk[1]), (17, 14, sk[1])]
            dec += [(11, 12, (246, 150, 130)), (20, 12, (246, 150, 130))]
        else:
            dec += [(14, 14, sk[1]), (15, 14, MOUTH), (16, 14, MOUTH), (17, 14, sk[1])]
        # leuan alla varjo
        dec += [(x, 16, sk[1]) for x in range(13, 19)]
    elif view == "s":
        dec += [(10, 10, ch.iris), (10, 11, PUPIL), (11, 10, EYE_W), (11, 11, sk[3])]
        lash = (60, 30, 30)
        dec += [(10, 9, lash), (11, 9, lash), (9, 9, lash) if ch.female else (12, 9, lash)]
        brow = P[ch.hair_c][0] if ch.hair != "bald" else sk[0]
        if not ch.female:
            dec += [(9, 8, brow), (10, 8, brow), (11, 8, brow), (12, 8, brow)]
        dec += [(8, 12, sk[3]), (8, 13, sk[1]), (9, 13, sk[1])]   # nenä
        if ch.female:
            dec += [(9, 14, (196, 80, 82)), (10, 14, (196, 80, 82)), (12, 12, (246, 150, 130))]
        else:
            dec += [(9, 14, MOUTH), (10, 14, sk[1])]
        dec += [(x, 16, sk[1]) for x in range(11, 15)]


# ------------------------------------------------------------------ HIUKSET / PÄÄHINEET
def hair(ch, view, parts, dec):
    h = ch.hair_c
    R = P[h]
    st = ch.hair
    if st == "short":
        if view == "f":
            px = spans({3: (12, 19), 4: (10, 21), 5: (9, 22), 6: (8, 23),
                        7: [(8, 23)], 8: [(8, 10), (12, 15), (19, 23)], 9: [(8, 9), (13, 14), (22, 23)]})
            parts.append(Part(px, h, 60))
            dec += hl(4, 11, 14, R[4]) + hl(5, 10, 12, R[3]) + [(15, 5, R[3]), (16, 5, R[3])]
            dec += vl(14, 6, 7, R[1]) + vl(18, 5, 7, R[1]) + vl(21, 6, 7, R[1]) + vl(11, 6, 7, R[1]) + [(9, 8, R[1])]
        elif view == "b":
            px = spans({3: (12, 19), 4: (10, 21), 5: (8, 23), 6: (8, 23), 7: (8, 23), 8: (8, 23), 9: (8, 23),
                        10: (8, 23), 11: (8, 23), 12: (8, 23), 13: (9, 22), 14: [(10, 12), (14, 17), (19, 21)]})
            parts.append(Part(px, h, 60))
            dec += hl(4, 12, 14, R[4]) + hl(5, 10, 15, R[3]) + hl(6, 9, 11, R[3])
            dec += vl(11, 8, 11, R[1]) + vl(15, 7, 10, R[1]) + vl(19, 7, 11, R[1]) + vl(13, 11, 13, R[1]) + vl(17, 10, 13, R[1])
        else:
            px = spans({3: (11, 18), 4: (9, 20), 5: (8, 21), 6: (8, 22), 7: [(8, 10), (12, 22)],
                        8: [(8, 9), (14, 22)], 9: (17, 22), 10: (17, 22), 11: (17, 22), 12: (18, 22), 13: (18, 21)})
            parts.append(Part(px, h, 60))
            dec += hl(4, 10, 13, R[4]) + hl(5, 9, 12, R[3]) + [(14, 5, R[3])]
            dec += vl(16, 5, 7, R[1]) + vl(19, 6, 11, R[1]) + vl(21, 8, 11, R[1]) + vl(13, 6, 7, R[1])
    elif st == "long":
        if view == "f":
            back = rect(9, 8, 22, 19)
            parts.append(Part(back, h, 5, dim=1))
            px = spans({3: (12, 19), 4: (10, 21), 5: (9, 22), 6: (8, 23), 7: [(8, 15), (18, 23)],
                        8: [(8, 13), (20, 23)], 9: [(8, 11), (21, 23)]})
            px |= spans({y: [(7, 9), (22, 24)] for y in range(10, 20)})
            px |= {(8, 20), (23, 20)}
            parts.append(Part(px, h, 60))
            dec += hl(4, 11, 14, R[4]) + hl(5, 10, 13, R[3]) + [(10, 6, R[3])]
            dec += vl(16, 4, 6, R[1]) + [(17, 7, R[1]), (12, 7, R[1]), (10, 8, R[1])]
            dec += vl(8, 11, 18, R[1]) + vl(23, 11, 18, R[1]) + vl(7, 12, 16, R[3]) + vl(22, 10, 14, R[3])
        elif view == "b":
            px = spans({3: (12, 19), 4: (10, 21), 5: (8, 23)})
            px |= rect(8, 6, 23, 19) | spans({20: [(9, 11), (13, 18), (20, 22)]})
            px |= rect(7, 9, 24, 17)
            parts.append(Part(px, h, 60))
            dec += hl(4, 12, 14, R[4]) + hl(5, 10, 15, R[3]) + hl(6, 9, 12, R[3])
            dec += vl(11, 8, 18, R[1]) + vl(15, 7, 19, R[1]) + vl(19, 8, 18, R[1]) + vl(22, 10, 16, R[1])
            dec += vl(9, 9, 15, R[3]) + vl(13, 9, 14, R[3]) + vl(17, 10, 15, R[3])
        else:
            px = spans({3: (11, 18), 4: (9, 20), 5: (8, 21), 6: (8, 22), 7: [(8, 11), (13, 22)],
                        8: [(8, 10), (14, 22)]})
            px |= rect(14, 9, 22, 18) | spans({19: (15, 22), 20: [(16, 17), (19, 21)]})
            parts.append(Part(px, h, 60))
            dec += hl(4, 10, 13, R[4]) + hl(5, 9, 12, R[3])
            dec += vl(16, 8, 18, R[1]) + vl(19, 7, 19, R[1]) + vl(21, 9, 16, R[1]) + vl(17, 9, 14, R[3]) + vl(15, 9, 13, R[3])
    elif st == "beard":
        g = P["grey_h"]
        if view == "f":
            px = spans({6: [(8, 10), (21, 23)], 7: [(8, 10), (21, 23)], 8: [(8, 9), (22, 23)], 9: [(8, 9), (22, 23)]})
            px |= {(13, 4), (14, 4), (17, 4), (18, 4)}
            parts.append(Part(px, "grey_h", 60))
            bd = spans({12: [(9, 9), (22, 22)], 13: [(9, 12), (19, 22)], 14: [(9, 13), (18, 22)],
                        15: (10, 21), 16: (11, 20), 17: (13, 18)})
            bd |= rect(13, 13, 18, 13)
            parts.append(Part(bd, "grey_h", 62))
            dec += [(15, 13, g[3]), (16, 13, g[2]), (14, 14, MOUTH), (15, 14, MOUTH), (16, 14, MOUTH), (17, 14, MOUTH)]
            parts.append(Part(rect(14, 14, 17, 14), "skin", 61, flat=True))
            dec += [(12, 16, g[1]), (15, 16, g[1]), (18, 15, g[1]), (11, 14, g[3]), (14, 17, g[3])]
            # ryppy otsalla ja kaljun kiilto
            dec += [(13, 6, P["skin"][1]), (14, 6, P["skin"][1]), (17, 6, P["skin"][1]), (12, 5, P["skin"][4])]
        elif view == "b":
            px = spans({7: (9, 22), 8: (8, 23), 9: (8, 23), 10: (8, 23), 11: (8, 23), 12: (9, 22), 13: (10, 21)})
            parts.append(Part(px, "grey_h", 60))
            dec += [(12, 5, P["skin"][4]), (13, 5, P["skin"][4]), (11, 6, P["skin"][3])]
            dec += hl(8, 10, 21, g[3]) + vl(12, 9, 12, g[1]) + vl(16, 9, 12, g[1]) + vl(20, 9, 11, g[1])
        else:
            px = spans({6: (16, 20), 7: (15, 21), 8: (14, 21), 9: (17, 21), 10: (17, 21), 11: (18, 21), 12: (18, 21), 13: (17, 20)})
            parts.append(Part(px, "grey_h", 60))
            bd = spans({12: (13, 14), 13: [(9, 10), (12, 16)], 14: (11, 16), 15: (9, 15), 16: (10, 14), 17: (11, 13)})
            parts.append(Part(bd, "grey_h", 62))
            dec += [(13, 5, P["skin"][4]), (12, 15, g[1]), (14, 14, g[1]), (10, 15, g[3])]
    elif st == "hat":
        y = P["hat_y"]
        if view == "f":
            dome = spans({2: (12, 19), 3: (10, 21), 4: (9, 22), 5: (8, 23), 6: (8, 23), 7: (8, 23)})
            parts.append(Part(dome, "hat_y", 70, gloss=True))
            parts.append(Part(rect(6, 8, 25, 8), "hat_y", 71, flat=True))
            dec += [(15, 2, y[3]), (16, 2, y[3])] + [(15, yy, y[3]) for yy in range(3, 8)] + [(16, yy, y[1]) for yy in range(3, 8)]
            dec += [(x, 8, y[1]) for x in range(6, 26)] + [(x, 7, y[1]) for x in range(8, 24, 3)]
            dec += [(11, 4, y[4]), (12, 4, y[4]), (11, 3, y[4])]
            parts.append(Part({(9, 9), (22, 9)}, "black_h", 55, flat=True))
        elif view == "b":
            dome = spans({2: (12, 19), 3: (10, 21), 4: (9, 22), 5: (8, 23), 6: (8, 23), 7: (8, 23)})
            parts.append(Part(dome, "hat_y", 70, gloss=True))
            parts.append(Part(rect(7, 8, 24, 8), "hat_y", 71, flat=True))
            dec += [(15, yy, y[3]) for yy in range(2, 8)] + [(16, yy, y[1]) for yy in range(2, 8)]
            dec += [(x, 8, y[1]) for x in range(7, 25)] + [(11, 4, y[4]), (12, 3, y[4])]
            parts.append(Part(spans({9: (9, 22), 10: (9, 22), 11: (9, 22), 12: (10, 21), 13: (11, 20)}), "black_h", 60))
            dec += [(12, 10, P["black_h"][3]), (16, 11, P["black_h"][3]), (19, 10, P["black_h"][3])]
        else:
            dome = spans({2: (11, 18), 3: (9, 20), 4: (8, 21), 5: (8, 21), 6: (8, 21), 7: (8, 21)})
            parts.append(Part(dome, "hat_y", 70, gloss=True))
            parts.append(Part(rect(4, 8, 22, 8) | {(4, 9), (5, 9)}, "hat_y", 71, flat=True))
            dec += [(x, 2 + abs(x - 14) // 4, y[3]) for x in range(10, 20)]
            dec += [(x, 8, y[1]) for x in range(6, 23)] + [(10, 4, y[4]), (11, 4, y[4]), (10, 3, y[4])]
            parts.append(Part(spans({9: (19, 21), 10: (19, 21), 11: (19, 21), 12: (19, 20)}), "black_h", 60))
    elif st == "bald":
        s = P[ch.skin]
        stub = (206, 150, 120)
        if view == "f":
            dec += [(11, 5, s[4]), (12, 5, s[4]), (11, 6, s[4]), (12, 4, s[3])]
            dec += [(x, y, stub) for x, y in ((10, 13), (21, 13), (10, 14), (21, 14), (11, 15), (20, 15), (12, 15),
                                              (19, 15), (14, 16), (16, 16), (17, 16), (15, 15), (13, 16), (18, 16))]
            dec += [(15, 6, s[1]), (16, 6, s[1])]   # otsarypy
        elif view == "b":
            dec += [(11, 5, s[4]), (12, 5, s[4]), (11, 6, s[4]), (13, 4, s[3])]
            dec += [(x, 15, s[1]) for x in range(12, 20)] + [(14, 14, s[1]), (17, 14, s[1])]
            # niskapoimu
        else:
            dec += [(11, 5, s[4]), (12, 5, s[4]), (12, 4, s[3]), (11, 6, s[4])]
            dec += [(x, y, stub) for x, y in ((9, 15), (10, 15), (11, 16), (12, 16), (13, 15), (14, 14), (14, 13), (11, 15), (12, 15))]
    elif st == "bob":
        b = P["band"]
        if view == "f":
            px = spans({3: (12, 19), 4: (10, 21), 5: (9, 22), 6: (8, 23), 7: (8, 23), 8: [(8, 12), (14, 17), (19, 23)],
                        9: [(8, 11), (15, 16), (20, 23)]})
            px |= spans({y: [(8, 10), (21, 23)] for y in range(10, 15)}) | spans({15: [(7, 10), (21, 24)]})
            parts.append(Part(px, h, 60))
            parts.append(Part(rect(9, 6, 22, 6) | {(8, 7), (23, 7)}, "band", 63, flat=True))
            dec += [(12, 6, b[3]), (13, 6, b[3]), (19, 6, b[1]), (20, 6, b[1]), (14, 8, R[1]), (17, 8, R[1])]
            dec += hl(4, 11, 14, R[4]) + hl(5, 10, 12, R[3]) + vl(9, 10, 14, R[3]) + vl(22, 10, 14, R[1])
            dec += [(8, 13, P["gold"][3]), (23, 13, P["gold"][3])]      # korvakorut
        elif view == "b":
            px = spans({3: (12, 19), 4: (10, 21), 5: (9, 22)}) | rect(8, 6, 23, 14) | spans({15: (7, 24), 16: [(8, 11), (13, 18), (20, 23)]})
            parts.append(Part(px, h, 60))
            parts.append(Part(rect(8, 6, 23, 6), "band", 63, flat=True))
            dec += hl(4, 12, 14, R[4]) + hl(5, 10, 13, R[3])
            dec += hl(9, 10, 14, R[3]) + hl(9, 17, 21, R[3]) + hl(8, 11, 13, R[4])
            dec += vl(12, 10, 14, R[1]) + vl(16, 7, 14, R[1]) + vl(20, 10, 14, R[1]) + [(16, 6, b[3]), (15, 6, b[1])]
        else:
            px = spans({3: (11, 18), 4: (9, 20), 5: (8, 21), 6: (8, 22), 7: (8, 22), 8: [(8, 10), (13, 22)]})
            px |= rect(14, 9, 22, 14) | spans({15: (14, 23)})
            parts.append(Part(px, h, 60))
            parts.append(Part(rect(9, 6, 21, 6), "band", 63, flat=True))
            dec += hl(4, 10, 13, R[4]) + hl(5, 9, 12, R[3]) + [(11, 6, b[3])]
            dec += hl(9, 15, 19, R[3]) + vl(17, 10, 14, R[1]) + vl(20, 9, 14, R[1])
    elif st == "cap":
        n, k = P["navy"], P["black"]
        if view in "fb":
            crown = spans({2: (11, 20), 3: (9, 22), 4: (8, 23), 5: (8, 23), 6: (8, 23)})
            parts.append(Part(crown, "navy", 70))
            parts.append(Part(rect(9, 7, 22, 7), "black", 71, flat=True))
            dec += [(11, 3, n[3]), (12, 3, n[3]), (10, 4, n[3])] + [(x, 7, k[3]) for x in range(10, 22, 4)]
            if view == "f":
                parts.append(Part(spans({8: (9, 22), 9: (11, 20)}), "black", 72, gloss=True))
                dec += [(x, 8, k[3]) for x in range(11, 19)]
                dec += [(15, 4, P["gold"][3]), (16, 4, P["gold"][2]), (15, 5, P["gold"][2]), (16, 5, P["gold"][1]),
                        (15, 3, P["gold"][4])]
                dec += [(x, 10, P[ch.skin][1]) for x in range(11, 21) if x not in (12, 19)]   # lipan varjo
                parts.append(Part({(9, 9), (22, 9), (9, 10), (22, 10)}, "brown_h", 55, flat=True))
            else:
                parts.append(Part(spans({8: (9, 22), 9: (9, 22), 10: (9, 22), 11: (10, 21), 12: (11, 20)}), "brown_h", 60))
                dec += [(12, 9, P["brown_h"][3]), (17, 10, P["brown_h"][3])]
        else:
            crown = spans({2: (10, 18), 3: (8, 21), 4: (8, 21), 5: (8, 21), 6: (8, 21)})
            parts.append(Part(crown, "navy", 70))
            parts.append(Part(rect(9, 7, 21, 7), "black", 71, flat=True))
            parts.append(Part(spans({8: (5, 12), 9: (5, 9)}), "black", 72, gloss=True))
            dec += [(10, 3, n[3]), (11, 3, n[3]), (9, 4, n[3]), (6, 8, k[3]), (7, 8, k[3])]
            dec += [(10, 4, P["gold"][3]), (10, 5, P["gold"][2]), (11, 5, P["gold"][1])]
            dec += [(10, 9, P[ch.skin][1]), (11, 9, P[ch.skin][1])]
            parts.append(Part(spans({8: (14, 21), 9: (17, 21), 10: (18, 21), 11: (18, 21), 12: (18, 20)}), "brown_h", 60))


# ------------------------------------------------------------------ VAATTEET
def clothes(ch, view, f, parts, dec):
    S = P[ch.shirt]
    pants = P[ch.pants]
    kind = ch.outfit
    if view in "fb":
        dyl = {0: 0, 1: -1, 2: 1}[f]
        # helma ja vyö
        dec += [(x, 24, S[1]) for x in range(11, 21)]
        belt = P["dark"] if kind != "police" else P["black"]
        dec += [(x, 25, belt[2]) for x in range(11, 21)]
        if view == "f":
            dec += [(15, 25, P["silver"][2]), (16, 25, P["silver"][1])]
            # taskut
            dec += [(12, 26, pants[1]), (19, 26, pants[1])]
        else:
            dec += [(13, 26, pants[1]), (18, 26, pants[1]), (12, 27, pants[1]), (19, 27, pants[1])]
        # hihansuun reuna
        if ch.sleeve == "short":
            dec += [(x, 20, S[1]) for x in (8, 9, 10, 21, 22, 23)]
        if view == "f":
            if kind == "tee":
                dec += [(14, 17, P[ch.skin][1]), (15, 17, P[ch.skin][2]), (16, 17, P[ch.skin][2]), (17, 17, P[ch.skin][1]),
                        (15, 18, P[ch.skin][1]), (16, 18, P[ch.skin][1]), (13, 17, S[3]), (18, 17, S[3])]
                if ch.logo:
                    for x, y in ((14, 20), (15, 20), (16, 20), (17, 20), (14, 21), (17, 21), (15, 22), (16, 22)):
                        dec.append((x, y, ch.logo))
                if ch.chain:
                    g = P["gold"]
                    dec += [(13, 18, g[2]), (14, 19, g[3]), (15, 19, g[2]), (16, 19, g[3]), (17, 19, g[2]), (18, 18, g[2]),
                            (15, 20, g[4])]
                dec += [(12, 22, S[1]), (13, 23, S[1]), (19, 21, S[1]), (18, 22, S[1])]   # ryppyjä
            elif kind == "blouse":
                dec += [(13, 17, P[ch.skin][2]), (14, 17, P[ch.skin][2]), (15, 17, P[ch.skin][2]), (16, 17, P[ch.skin][2]),
                        (17, 17, P[ch.skin][2]), (18, 17, P[ch.skin][1]), (14, 18, P[ch.skin][1]), (15, 18, P[ch.skin][2]),
                        (16, 18, P[ch.skin][2]), (17, 18, P[ch.skin][1]), (15, 19, P[ch.skin][1]), (16, 19, P[ch.skin][1])]
                dec += [(13, 18, S[3]), (18, 18, S[3]), (14, 22, S[1]), (17, 22, S[1]), (15, 23, S[3]), (16, 23, S[3])]
                if ch.necklace:
                    dec += [(15, 18, P["gold"][3]), (16, 19, P["gold"][4])]
            elif kind == "shirt":
                dec += [(14, 17, S[4]), (13, 18, S[4]), (17, 17, S[4]), (18, 18, S[4]), (15, 17, P[ch.skin][1]),
                        (16, 17, P[ch.skin][1])]
                dec += [(15, y, S[1]) for y in range(18, 25)]
                dec += [(16, y, (240, 232, 214)) for y in (19, 21, 23)]
                dec += [(12, 19, S[1]), (13, 19, S[1]), (12, 20, S[3]), (19, 22, S[1])]
            elif kind == "vest":
                V = P["hivis"]
                vest = rect(11, 17, 14, 24) | rect(17, 17, 20, 24) - {(14, 17), (17, 17)}
                for x, y in vest:
                    c = V[2] if x in (12, 13, 18, 19) else V[1] if x in (14, 17, 20) else V[3]
                    dec.append((x, y, c))
                dec += [(x, y, P["silver"][3 if y == 21 else 2]) for x in list(range(11, 15)) + list(range(17, 21)) for y in (21, 22)]
                dec += [(15, 17, P[ch.skin][1]), (16, 17, P[ch.skin][1]), (15, 18, S[3]), (16, 19, S[1])]
                dec += [(12, 18, V[4])]
            elif kind == "police":
                B = P["blue"]
                dec += [(14, 17, B[4]), (17, 17, B[4]), (13, 17, B[3]), (18, 17, B[3])]
                tie = P["navy"]
                dec += [(15, 17, tie[2]), (16, 17, tie[2])] + [(15, y, tie[2]) for y in range(18, 24)] + [(16, y, tie[1]) for y in range(18, 24)]
                dec += [(15, 18, tie[3])]
                dec += [(18, 19, P["gold"][3]), (19, 19, P["gold"][2]), (18, 20, P["gold"][2]), (19, 20, P["gold"][1])]
                dec += [(12, 19, B[1]), (13, 19, B[1]), (14, 19, B[1]), (12, 20, B[3]), (13, 20, B[2])]
                dec += [(11, 18, P["black"][2]), (12, 18, P["black"][3]), (11, 19, P["black"][1])]   # radio
                dec += [(8, 19, B[4]), (23, 19, B[1])]   # olkapolet
                dec += [(20, 25, P["black"][3]), (21, 25, P["black"][2]), (20, 26, P["black"][2]), (21, 26, P["black"][1]),
                        (21, 27, P["black"][1])]
                dec += [(x, 26, pants[1]) for x in range(11, 21) if x in (11, 20)]
        else:  # selkä
            dec += hl(18, 13, 18, S[1]) + vl(15, 19, 23, S[1]) + [(12, 19, S[3]), (13, 19, S[3]), (12, 21, S[1]), (19, 21, S[1])]
            if kind == "vest":
                V = P["hivis"]
                for x in range(11, 21):
                    for y in range(17, 25):
                        dec.append((x, y, V[2] if 12 <= x <= 19 else V[1]))
                dec += [(x, y, P["silver"][3 if y == 21 else 2]) for x in range(11, 21) for y in (21, 22)]
                dec += [(x, 17, S[2]) for x in (14, 15, 16, 17)]
            if kind == "police":
                dec += [(x, 17, P["blue"][1]) for x in range(13, 19)]
                dec += [(11, 25, P["black"][3]), (11, 26, P["black"][2]), (10, 26, P["black"][1])]
            if ch.long_back:
                pass
    else:  # sivu
        dec += [(x, 24, S[1]) for x in range(11, 20)]
        belt = P["dark"] if kind != "police" else P["black"]
        dec += [(x, 25, belt[2]) for x in range(12, 19)]
        dec += [(12, 25, P["silver"][2])]
        if ch.sleeve == "short":
            dec += [(x, 20, S[1]) for x in (14, 15, 16)]
        if kind == "tee":
            dec += [(12, 17, P[ch.skin][1]), (11, 18, S[3]), (12, 21, S[1])]
            if ch.chain:
                dec += [(12, 18, P["gold"][3]), (12, 19, P["gold"][2])]
        elif kind == "blouse":
            dec += [(12, 17, P[ch.skin][2]), (12, 18, P[ch.skin][1]), (11, 19, S[3])]
        elif kind == "shirt":
            dec += [(12, 17, S[4]), (11, 18, S[4]), (11, 20, (240, 232, 214)), (11, 22, (240, 232, 214))]
        elif kind == "vest":
            V = P["hivis"]
            for x in range(11, 20):
                for y in range(17, 25):
                    if (x, y) not in ((12, 17),):
                        dec.append((x, y, V[3] if x == 11 else V[2] if x < 18 else V[1]))
            dec += [(x, y, P["silver"][3 if y == 21 else 2]) for x in range(11, 20) for y in (21, 22)]
        elif kind == "police":
            dec += [(12, 17, P["navy"][2]), (11, 18, P["navy"][2]), (11, 19, P["navy"][1]), (12, 19, P["gold"][3]),
                    (12, 20, P["gold"][2])]
            dec += [(17, 25, P["black"][3]), (17, 26, P["black"][2]), (18, 26, P["black"][1]), (17, 27, P["black"][1], True)]
            dec += [(16, 18, P["black"][2]), (17, 18, P["black"][3])]


def frame(ch, col, f, pose=0):
    view = {"left": "s", "down": "f", "up": "b", "right": "s"}[col]
    parts, dec = body(ch, view, f, pose)
    hair(ch, view, parts, dec)
    fdec = []
    face(ch, view, parts, fdec)
    clothes(ch, view, f, parts, dec)
    # kasvojen koristeet piiloon jos hiukset/hattu peittävät kohdan
    top = {}
    for i, pt in enumerate(parts):
        for p in pt.px:
            if p not in top or parts[top[p]].z <= pt.z:
                top[p] = i
    keep = [d for d in fdec if not (top.get((d[0], d[1])) is not None and parts[top[(d[0], d[1])]].z >= 55)]
    keep = keep + dec
    img = render(parts, keep)
    if col == "right":
        img = img.transpose(Image.FLIP_LEFT_RIGHT)
    return img


COLS = ["left", "down", "up", "right"]

NPCS = [
    Char(hair="short", hair_c="ginger", shirt="green", outfit="tee", logo=(236, 236, 214), pants="khaki", shoes="brown",
         iris=(64, 120, 70), chain=False, necklace=False, long_back=False),
    Char(hair="long", hair_c="auburn", shirt="red", outfit="blouse", logo=None, pants="jeans", shoes="wine", female=True,
         iris=(70, 110, 170), chain=False, necklace=True, long_back=True),
    Char(hair="beard", hair_c="grey_h", shirt="orange", outfit="shirt", logo=None, pants="olive", shoes="brown",
         sleeve="long", iris=(90, 100, 130), chain=False, necklace=False, long_back=False),
    Char(hair="hat", hair_c="black_h", skin="skin_d", shirt="work", outfit="vest", logo=None, pants="work", shoes="brown",
         sleeve="long", iris=(60, 40, 30), chain=False, necklace=False, long_back=False),
    Char(hair="bald", hair_c="brown_h", skin="skin", shirt="tee", outfit="tee", logo=None, pants="dark", shoes="white",
         iris=(60, 90, 120), chain=True, necklace=False, long_back=False),
    Char(hair="bob", hair_c="black_h", skin="skin_t", shirt="peach", outfit="blouse", logo=None, pants="lilac", shoes="dark",
         female=True, iris=(80, 54, 40), chain=False, necklace=False, long_back=False),
]
POLICE = Char(hair="cap", hair_c="brown_h", shirt="blue", outfit="police", logo=None, pants="navy", shoes="black",
              iris=(60, 80, 120), chain=False, necklace=False, long_back=False)


def sheet(chars, sep):
    rows = len(chars) * 3
    stride = N + sep
    img = Image.new("RGBA", (4 * stride - sep, rows * stride - sep), (0, 0, 0, 0))
    for ci, ch in enumerate(chars):
        for f in range(3):
            for c, col in enumerate(COLS):
                img.alpha_composite(frame(ch, col, f), (c * stride, (ci * 3 + f) * stride))
    return img


if __name__ == "__main__":
    root = sys.argv[1] if len(sys.argv) > 1 else "."
    a = sheet(NPCS, 0)
    b = sheet([POLICE], 0)
    a.save(os.path.join(root, "assets/sprites/player/characters_hd.png"))
    # pelaajan (tyyppi 4) aseasennot: rivit 0-2 yksi käsi, 3-5 kaksi kättä
    pl = Image.new("RGBA", (4 * N, 6 * N), (0, 0, 0, 0))
    for pose in (1, 2):
        for f in range(3):
            for c, col in enumerate(COLS):
                pl.alpha_composite(frame(NPCS[4], col, f, pose), (c * N, ((pose - 1) * 3 + f) * N))
    pl.save(os.path.join(root, "assets/sprites/player/player_armed_hd.png"))
    b.save(os.path.join(root, "assets/sprites/police/police_officer_hd.png"))
    print("ok", a.size, b.size)
