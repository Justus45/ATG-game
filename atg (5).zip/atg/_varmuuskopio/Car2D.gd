extends CharacterBody2D

@export var speed: float = 250.0 # Auton ajonopeus
var driver: CharacterBody2D = null
var is_driving: bool = false
var exit_cooldown: float = 0.0
## true = auto kuuluu jollekin muulle (esim. parkkipaikan auto): ensimmäinen
## sisään nouseminen on auton varastus ja nostaa etsintäkuulutuksen.
var is_npc_owned: bool = false
var _drunk_t := 0.0

const CarFXScript := preload("res://scripts/entities/CarFX.gd")

# --- Kolarit ja vauriot. SÄÄDÄ NÄITÄ ---
const MAX_HEALTH := 100.0
const CRASH_MIN_SPEED := 70.0      ## tätä hitaampi kosketus (px/s törmäyssuunnassa) ei ole kolari
const CRASH_DAMAGE := 0.11         ## vahinko / (px/s) kynnyksen yli
const BOUNCE := 0.35               ## kuinka paljon auto kimpoaa takaisin (0 = ei lainkaan)
const KNOCK_FRICTION := 420.0      ## kuinka nopeasti töytäisy hiipuu (px/s²)
const SMOKE_BELOW := 0.5           ## alle tämän kunnon (osuus) konepelti savuaa

var health := MAX_HEALTH
var wrecked := false
## Ulkoinen töytäisy (kolari, poliisin rammaus): lisätään ajonopeuteen ja hiipuu pois
var _knock := Vector2.ZERO
## Kuljettajan tavoittelema nopeus (ohjauksesta), ilman töytäisyjä
var _drive_vel := Vector2.ZERO
var _crash_cd := 0.0
var _knock_cd := 0.0
var _crash_t := 0.0                # > 0: ohjaus ei pure hetkeen kolarin jälkeen
var _smoke_acc := 0.0

## Törmäysmuoto käännetään auton suunnan mukaan (vaaka / pysty)
var _shape: RectangleShape2D
var _vertical := false

@onready var interaction_area: Area2D = $InteractionArea
@onready var exit_point: Marker2D = $ExitPoint
@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var collision: CollisionShape2D = $CollisionShape2D

func _ready() -> void:
	add_to_group("player_vehicles")
	add_child(CarFXScript.new())  # pyörivät renkaat + pakokaasu
	interaction_area.body_entered.connect(_on_body_entered)
	interaction_area.body_exited.connect(_on_body_exited)
	# Jokaisella autolla oma muoto (scenen muoto on jaettu kaikkien autojen kesken)
	_shape = (collision.shape as RectangleShape2D).duplicate()
	collision.shape = _shape
	_apply_shape(_is_vertical_anim(animated_sprite.animation), true)

func _physics_process(delta: float) -> void:
	_crash_cd = maxf(_crash_cd - delta, 0.0)
	_knock_cd = maxf(_knock_cd - delta, 0.0)
	_crash_t = maxf(_crash_t - delta, 0.0)
	_knock = _knock.move_toward(Vector2.ZERO, KNOCK_FRICTION * delta)
	_smoke(delta)
	# Pysäköidyn auton kuva voidaan vaihtaa ulkopuolelta (kaupungin generointi): muoto perässä
	if _is_vertical_anim(animated_sprite.animation) != _vertical:
		if not _apply_shape(not _vertical):
			animated_sprite.animation = &"car_down" if _vertical else &"car_right"

	if not is_driving:
		if animated_sprite:
			animated_sprite.stop()
		_drive_vel = Vector2.ZERO
		# Tönäisty pysäköity auto liukuu hetken
		if _knock.length() > 2.0:
			_move_with_crashes(_knock)
		else:
			velocity = Vector2.ZERO
		return

	if exit_cooldown > 0:
		exit_cooldown -= delta

	# Poliisi pysäyttänyt: auto seisoo, ei ajoa eikä poistuta
	if driver and driver.get("police_locked"):
		velocity = Vector2.ZERO
		_drive_vel = Vector2.ZERO
		animated_sprite.stop()
		return

	# Otetaan liikesuunta WASD / nuolinäppäimistä suoraan
	var input_vector := Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	if wrecked:
		input_vector = Vector2.ZERO
	_drive_vel = _drunk_velocity(input_vector, delta)
	# Kolarin jälkeen ohjaus ei pure hetkeen
	if _crash_t > 0.0:
		_drive_vel *= 0.25
	_move_with_crashes(_drive_vel + _knock)

	# Vaihdetaan auton animaatiota liikesuunnan mukaan (kuten pelaajalla)
	if input_vector != Vector2.ZERO:
		var anim := &"car_down"
		if abs(input_vector.x) > abs(input_vector.y):
			anim = &"car_left" if input_vector.x < 0 else &"car_right"
		elif input_vector.y < 0:
			anim = &"car_up"
		# Käännös vaaka <-> pysty vain, jos käännetty auto mahtuu (ei jumiudu seinään)
		if _is_vertical_anim(anim) == _vertical or _apply_shape(_is_vertical_anim(anim)):
			animated_sprite.play(anim)
		else:
			animated_sprite.play()
	else:
		animated_sprite.stop() # Pysähtyy kun ei paineta mitään

	# Autosta poistuminen E-näppäimellä
	if Input.is_action_just_pressed("interact") and exit_cooldown <= 0:
		exit_car()

## Liikkuu ja tunnistaa kolarit seiniin ja muihin autoihin.
func _move_with_crashes(vel: Vector2) -> void:
	velocity = vel
	var pre := vel
	move_and_slide()
	for i in get_slide_collision_count():
		var col := get_slide_collision(i)
		var n := col.get_normal()
		var impact := -pre.dot(n)     # nopeus kohti estettä
		var other := col.get_collider()
		if other is CharacterBody2D and other.has_method("apply_knock"):
			# Toinen pelaajan/pysäköity auto: osa vauhdista siirtyy siihen
			var rel: Vector2 = pre - (other as CharacterBody2D).velocity
			impact = -rel.dot(n)
			if impact > CRASH_MIN_SPEED * 0.6:
				other.apply_knock(-n * impact * 0.6, impact)
		if impact > CRASH_MIN_SPEED:
			crash(impact, n, other)
			break

## Kolari: kimpoaminen, vauriot, ääni, kipinät ja kameran tärähdys.
## normal osoittaa esteestä poispäin (kohti tätä autoa).
func crash(impact: float, normal: Vector2, _other: Object = null) -> void:
	if _crash_cd > 0.0:
		return
	_crash_cd = 0.3
	var hard := clampf((impact - CRASH_MIN_SPEED) / 220.0, 0.0, 1.0)
	_knock = normal * impact * BOUNCE + _knock.slide(normal)
	_drive_vel = _drive_vel.slide(normal) * 0.5
	velocity = _drive_vel + _knock
	_crash_t = lerpf(0.15, 0.55, hard)
	take_hit((impact - CRASH_MIN_SPEED) * CRASH_DAMAGE)
	var at := global_position - normal * 9.0
	Sfx.play("crash", at, lerpf(-8.0, 2.0, hard), 0.12, lerpf(1.25, 0.85, hard))
	_sparks(at, normal, int(lerpf(5.0, 16.0, hard)))
	# Kori nytkähtää
	var tw := create_tween()
	tw.tween_property(animated_sprite, "rotation", randf_range(-0.12, 0.12) * (0.4 + hard), 0.05)
	tw.tween_property(animated_sprite, "rotation", 0.0, 0.25).set_trans(Tween.TRANS_ELASTIC).set_ease(Tween.EASE_OUT)
	if is_driving:
		var cam := get_viewport().get_camera_2d()
		if cam and cam.has_method("shake"):
			cam.shake(lerpf(1.5, 6.0, hard))

## Ulkoinen töytäisy (toinen auto törmää tähän). impact = törmäysnopeus.
func apply_knock(impulse: Vector2, impact: float = 0.0) -> void:
	if _knock_cd > 0.0:
		return
	_knock_cd = 0.25
	_knock += impulse
	if impact > CRASH_MIN_SPEED:
		take_hit((impact - CRASH_MIN_SPEED) * CRASH_DAMAGE * 0.8)
		if not is_driving:
			Sfx.play("crash", global_position, -6.0, 0.12)
			_sparks(global_position, impulse.normalized(), 6)

## Vahinkoa autolle. Romuksi ajettu auto ei enää liiku.
func take_hit(amount: float) -> void:
	if amount <= 0.0 or wrecked:
		return
	health = maxf(health - amount, 0.0)
	animated_sprite.modulate = Color(1.0, 1.0, 1.0).lerp(Color(0.55, 0.5, 0.48), 1.0 - health / MAX_HEALTH)
	if health <= 0.0:
		wrecked = true
		Sfx.play("glass_break", global_position, 0.0, 0.05)
		if is_driving:
			_hud_message("Auto ajettiin romuksi! Paina E noustaksesi ulos.", 3.0)

## Ammus osuu autoon (luodit kutsuvat body_entered -> take_damage).
func take_damage(amount: int = 1, _source: Node = null) -> void:
	take_hit(float(amount) * 4.0)

## Voiko autoon nousta?
func can_enter() -> bool:
	return not wrecked

## Auton törmäyslaatikko maailmassa (Impacts käyttää jalankulkijoihin osumiseen).
func hit_rect() -> Rect2:
	var sz := _shape.size
	return Rect2(collision.global_position - sz * 0.5, sz)

func is_vertical() -> bool:
	return _vertical

func _is_vertical_anim(anim: StringName) -> bool:
	return anim == &"car_up" or anim == &"car_down"

## Muoto auton kuvan mukaan. Palauttaa false, jos käännetty muoto ei mahdu (seinä tiellä).
func _apply_shape(vertical: bool, force: bool = false) -> bool:
	if vertical == _vertical and not force:
		return true
	var anim := &"car_down" if vertical else &"car_right"
	var tex: Texture2D = null
	if animated_sprite.sprite_frames and animated_sprite.sprite_frames.has_animation(anim):
		tex = animated_sprite.sprite_frames.get_frame_texture(anim, 0)
	var tex_size := tex.get_size() if tex else (Vector2(16, 21) if vertical else Vector2(23, 16))
	# Kuvassa on ohut ääriviiva ja katon perspektiivi: muoto hieman kuvaa pienempi
	var new_size := Vector2(maxf(tex_size.x - 2.0, 8.0), maxf(tex_size.y - (3.0 if vertical else 4.0), 8.0))
	var new_pos := Vector2(0.0, 0.5 if vertical else 1.0)
	if not force and is_inside_tree():
		var test := RectangleShape2D.new()
		test.size = new_size
		var q := PhysicsShapeQueryParameters2D.new()
		q.shape = test
		q.transform = Transform2D(0.0, global_position + new_pos)
		q.collision_mask = collision_mask
		var excl: Array[RID] = [get_rid()]
		if driver:
			excl.append(driver.get_rid())
		q.exclude = excl
		if not get_world_2d().direct_space_state.intersect_shape(q, 1).is_empty():
			return false
	_shape.size = new_size
	collision.position = new_pos
	_vertical = vertical
	return true

## Humalainen kuljettaja ajaa mutkitellen ja ohjaus reagoi hitaasti.
func _drunk_velocity(input_vector: Vector2, delta: float) -> Vector2:
	# Sää: sade ja lumi hidastavat ja tekevät tiestä liukkaan (auto liukuu)
	var wanted := input_vector * speed * Game.car_speed_mult()
	# Vaurioitunut auto kulkee hitaammin
	wanted *= lerpf(0.55, 1.0, health / MAX_HEALTH)
	var grip := Game.road_grip()
	var k := 0.0
	if driver and driver.has_method("drunk_strength"):
		k = driver.drunk_strength()
	if k <= 0.0:
		if grip >= 0.99:
			return wanted
		return _drive_vel.lerp(wanted, clampf(delta * lerpf(2.5, 20.0, grip), 0.0, 1.0))
	_drunk_t += delta
	if input_vector != Vector2.ZERO:
		var ang := (sin(_drunk_t * 1.3) * 0.55 + sin(_drunk_t * 0.45 + 2.0) * 0.45) * 0.8 * k
		wanted = wanted.rotated(ang)
	return _drive_vel.lerp(wanted, clampf(delta * lerpf(20.0, 5.0, k) * maxf(grip, 0.3), 0.0, 1.0))

func drive(player_node: CharacterBody2D) -> void:
	driver = player_node
	is_driving = true
	exit_cooldown = 0.3
	_drive_vel = Vector2.ZERO
	get_tree().call_group("police_manager", "set_player_car", self)
	if is_npc_owned:
		# Auton varastaminen on rikos: 1 tähti
		is_npc_owned = false
		_hud_message("Varastit auton!", 2.5)
		# Varkaus nostaa tähtiä vain, jos poliisi tai joku ohikulkija näki sen
		get_tree().call_group("police_manager", "commit_crime", 1, global_position, null, false)

func exit_car() -> void:
	if not driver: return
	is_driving = false
	_drive_vel = Vector2.ZERO
	velocity = Vector2.ZERO
	var spot := _free_exit_spot(driver)
	driver.global_position = spot
	driver.velocity = Vector2.ZERO
	driver.show()
	driver.set_physics_process(true)
	driver.set_process_unhandled_input(true)
	driver.get_node("CollisionShape2D").disabled = false
	driver = null
	if animated_sprite:
		animated_sprite.stop()

## Etsii auton vierestä paikan, johon kuljettaja mahtuu (ei seinän tai talon sisään).
## Palauttaa pelaajan solmun sijainnin (törmäysmuodon siirtymä huomioituna).
func _free_exit_spot(who: CharacterBody2D) -> Vector2:
	var cs := who.get_node("CollisionShape2D") as CollisionShape2D
	var off := cs.position
	var half := _shape.size * 0.5
	var c := collision.global_position
	var pad := 7.0
	var candidates: Array[Vector2] = [
		c + Vector2(0, -half.y - pad), c + Vector2(0, half.y + pad),
		c + Vector2(-half.x - pad, 0), c + Vector2(half.x + pad, 0),
		c + Vector2(-half.x - pad, -half.y - pad), c + Vector2(half.x + pad, -half.y - pad),
		c + Vector2(-half.x - pad, half.y + pad), c + Vector2(half.x + pad, half.y + pad),
	]
	var q := PhysicsShapeQueryParameters2D.new()
	q.shape = cs.shape
	q.collision_mask = who.collision_mask
	var excl: Array[RID] = [who.get_rid()]
	q.exclude = excl
	var space := get_world_2d().direct_space_state
	for p: Vector2 in candidates:
		q.transform = Transform2D(0.0, p)
		if space.intersect_shape(q, 1).is_empty():
			return p - off
	return exit_point.global_position - off

## Kipinät ja peltiromu kolarikohtaan.
func _sparks(at: Vector2, normal: Vector2, count: int) -> void:
	var parent := get_parent()
	if parent == null:
		return
	for i in count:
		var s := Polygon2D.new()
		var r := randf_range(0.6, 1.4)
		s.polygon = PackedVector2Array([Vector2(-r, -r), Vector2(r, -r), Vector2(r, r), Vector2(-r, r)])
		s.color = [Color(1.0, 0.85, 0.3), Color(1.0, 0.6, 0.15), Color(0.75, 0.75, 0.8)][randi() % 3]
		s.z_index = 4000
		parent.add_child(s)
		s.global_position = at
		var dir := (normal + Vector2.from_angle(randf() * TAU) * 0.9).normalized()
		var tw := s.create_tween()
		tw.tween_property(s, "global_position", at + dir * randf_range(8.0, 26.0), randf_range(0.2, 0.4)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_QUAD)
		tw.parallel().tween_property(s, "modulate:a", 0.0, 0.4)
		tw.tween_callback(s.queue_free)

## Vaurioitunut auto savuaa konepellistä; romu savuaa mustana.
func _smoke(delta: float) -> void:
	if health / MAX_HEALTH > SMOKE_BELOW:
		return
	var k := 1.0 - health / MAX_HEALTH
	_smoke_acc += delta * lerpf(3.0, 14.0, k)
	while _smoke_acc >= 1.0:
		_smoke_acc -= 1.0
		var p := Polygon2D.new()
		var r := randf_range(1.5, 3.0)
		var pts := PackedVector2Array()
		for j in 6:
			pts.append(Vector2.from_angle(j * TAU / 6.0) * r)
		p.polygon = pts
		var g := 0.25 if wrecked else lerpf(0.75, 0.4, k)
		p.color = Color(g, g, g, 0.7)
		p.z_index = 4001
		get_parent().add_child(p)
		var start := global_position + Vector2(randf_range(-4.0, 4.0), -6.0)
		p.global_position = start
		var tw := p.create_tween()
		var drift := Vector2(Game.wind * 14.0 + randf_range(-4.0, 4.0), randf_range(-22.0, -14.0))
		tw.tween_property(p, "global_position", start + drift, 1.1)
		tw.parallel().tween_property(p, "scale", Vector2(2.4, 2.4), 1.1)
		tw.parallel().tween_property(p, "modulate:a", 0.0, 1.1)
		tw.tween_callback(p.queue_free)

func _hud_message(text: String, seconds: float) -> void:
	var hud_node := get_tree().current_scene.get_node_or_null("Hud")
	if hud_node and hud_node.has_method("show_message"):
		hud_node.show_message(text, seconds)

func _on_body_entered(body: Node2D) -> void:
	if body.has_method("enter_car"):
		body.current_car = self
		var main_level = get_tree().current_scene
		var hud_node = main_level.get_node_or_null("Hud")
		if hud_node:
			hud_node.show_instruction("Auto on romuna" if wrecked else "Paina E noustaksesi autoon")

func _on_body_exited(body: Node2D) -> void:
	if body.has_method("enter_car") and body.current_car == self:
		body.current_car = null
		var main_level = get_tree().current_scene
		var hud_node = main_level.get_node_or_null("Hud")
		if hud_node:
			hud_node.hide_instruction()
