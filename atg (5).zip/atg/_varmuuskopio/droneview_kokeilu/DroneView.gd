extends Node
## DroneView: 3D-dronenäkymä ATG:n 2D-pelille (autoload).
##
## Pelilogiikka pyörii ennallaan 2D:nä (fysiikka, tekoäly, poliisit, HUD, sisätilat).
## Tämä skripti piirtää saman maailman 3D:nä viistosti ylhäältä, kuin drooni kuvaisi:
##  - Maa: 2D-maailma renderöidään SubViewportiin (jaettu World2D) ja kuva levitetään
##    3D-maatasolle. Tiet, merkinnät, veri, kolikot, yön sävytys ja katuvalot tulevat
##    siis suoraan 2D-pelistä.
##  - Talot: city_generator.gd:n tontit (building_lots) nostetaan laatikoiksi. Katto ja
##    julkisivu (ikkunat, ovet) otetaan samasta maakuvasta, sivuseinät seinätiilestä.
##  - Hahmot (pelaaja, jalankulkijat, poliisit, roistot, baarin asiakkaat): pystyssä
##    seisovat sprite-kortit. Kuollut hahmo jää maahan makaamaan 2D-kuvana.
##  - Autot: laatikko, jonka katolla on auton 2D-kuva.
## 2D-hahmot ja -autot piilotetaan maakuvasta visibility_layer-bitillä, jottei niistä
## jää maahan litteää kopiota.
##
## Näppäimet: F3 = 3D päälle/pois, F4 = kamerakulma, hiiren rulla = zoomi.
## Tähtäys: HeldWeapon.gd kysyy hiiren maailmanpisteen mouse_world():lta.

# ----------------------------------------------------------------------------
#  SÄÄDÖT
# ----------------------------------------------------------------------------
## Aloitetaanko 3D-näkymässä (F3 vaihtaa)
@export var start_active := true
## Kamerakulmat asteina vaakatasosta (F4 kiertää). 90 = suoraan ylhäältä.
const PITCH_PRESETS := [58.0, 72.0, 45.0]
## Kameran pystysuora näkökenttä
@export var fov_deg := 40.0
## Korkeuskerroin: yksi julkisivurivi (16 px) on näin monta yksikköä korkea.
## > 1 saa talot ja hahmot näyttämään yhtä korkeilta kuin 2D:ssä.
@export var height_scale := 1.5
## Talojen lisäkerrokset (julkisivun 2 rivin päälle): satunnaisesti 0..max
@export var max_extra_floors := 2
## Maakuvan resoluutio ja tarkkuus (tekseliä per 2D-pikseli). 2560 / 2 = 80 tiiltä.
@export var ground_tex_size := 2560
@export var ground_texels_per_px := 2.0
## Kuinka kaukana (tiiliä) olevia hahmoja/autoja piirretään
@export var proxy_cull_tiles := 60.0
## Seinät läpinäkyviksi pelaajan edessä (ruudun korkeuden osuutena)
@export var xray_radius := 0.11

const PX := 16.0          ## 2D-pikseliä per 3D-yksikkö (1 tiili = 1 yksikkö)
const HIDE_LAYER := 2     ## visibility_layer: näkyy pääikkunassa, ei maakuvassa (maski 1)
const CAR_H := 0.42       ## auton korin korkeus (kerrotaan height_scalella)
const AIM_H := 0.6        ## tähtäystason korkeus (hahmon keskikohta)
const BULLET_DROP := 6.0  ## luoti lentää näin monta px "ilmassa" (käden korkeus)

enum Kind { PERSON, ATTACHED, CAR, FLOAT }

const GROUND_SHADER := """
shader_type spatial;
render_mode unshaded, cull_disabled, shadows_disabled;
uniform sampler2D ground_tex : source_color, filter_nearest, repeat_disable;
uniform vec4 ground_rect = vec4(0.0, 0.0, 1.0, 1.0);
uniform vec4 fallback : source_color = vec4(0.2, 0.28, 0.2, 1.0);
varying vec3 wpos;
void vertex() {
	wpos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}
void fragment() {
	vec2 px = wpos.xz * 16.0;
	vec2 uv = (px - ground_rect.xy) / ground_rect.zw;
	vec3 c = texture(ground_tex, clamp(uv, vec2(0.0), vec2(1.0))).rgb;
	vec2 e = min(uv, vec2(1.0) - uv);
	float k = smoothstep(0.0, 0.05, min(e.x, e.y));
	ALBEDO = mix(fallback.rgb, c, k);
}
"""

const BUILDING_SHADER := """
shader_type spatial;
render_mode unshaded, cull_disabled, shadows_disabled;
uniform sampler2D ground_tex : source_color, filter_nearest, repeat_disable;
uniform sampler2D atlas_tex : source_color, filter_nearest;
uniform vec4 ground_rect = vec4(0.0, 0.0, 1.0, 1.0);
uniform vec4 wall_region = vec4(0.0, 0.0, 0.01, 0.01);
uniform vec4 sky : source_color = vec4(1.0);
uniform vec4 fallback : source_color = vec4(0.55, 0.5, 0.47, 1.0);
uniform vec3 player_pos = vec3(0.0, -1000.0, 0.0);
uniform vec2 player_uv = vec2(-10.0, -10.0);
uniform float xray_radius = 0.11;
varying vec4 region;
varying vec3 wpos;
void vertex() {
	region = CUSTOM0;
	wpos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}
void fragment() {
	vec2 f = clamp(fract(UV), vec2(0.0), vec2(0.9999));
	vec3 c;
	if (region.w < 0.0) {
		c = texture(atlas_tex, wall_region.xy + f * wall_region.zw).rgb * sky.rgb;
	} else {
		vec2 px = region.xy + f * region.zw;
		vec2 uv = (px - ground_rect.xy) / ground_rect.zw;
		if (uv.x < 0.0 || uv.y < 0.0 || uv.x > 1.0 || uv.y > 1.0) {
			c = fallback.rgb * sky.rgb;
		} else {
			c = texture(ground_tex, uv).rgb;
		}
	}
	ALBEDO = c * COLOR.rgb;
	// Pelaajan edessä (kameran puolella) olevat seinät harvennetaan, ettei pelaaja katoa talon taakse
	if (wpos.z > player_pos.z + 0.05 && wpos.y > 0.05) {
		vec2 d = (SCREEN_UV - player_uv) * vec2(VIEWPORT_SIZE.x / VIEWPORT_SIZE.y, 1.0);
		if (length(d) < xray_radius) {
			ivec2 fc = ivec2(FRAGCOORD.xy);
			if (((fc.x + fc.y) & 1) == 0) {
				discard;
			}
		}
	}
}
"""

# ----------------------------------------------------------------------------
#  TILA
# ----------------------------------------------------------------------------
var active := true
var zoom_mult := 1.0

var _scene: Node = null
var _city: Node = null
var _cam2d: Camera2D = null
var _root: Node = null
var _layer: CanvasLayer
var _rect: TextureRect
var _vp3d: SubViewport
var _ground_vp: SubViewport
var _world: Node3D
var _cam3d: Camera3D
var _env: Environment
var _ground_mat: ShaderMaterial
var _bld_mat: ShaderMaterial
var _world_canvas := RID()
var _ground_rect := Rect2(0, 0, 1, 1)
var _sky := Color.WHITE
var _modulate_node: CanvasModulate = null
var _preset := 0
var _pitch := 58.0
var _zoom_s := 1.0

var _proxies: Array = []          # Proxy
var _known := {}                  # sprite instance id -> true
var _pending: Array = []          # [sprite, yrityksiä jäljellä]
var _tex_cache := {}              # texture instance id -> {used: Rect2, avg: Color}


class Proxy:
	var kind := 0
	var spr = null                # Sprite2D / AnimatedSprite2D
	var body = null               # ATTACHED: omistajan vartalo-sprite (jalkojen paikka)
	var node: Node3D
	var s3: Sprite3D
	var top: MeshInstance3D
	var box: MeshInstance3D
	var top_mat: StandardMaterial3D
	var box_mat: StandardMaterial3D
	var tex: Texture2D = null
	var avg := Color(0.5, 0.5, 0.5)


# ----------------------------------------------------------------------------
#  ELINKAARI
# ----------------------------------------------------------------------------
func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	active = start_active
	_pitch = PITCH_PRESETS[0]
	_add_key("toggle_3d", KEY_F3)
	_add_key("camera_angle", KEY_F4)
	get_tree().node_added.connect(_on_node_added)


func _add_key(action: String, key: Key) -> void:
	if InputMap.has_action(action):
		return
	InputMap.add_action(action)
	var ev := InputEventKey.new()
	ev.physical_keycode = key
	InputMap.action_add_event(action, ev)


## Onko 3D-näkymä käytössä (HeldWeapon kysyy tätä tähtäystä varten)
func is_active() -> bool:
	return active and _cam3d != null and is_instance_valid(_cam3d)


func set_active(v: bool) -> void:
	active = v
	if _layer:
		_layer.visible = v
	var mode := SubViewport.UPDATE_ALWAYS if v else SubViewport.UPDATE_DISABLED
	if _vp3d:
		_vp3d.render_target_update_mode = mode
	if _ground_vp:
		_ground_vp.render_target_update_mode = mode


func _input(event: InputEvent) -> void:
	if _scene == null:
		return
	if event.is_action_pressed("toggle_3d"):
		set_active(not active)
		_msg("3D-dronenäkymä " + ("päällä" if active else "pois") + " (F3)")
	elif not active:
		return
	elif event.is_action_pressed("camera_angle"):
		_preset = (_preset + 1) % PITCH_PRESETS.size()
		_msg("Kamerakulma %d° (F4)" % int(PITCH_PRESETS[_preset]))
	elif event is InputEventMouseButton and (event as InputEventMouseButton).pressed:
		var mb := event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_WHEEL_UP:
			zoom_mult = clampf(zoom_mult * 0.9, 0.5, 2.5)
		elif mb.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			zoom_mult = clampf(zoom_mult * 1.1, 0.5, 2.5)


func _msg(text: String) -> void:
	var g := get_node_or_null("/root/Game")
	if g and g.has_method("msg"):
		g.msg(text, 1.8)


func _on_node_added(n: Node) -> void:
	if _scene != null and (n is Sprite2D or n is AnimatedSprite2D):
		_pending.append([n, 3])


func _process(delta: float) -> void:
	var scene := get_tree().current_scene
	var ok := scene != null and scene.get_node_or_null("City") != null \
		and scene.get_node_or_null("Camera2D") is Camera2D
	if not ok:
		if _root != null:
			_teardown()
		return
	if scene != _scene:
		_attach(scene)
	if not active:
		return
	_update(delta)


# ----------------------------------------------------------------------------
#  RAKENNUS
# ----------------------------------------------------------------------------
func _teardown() -> void:
	if _root and is_instance_valid(_root):
		_root.queue_free()
	_root = null
	_scene = null
	_city = null
	_cam2d = null
	_cam3d = null
	_vp3d = null
	_ground_vp = null
	_layer = null
	_modulate_node = null
	_proxies.clear()
	_known.clear()
	_pending.clear()
	_tex_cache.clear()


func _attach(scene: Node) -> void:
	_teardown()
	_scene = scene
	_city = scene.get_node("City")
	_cam2d = scene.get_node("Camera2D") as Camera2D
	_world_canvas = get_tree().root.world_2d.canvas
	_root = Node.new()
	_root.name = "DroneView3D"
	add_child(_root)

	# Näyttökerros ensimmäiseksi: kerros 1, järjestysindeksi 0 -> piirtyy maailman päälle
	# mutta Atmosphere-kerroksen (sade, sumu, lumi; myös kerros 1) ja HUD:n alle.
	_layer = CanvasLayer.new()
	_layer.name = "DroneLayer"
	_layer.layer = 1
	_root.add_child(_layer)

	_vp3d = SubViewport.new()
	_vp3d.name = "View3D"
	_vp3d.own_world_3d = true
	_vp3d.msaa_3d = Viewport.MSAA_2X
	_vp3d.size = _window_size()
	_vp3d.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	_root.add_child(_vp3d)

	_rect = TextureRect.new()
	_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_rect.stretch_mode = TextureRect.STRETCH_SCALE
	_layer.add_child(_rect)
	_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	_rect.texture = _vp3d.get_texture()

	# Maakuva: sama 2D-maailma omalla "kameralla" (canvas_transform), ilman hahmoja/autoja
	_ground_vp = SubViewport.new()
	_ground_vp.name = "Ground2D"
	_ground_vp.size = Vector2i(ground_tex_size, ground_tex_size)
	_ground_vp.world_2d = get_tree().root.world_2d
	_ground_vp.canvas_cull_mask = 1
	_ground_vp.disable_3d = true
	_ground_vp.transparent_bg = false
	_ground_vp.canvas_item_default_texture_filter = Viewport.DEFAULT_CANVAS_ITEM_TEXTURE_FILTER_NEAREST
	_ground_vp.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	_root.add_child(_ground_vp)

	_world = Node3D.new()
	_world.name = "World3D"
	_vp3d.add_child(_world)

	var we := WorldEnvironment.new()
	_env = Environment.new()
	_env.background_mode = Environment.BG_COLOR
	_env.background_color = Color(0.12, 0.14, 0.12)
	_env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	_env.ambient_light_color = Color.WHITE
	_env.tonemap_mode = Environment.TONE_MAPPER_LINEAR
	we.environment = _env
	_world.add_child(we)

	_cam3d = Camera3D.new()
	_cam3d.fov = fov_deg
	_cam3d.near = 0.3
	_cam3d.far = 500.0
	_world.add_child(_cam3d)
	_cam3d.make_current()

	_build_ground()
	_build_buildings()
	_scan(scene)
	set_active(active)


func _window_size() -> Vector2i:
	var s := get_window().size
	return Vector2i(maxi(s.x, 16), maxi(s.y, 16))


func _build_ground() -> void:
	var sh := Shader.new()
	sh.code = GROUND_SHADER
	_ground_mat = ShaderMaterial.new()
	_ground_mat.shader = sh
	_ground_mat.set_shader_parameter("ground_tex", _ground_vp.get_texture())

	var r := Rect2(0, 0, 4096, 4096)
	if _city.has_method("world_rect"):
		r = _city.world_rect()
	var pm := PlaneMesh.new()
	pm.size = r.size / PX + Vector2(200, 200)
	var mi := MeshInstance3D.new()
	mi.name = "Ground"
	mi.mesh = pm
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mi.material_override = _ground_mat
	mi.position = Vector3(r.get_center().x / PX, 0.0, r.get_center().y / PX)
	_world.add_child(mi)


## Nostaa city_generatorin tontit laatikoiksi. Yksi ArrayMesh koko kaupungille.
func _build_buildings() -> void:
	var sh := Shader.new()
	sh.code = BUILDING_SHADER
	_bld_mat = ShaderMaterial.new()
	_bld_mat.shader = sh
	_bld_mat.set_shader_parameter("ground_tex", _ground_vp.get_texture())
	_bld_mat.set_shader_parameter("xray_radius", xray_radius)

	# Sivuseinien tiili tilemapista (city_generator.WALL)
	var layer := _city.get("ground_layer") as TileMapLayer
	if layer and layer.tile_set:
		var src := layer.tile_set.get_source(int(_city.get("source_id"))) as TileSetAtlasSource
		if src and src.texture:
			var ts := src.texture.get_size()
			var stride := float(_city.get("stride"))
			var wall: Vector2i = CityGenerator.WALL
			var t0 := float(_city.get("tile"))
			_bld_mat.set_shader_parameter("atlas_tex", src.texture)
			_bld_mat.set_shader_parameter("wall_region", Vector4(
				wall.x * stride / ts.x, wall.y * stride / ts.y, t0 / ts.x, t0 / ts.y))

	var lots = _city.get("building_lots")
	if lots == null or (lots as Array).is_empty():
		push_warning("DroneView: city_generator ei antanut building_lots-listaa, taloja ei nosteta 3D:ksi.")
		return

	var t := float(_city.get("tile"))
	var g0: Vector2 = _city.cell_to_world(Vector2i.ZERO) - Vector2(t, t) * 0.5
	var hs := height_scale
	const E := 0.999
	var wall_r := Color(0.0, 0.0, 0.0, -1.0)

	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	st.set_custom_format(0, SurfaceTool.CUSTOM_RGBA_FLOAT)
	for b in lots:
		var lot: Rect2i = b["lot"]
		var fy: int = b["fy"]
		var landmark: bool = b.get("landmark", false)
		var hv := absi(hash(lot.position))
		var extra := 1 if landmark else hv % (max_extra_floors + 1)
		if fy < 0:
			extra = mini(extra, 1)
		var rows := 2 + extra
		var h := rows * hs
		var p0 := g0 + Vector2(lot.position) * t
		var p1 := g0 + Vector2(lot.end) * t
		var x0 := p0.x / PX
		var x1 := p1.x / PX
		var z0 := p0.y / PX
		var z1 := p1.y / PX
		var wpx := p1.x - p0.x
		var wt := float(lot.size.x)
		var dt := float(lot.size.y)

		# Katto: 2D:n kattoalue venytetään koko tontin päälle
		var roof := Color(p0.x, p0.y, wpx, float(fy - lot.position.y) * t) if fy >= 0 \
			else Color(p0.x, p0.y, wpx, p1.y - p0.y)
		_quad(st, [Vector3(x0, h, z0), Vector3(x1, h, z0), Vector3(x1, h, z1), Vector3(x0, h, z1)],
			[Vector2(0, 0), Vector2(E, 0), Vector2(E, E), Vector2(0, E)], roof, 1.0)

		# Etuseinä (etelä, kameraan päin): 2D-julkisivu, ylemmät kerrokset ikkunarivistä
		if fy >= 0:
			var fpy := g0.y + fy * t
			var h2 := 2.0 * hs
			_quad(st, [Vector3(x0, h2, z1), Vector3(x1, h2, z1), Vector3(x1, 0, z1), Vector3(x0, 0, z1)],
				[Vector2(0, 0), Vector2(E, 0), Vector2(E, E), Vector2(0, E)],
				Color(p0.x, fpy, wpx, 2.0 * t), 0.96)
			if rows > 2:
				var n := float(rows - 2)
				_quad(st, [Vector3(x0, h, z1), Vector3(x1, h, z1), Vector3(x1, h2, z1), Vector3(x0, h2, z1)],
					[Vector2(0, 0), Vector2(E, 0), Vector2(E, n), Vector2(0, n)],
					Color(p0.x, fpy, wpx, t), 0.96)
		else:
			_quad(st, [Vector3(x0, h, z1), Vector3(x1, h, z1), Vector3(x1, 0, z1), Vector3(x0, 0, z1)],
				[Vector2(0, 0), Vector2(wt, 0), Vector2(wt, rows), Vector2(0, rows)], wall_r, 0.92)

		# Sivut ja takaseinä: tasainen seinätiili
		_quad(st, [Vector3(x1, h, z1), Vector3(x1, h, z0), Vector3(x1, 0, z0), Vector3(x1, 0, z1)],
			[Vector2(0, 0), Vector2(dt, 0), Vector2(dt, rows), Vector2(0, rows)], wall_r, 0.78)
		_quad(st, [Vector3(x0, h, z0), Vector3(x0, h, z1), Vector3(x0, 0, z1), Vector3(x0, 0, z0)],
			[Vector2(0, 0), Vector2(dt, 0), Vector2(dt, rows), Vector2(0, rows)], wall_r, 0.72)
		_quad(st, [Vector3(x1, h, z0), Vector3(x0, h, z0), Vector3(x0, 0, z0), Vector3(x1, 0, z0)],
			[Vector2(0, 0), Vector2(wt, 0), Vector2(wt, rows), Vector2(0, rows)], wall_r, 0.62)

	var mi := MeshInstance3D.new()
	mi.name = "Buildings"
	mi.mesh = st.commit()
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mi.material_override = _bld_mat
	_world.add_child(mi)


func _quad(st: SurfaceTool, v: Array, uv: Array, region: Color, shade: float) -> void:
	var col := Color(shade, shade, shade, 1.0)
	for i: int in [0, 1, 2, 0, 2, 3]:
		st.set_color(col)
		st.set_uv(uv[i])
		st.set_custom(0, region)
		st.add_vertex(v[i])


# ----------------------------------------------------------------------------
#  HAHMOT JA AUTOT (2D-spritejen 3D-vastineet)
# ----------------------------------------------------------------------------
func _scan(n: Node) -> void:
	if n is Sprite2D or n is AnimatedSprite2D:
		_pending.append([n, 3])
	for c in n.get_children():
		_scan(c)


func _process_pending() -> void:
	if _pending.is_empty():
		return
	var again: Array = []
	for e in _pending:
		var s = e[0]
		if not is_instance_valid(s) or not (s as Node).is_inside_tree():
			continue
		var id: int = (s as Object).get_instance_id()
		if _known.has(id):
			continue
		var info := _classify(s)
		if info.is_empty():
			if int(e[1]) > 1:
				again.append([s, int(e[1]) - 1])
			continue
		_known[id] = true
		_proxies.append(_make_proxy(s, info))
	_pending = again


func _script_path(n: Node) -> String:
	var sc = n.get_script()
	return (sc as Script).resource_path if sc is Script else ""


## Mikä 2D-sprite on kyseessä? Palauttaa {} jos spriteä ei korvata 3D:llä.
func _classify(s: Node) -> Dictionary:
	var p := s.get_parent()
	if p == null or not (p is Node2D):
		return {}
	var path := _script_path(p)
	if path.ends_with("HeldWeapon.gd"):
		var owner2 := p.get_parent()
		var body: Node = null
		if owner2:
			body = owner2.get_node_or_null("AnimatedSprite2D")
		if body:
			return {"kind": Kind.ATTACHED, "body": body}
		return {}
	if path.ends_with("Bullet2D.gd"):
		return {"kind": Kind.FLOAT}
	if path.ends_with("WeaponPickup.gd"):
		return {}   # maassa lojuva ase jää maakuvaan
	if p.is_in_group("player"):
		return {"kind": Kind.PERSON} if s.name == "AnimatedSprite2D" else {}
	if p.is_in_group("player_vehicles") or path.ends_with("Car2D.gd"):
		return {"kind": Kind.CAR} if s.name == "AnimatedSprite2D" else {}
	var v = p.get("visual")
	if v != null and v == s:
		return {"kind": Kind.CAR if p.get("is_car") == true else Kind.PERSON}
	var sp = p.get("sprite")
	if sp != null and sp == s:
		return {"kind": Kind.CAR if path.get_file().contains("Car") else Kind.PERSON}
	return {}


func _make_proxy(s, info: Dictionary) -> Proxy:
	var p := Proxy.new()
	p.kind = int(info["kind"])
	p.spr = s
	p.body = info.get("body", null)
	if p.kind == Kind.CAR:
		p.node = Node3D.new()
		p.box = MeshInstance3D.new()
		p.box.mesh = BoxMesh.new()
		p.box_mat = StandardMaterial3D.new()
		p.box_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		p.box_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
		p.box.material_override = p.box_mat
		p.box.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		p.node.add_child(p.box)
		p.top = MeshInstance3D.new()
		p.top.mesh = QuadMesh.new()
		p.top.rotation_degrees = Vector3(-90.0, 0.0, 0.0)
		p.top_mat = StandardMaterial3D.new()
		p.top_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		p.top_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
		p.top_mat.alpha_scissor_threshold = 0.5
		p.top_mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
		p.top_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
		p.top.material_override = p.top_mat
		p.top.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		p.node.add_child(p.top)
	else:
		var s3 := Sprite3D.new()
		s3.pixel_size = 1.0 / PX
		s3.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
		s3.alpha_cut = SpriteBase3D.ALPHA_CUT_DISCARD
		s3.shaded = false
		s3.double_sided = true
		s3.billboard = BaseMaterial3D.BILLBOARD_DISABLED
		s3.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		p.s3 = s3
		p.node = s3
	p.node.visible = false
	_world.add_child(p.node)
	return p


func _tex_of(s) -> Texture2D:
	if s is Sprite2D:
		return (s as Sprite2D).texture
	var a := s as AnimatedSprite2D
	if a == null or a.sprite_frames == null or not a.sprite_frames.has_animation(a.animation):
		return null
	var n := a.sprite_frames.get_frame_count(a.animation)
	if n <= 0:
		return null
	return a.sprite_frames.get_frame_texture(a.animation, clampi(a.frame, 0, n - 1))


## Spriten paikallinen suorakulmio (offset + centered huomioituna)
func _local_rect(s, tex: Texture2D) -> Rect2:
	if s is Sprite2D:
		return (s as Sprite2D).get_rect()
	var a := s as AnimatedSprite2D
	var sz := tex.get_size()
	var pos := a.offset
	if a.centered:
		pos -= sz * 0.5
	return Rect2(pos, sz)


func _modulate_of(s) -> Color:
	var ci := s as CanvasItem
	var m := ci.self_modulate * ci.modulate
	var n := ci.get_parent()
	var depth := 0
	while n is CanvasItem and depth < 6:
		m *= (n as CanvasItem).modulate
		n = n.get_parent()
		depth += 1
	return m


func _set_layer(s, v: int) -> void:
	var ci := s as CanvasItem
	if ci.visibility_layer != v:
		ci.visibility_layer = v


func _tex_info(tex: Texture2D) -> Dictionary:
	var key := tex.get_instance_id()
	if _tex_cache.has(key):
		return _tex_cache[key]
	var info := {"used": Rect2(Vector2.ZERO, tex.get_size()), "avg": Color(0.5, 0.5, 0.5)}
	var img := tex.get_image()
	if img:
		if img.is_compressed():
			img.decompress()
		var u := img.get_used_rect()
		if u.size.x > 0 and u.size.y > 0:
			info["used"] = Rect2(u)
			var sum := Color(0, 0, 0, 0)
			var cnt := 0
			for y in range(u.position.y, u.end.y):
				for x in range(u.position.x, u.end.x):
					var c := img.get_pixel(x, y)
					if c.a > 0.5:
						sum += c
						cnt += 1
			if cnt > 0:
				info["avg"] = Color(sum.r / cnt, sum.g / cnt, sum.b / cnt, 1.0)
	_tex_cache[key] = info
	return info


## Päivittää yhden vastineen. Palauttaa false, jos 2D-sprite on poistunut.
func _update_proxy(p: Proxy, ctr: Vector2, cull2: float, light: Color) -> bool:
	if not is_instance_valid(p.spr):
		if is_instance_valid(p.node):
			p.node.queue_free()
		return false
	var s = p.spr
	var ci := s as CanvasItem
	var n2 := s as Node2D
	if not ci.is_inside_tree() or not ci.is_visible_in_tree() or ci.get_canvas() != _world_canvas \
			or n2.global_position.distance_squared_to(ctr) > cull2:
		p.node.visible = false
		return true
	var tex := _tex_of(s)
	if tex == null:
		p.node.visible = false
		return true
	var gs := n2.global_scale
	var gr := wrapf(n2.global_rotation, -PI, PI)
	var r := _local_rect(s, tex)
	var gp := n2.global_position
	var c := gp + r.get_center() * gs
	var m := _modulate_of(s)

	if p.kind == Kind.CAR:
		_set_layer(s, HIDE_LAYER)
		if tex != p.tex:
			p.tex = tex
			var info := _tex_info(tex)
			var tsz := tex.get_size()
			var qm := p.top.mesh as QuadMesh
			qm.size = tsz / PX
			p.top_mat.albedo_texture = tex
			var used: Rect2 = info["used"]
			var bs := Vector2(maxf(used.size.x - 2.0, 2.0), maxf(used.size.y - 2.0, 2.0)) / PX
			var ch := CAR_H * height_scale
			var bm := p.box.mesh as BoxMesh
			bm.size = Vector3(bs.x, ch, bs.y)
			var uc := (used.get_center() - tsz * 0.5) / PX
			p.box.position = Vector3(uc.x, ch * 0.5, uc.y)
			p.top.position = Vector3(0.0, ch + 0.02, 0.0)
			p.avg = info["avg"]
		var fx := -1.0 if bool(s.flip_h) else 1.0
		var fz := -1.0 if bool(s.flip_v) else 1.0
		p.node.position = Vector3(c.x / PX, 0.0, c.y / PX)
		p.node.rotation = Vector3(0.0, -gr, 0.0)
		p.node.scale = Vector3(gs.x * fx, 1.0, gs.y * fz)
		p.top_mat.albedo_color = Color(m.r * light.r, m.g * light.g, m.b * light.b, 1.0)
		p.box_mat.albedo_color = Color(p.avg.r * m.r * light.r * 0.8, p.avg.g * m.g * light.g * 0.8,
			p.avg.b * m.b * light.b * 0.8, 1.0)
		p.node.visible = true
		return true

	# Hahmot ja niihin kiinnitetyt (ase, suuliekki) sekä luodit: pystysuora kortti
	if p.kind == Kind.PERSON and absf(gr) > 0.5:
		# Makaa maassa (kuollut / kaatunut): näytetään 2D-kuva maassa
		_set_layer(s, 1)
		p.node.visible = false
		return true
	_set_layer(s, HIDE_LAYER)
	var s3 := p.s3
	if s3.texture != tex:
		s3.texture = tex
	if s is Sprite2D:
		var sp := s as Sprite2D
		s3.hframes = sp.hframes
		s3.vframes = sp.vframes
		s3.frame = sp.frame
		s3.region_enabled = sp.region_enabled
		if sp.region_enabled:
			s3.region_rect = sp.region_rect
	s3.flip_h = bool(s.flip_h)
	s3.flip_v = bool(s.flip_v)
	s3.modulate = Color(m.r * light.r, m.g * light.g, m.b * light.b, m.a)
	var hs := height_scale
	match p.kind:
		Kind.PERSON:
			var feet_y := gp.y + r.end.y * gs.y
			s3.position = Vector3(c.x / PX, (feet_y - c.y) / PX * hs, feet_y / PX)
			s3.rotation = Vector3.ZERO
		Kind.ATTACHED:
			if not is_instance_valid(p.body) or not (p.body as CanvasItem).is_visible_in_tree():
				p.node.visible = false
				return true
			var b = p.body
			var bt := _tex_of(b)
			var br := _local_rect(b, bt) if bt else Rect2(-8, -8, 16, 16)
			var bfeet: float = (b as Node2D).global_position.y + br.end.y * (b as Node2D).global_scale.y
			var bias := -0.02 if ci.z_index < 0 else 0.02
			s3.position = Vector3(c.x / PX, (bfeet - c.y) / PX * hs, bfeet / PX + bias)
			s3.rotation = Vector3(0.0, 0.0, -gr)
		Kind.FLOAT:
			s3.position = Vector3(c.x / PX, BULLET_DROP / PX * hs, (c.y + BULLET_DROP) / PX)
			s3.rotation = Vector3(0.0, 0.0, -gr)
	s3.scale = Vector3(gs.x, gs.y * hs, 1.0)
	p.node.visible = true
	return true


# ----------------------------------------------------------------------------
#  PÄIVITYS
# ----------------------------------------------------------------------------
func _focus_point() -> Vector2:
	for car in get_tree().get_nodes_in_group("player_vehicles"):
		if "is_driving" in car and car.is_driving:
			return (car as Node2D).global_position
	var pl := _scene.get_node_or_null("Player") as Node2D
	return pl.global_position if pl else _cam2d.global_position


func _update(delta: float) -> void:
	if not is_instance_valid(_cam2d) or not is_instance_valid(_city):
		return
	var ws := _window_size()
	if _vp3d.size != ws:
		_vp3d.size = ws

	# Yön sävy (Atmosphere luo CanvasModulaten viiveellä)
	if _modulate_node == null or not is_instance_valid(_modulate_node):
		_modulate_node = _scene.get_node_or_null("DayNightModulate") as CanvasModulate
	_sky = _modulate_node.color if _modulate_node and _modulate_node.visible else Color.WHITE
	var light := _sky.lerp(Color.WHITE, 0.35)

	# --- Kamera: seuraa 2D-kameraa (sama pehmennys, humala ja tärähdys) ---
	var center := _cam2d.global_position + _cam2d.offset
	var vis_h := get_tree().root.get_visible_rect().size.y / maxf(_cam2d.zoom.y, 0.01)
	var k := clampf(delta * 4.0, 0.0, 1.0)
	_pitch = lerpf(_pitch, PITCH_PRESETS[_preset], k)
	_zoom_s = lerpf(_zoom_s, zoom_mult, k)
	var half := vis_h / PX * 0.5 * _zoom_s
	var dist := half / tan(deg_to_rad(fov_deg) * 0.5)
	var pr := deg_to_rad(_pitch)
	var tgt := Vector3(center.x / PX, 0.0, center.y / PX)
	_cam3d.fov = fov_deg
	_cam3d.look_at_from_position(tgt + Vector3(0.0, sin(pr), cos(pr)) * dist, tgt, Vector3.UP)
	_cam3d.rotate_object_local(Vector3(0, 0, 1), _cam2d.rotation)

	# --- Maakuvan alue: näkyvän maan keskelle ---
	var cover := float(ground_tex_size) / ground_texels_per_px
	var vs := Vector2(_vp3d.size)
	var lim := cover / PX * 0.45
	var a := _ray_ground(Vector2(vs.x * 0.5, 0.0), tgt, lim)
	var b := _ray_ground(Vector2(vs.x * 0.5, vs.y), tgt, lim)
	var mid := (a + b) * 0.5
	var tl := (Vector2(mid.x, mid.z) * PX - Vector2(cover, cover) * 0.5).round()
	_ground_rect = Rect2(tl, Vector2(cover, cover))
	var tx := ground_texels_per_px
	_ground_vp.canvas_transform = Transform2D(Vector2(tx, 0.0), Vector2(0.0, tx), -tl * tx)
	var gr4 := Vector4(tl.x, tl.y, cover, cover)
	_ground_mat.set_shader_parameter("ground_rect", gr4)
	_bld_mat.set_shader_parameter("ground_rect", gr4)
	_bld_mat.set_shader_parameter("sky", _sky)
	var fb := Color(0.2, 0.28, 0.2) * _sky
	_ground_mat.set_shader_parameter("fallback", fb)
	_env.background_color = fb

	# --- Läpinäkyvät seinät pelaajan edessä ---
	var fp := _focus_point()
	var pp := Vector3(fp.x / PX, 0.0, fp.y / PX)
	_bld_mat.set_shader_parameter("player_pos", pp)
	_bld_mat.set_shader_parameter("player_uv", _cam3d.unproject_position(pp + Vector3(0, 0.8, 0)) / vs)

	# --- Hahmot ja autot ---
	_process_pending()
	var cull := proxy_cull_tiles * PX
	var keep: Array = []
	for p: Proxy in _proxies:
		if _update_proxy(p, center, cull * cull, light):
			keep.append(p)
	if keep.size() != _proxies.size():
		_proxies = keep
		_known.clear()
		for p: Proxy in _proxies:
			if is_instance_valid(p.spr):
				_known[(p.spr as Object).get_instance_id()] = true


## Kameran säde ruudun pisteestä maatasolle (y = 0), rajattuna etäisyyteen lim
func _ray_ground(screen: Vector2, tgt: Vector3, lim: float) -> Vector3:
	var o := _cam3d.project_ray_origin(screen)
	var d := _cam3d.project_ray_normal(screen)
	var hit: Vector3
	if d.y > -0.01:
		hit = o + Vector3(d.x, 0.0, d.z).normalized() * 1000.0
	else:
		hit = o + d * (-o.y / d.y)
	hit.y = 0.0
	var off := hit - tgt
	if off.length() > lim:
		off = off.normalized() * lim
	return tgt + off


## Hiiren osoittama piste 2D-maailmassa (tähtäys)
func mouse_world() -> Vector2:
	if _cam3d == null or _rect == null or _rect.size.x < 1.0 or _rect.size.y < 1.0:
		return Vector2.ZERO
	var uv := _rect.get_local_mouse_position() / _rect.size
	var pix := uv * Vector2(_vp3d.size)
	var o := _cam3d.project_ray_origin(pix)
	var d := _cam3d.project_ray_normal(pix)
	var h := AIM_H * height_scale
	if absf(d.y) < 0.0001:
		return Vector2(o.x, o.z) * PX
	var w := o + d * ((h - o.y) / d.y)
	return Vector2(w.x, w.z) * PX
