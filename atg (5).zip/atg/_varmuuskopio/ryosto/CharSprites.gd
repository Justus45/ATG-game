extends RefCounted
## Yksityiskohtaiset hahmokuvat (32x32 px / ruutu), jotka piirretään pelissä
## 16x16-kokoisina (ImageTexture.set_size_override). Näin hahmoissa on
## kaksinkertainen tarkkuus, mutta mittasuhteet, offsetit ja osumalaatikot
## pysyvät täsmälleen ennallaan.
##
## Kuvat tuottaa _varmuuskopio/gen_characters_hd.py.
## Sarakkeet: 0 vasen, 1 alas, 2 ylös, 3 oikea. Rivit: tyyppi * 3 + askel.

const NPC_SHEET: Texture2D = preload("res://assets/sprites/player/characters_hd.png")
const POLICE_SHEET: Texture2D = preload("res://assets/sprites/police/police_officer_hd.png")
## Pelaajan aseasennot: rivit 0-2 yksi käsi, 3-5 kaksi kättä (sarakkeet kuten yllä)
const ARMED_PATH := "res://assets/sprites/player/player_armed_hd.png"
## Pelaajan hahmon ensimmäinen rivi characters.png:ssä
const PLAYER_ROW := 12
const SRC := 32
const DST := 16

static var _cache := {}
static var _imgs := {}


static func frame(sheet: Texture2D, col: int, row: int) -> Texture2D:
	var key := Vector3i(sheet.get_instance_id(), col, row)
	if _cache.has(key):
		return _cache[key]
	var img: Image = _imgs.get(sheet.get_instance_id())
	if img == null:
		img = sheet.get_image()
		if img.is_compressed():
			img.decompress()
		img.convert(Image.FORMAT_RGBA8)
		_imgs[sheet.get_instance_id()] = img
	var sub := img.get_region(Rect2i(col * SRC, row * SRC, SRC, SRC))
	var t := ImageTexture.create_from_image(sub)
	t.set_size_override(Vector2i(DST, DST))
	t.set_meta("cs_col", col)   # 2 = selin: ei silmiä (räpsytys ohitetaan)
	_cache[key] = t
	return t


# ----------------------------------------------------------------------------
#  BAARIN HENKILÖKUNTA (staff_hd.png, _varmuuskopio/gen_staff_hd.py)
# ----------------------------------------------------------------------------
## Asut: 0 tarjoilija (valkoinen paita, musta liivi, rusetti), 1 ovimies (musta), 2 kokki (valkoinen)
## Hahmotyypit 0-2 (samat kasvot kuin NPC-tyypeillä 0-2). Rivit: (asu*3 + tyyppi)*3 + askel.
const STAFF_PATH := "res://assets/sprites/player/staff_hd.png"
const WAITER := 0
const BOUNCER := 1
const CHEF := 2
static var _staff_sheet: Texture2D = null


static func staff(outfit: int, kind: int, col: int, step: int = 0) -> Texture2D:
	if _staff_sheet == null and ResourceLoader.exists(STAFF_PATH):
		_staff_sheet = load(STAFF_PATH) as Texture2D
	if _staff_sheet == null:
		return npc(col, kind * 3 + step)   # kuvaa ei vielä tuotu: tavallinen NPC
	return frame(_staff_sheet, col, (outfit * 3 + kind) * 3 + step)


# ----------------------------------------------------------------------------
#  SILMIEN RÄPSYTYS JA ÄÄRIVIIVA (IdleLife.gd, baarin piirrot)
# ----------------------------------------------------------------------------
static var _blink_cache := {}
static var _mask_cache := {}


## Sama kuva silmät kiinni (null, jos silmiä ei löydy, esim. selkä tai kypärä).
static func blink(tex: Texture2D) -> Texture2D:
	if tex == null:
		return null
	var id := tex.get_instance_id()
	if _blink_cache.has(id):
		return _blink_cache[id]
	var out: Texture2D = null
	if not (tex.has_meta("cs_col") and int(tex.get_meta("cs_col")) == 2):
		var img := tex.get_image()
		if img:
			img = img.duplicate() as Image
			if img.is_compressed():
				img.decompress()
			img.convert(Image.FORMAT_RGBA8)
			if _close_eyes(img):
				var t := ImageTexture.create_from_image(img)
				t.set_size_override(Vector2i(tex.get_size()))
				out = t
	_blink_cache[id] = out
	return out


## Hahmon siluetti valkoisena (ääriviivaa varten: piirretään 1 px siirroilla sävytettynä).
static func mask(tex: Texture2D) -> Texture2D:
	if tex == null:
		return null
	var id := tex.get_instance_id()
	if _mask_cache.has(id):
		return _mask_cache[id]
	var out: Texture2D = null
	var img := tex.get_image()
	if img:
		img = img.duplicate() as Image
		if img.is_compressed():
			img.decompress()
		img.convert(Image.FORMAT_RGBA8)
		for y in img.get_height():
			for x in img.get_width():
				var a := img.get_pixel(x, y).a
				img.set_pixel(x, y, Color(1, 1, 1, 1.0 if a > 0.5 else 0.0))
		var t := ImageTexture.create_from_image(img)
		t.set_size_override(Vector2i(tex.get_size()))
		out = t
	_mask_cache[id] = out
	return out


static func _skin(c: Color) -> bool:
	if c.a < 0.5:
		return false
	var r := c.r8
	var g := c.g8
	var b := c.b8
	return (r > 190 and g > 110 and r > b + 45) or (r >= 100 and r <= 175 and g >= 55 and g <= 115 and b >= 30 and b <= 80 and r > g and g > b)


static func _lum(c: Color) -> float:
	return 0.3 * c.r8 + 0.59 * c.g8 + 0.11 * c.b8


## Etsii pupillit (tumma piste, alla ihoa, yllä värikäs iiris / valkuainen) ja piirtää
## silmäluomen: yläpuoli iholla, pupillin rivi tummalla viivalla.
static func _close_eyes(img: Image) -> bool:
	if img.get_height() != 32:
		return false
	var pupils: Array[Vector2i] = []
	for y in range(7, 16):
		for x in range(1, img.get_width() - 1):
			var c := img.get_pixel(x, y)
			if c.a < 0.5 or absi(c.r8 - 26) + absi(c.g8 - 22) + absi(c.b8 - 34) > 28:
				continue
			var below := img.get_pixel(x, y + 1)
			var above := img.get_pixel(x, y - 1)
			if not _skin(below):
				continue
			if above.a < 0.5 or _skin(above) or _lum(above) < 62.0:
				continue
			pupils.append(Vector2i(x, y))
	if pupils.is_empty():
		return false
	for p in pupils:
		var skin := img.get_pixel(p.x, p.y + 1)
		var lid := Color(skin.r * 0.45, skin.g * 0.4, skin.b * 0.4, 1.0)
		for xx in range(p.x - 1, p.x + 2):
			var a := img.get_pixel(xx, p.y - 1)
			if a.a > 0.5 and (not _skin(a) or _lum(a) > _lum(skin) + 15.0):
				img.set_pixel(xx, p.y - 1, skin)
		for xx in range(p.x - 1, p.x + 2):
			if img.get_pixel(xx, p.y).a > 0.5:
				img.set_pixel(xx, p.y, lid)
	return true


## Jalankulkijat, baarin asiakkaat, katujengit ja pelaaja (characters.png:n järjestys)
static func npc(col: int, row: int) -> Texture2D:
	return frame(NPC_SHEET, col, row)


static func police(col: int, row: int) -> Texture2D:
	return frame(POLICE_SHEET, col, row)


## Pelaajan animaatiot aseasennossa (pose 1 tai 2). frames = Player.tscn:n alkuperäiset ruudut.
static func armed_frames(frames: SpriteFrames, pose: int) -> SpriteFrames:
	var out := frames.duplicate() as SpriteFrames
	if not ResourceLoader.exists(ARMED_PATH):
		return upgrade_frames(frames)
	var sheet := load(ARMED_PATH) as Texture2D
	for anim in out.get_animation_names():
		for i in out.get_frame_count(anim):
			var t := out.get_frame_texture(anim, i)
			if t is AtlasTexture:
				var r: Rect2 = (t as AtlasTexture).region
				var col := int(round(r.position.x / 17.0))
				var row := int(round(r.position.y / 17.0))
				var tex: Texture2D
				if row >= PLAYER_ROW and row < PLAYER_ROW + 3:
					tex = frame(sheet, col, (pose - 1) * 3 + row - PLAYER_ROW)
				else:
					tex = npc(col, row)
				out.set_frame(anim, i, tex, out.get_frame_duration(anim, i))
	return out


## Vaihtaa AnimatedSprite2D:n vanhat 16 px characters.png-ruudut (1 px väli)
## vastaaviin tarkkoihin kuviin.
static func upgrade_frames(frames: SpriteFrames) -> SpriteFrames:
	var out := frames.duplicate() as SpriteFrames
	for anim in out.get_animation_names():
		for i in out.get_frame_count(anim):
			var t := out.get_frame_texture(anim, i)
			if t is AtlasTexture:
				var r: Rect2 = (t as AtlasTexture).region
				var col := int(round(r.position.x / 17.0))
				var row := int(round(r.position.y / 17.0))
				out.set_frame(anim, i, npc(col, row), out.get_frame_duration(anim, i))
	return out


## Istuva hahmo: vain yläruumis (pää ja torso), jalat rajattu pois (terassin tuolit, pöydät).
static var _seat_cache := {}

static func seated(tex: Texture2D) -> Texture2D:
	if tex == null:
		return null
	var id := tex.get_instance_id()
	if _seat_cache.has(id):
		return _seat_cache[id]
	var out: Texture2D = null
	var img := tex.get_image()
	if img and img.get_height() == 32:
		img = img.duplicate() as Image
		if img.is_compressed():
			img.decompress()
		img.convert(Image.FORMAT_RGBA8)
		var sub := img.get_region(Rect2i(0, 0, 32, 23))
		var t := ImageTexture.create_from_image(sub)
		t.set_size_override(Vector2i(16, 12))
		if tex.has_meta("cs_col"):
			t.set_meta("cs_col", tex.get_meta("cs_col"))
		out = t
	_seat_cache[id] = out
	return out



# ----------------------------------------------------------------------------
#  KALLE (kalle_hd.png, _varmuuskopio/gen_kalle_hd.py): skinhead nahkatakissa, tatuoinnit
# ----------------------------------------------------------------------------
const KALLE_PATH := "res://assets/sprites/player/kalle_hd.png"
static var _kalle_sheet: Texture2D = null

static func kalle(col: int, step: int = 0) -> Texture2D:
	if _kalle_sheet == null and ResourceLoader.exists(KALLE_PATH):
		_kalle_sheet = load(KALLE_PATH) as Texture2D
	if _kalle_sheet == null:
		return npc(col, 9 + step)   # kuvaa ei vielä tuotu
	return frame(_kalle_sheet, col, step)
