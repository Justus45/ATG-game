"""ATG: maailman tilemap 2x-tarkkuuteen (16 px -> 32 px / ruutu), hahmojen tyyliin.

1. Lähtökohta on alkuperäinen tilemap (samat värit kuin pelin tilemap.png).
2. Jokainen pikseli -> 2x2. Ääriviivat ja 1 px viivat ohennetaan 1 px:n levyisiksi
   (kuten uusissa hahmoissa), kuperat kulmat pyöristetään.
3. Materiaalit (nurmi, asfaltti, laatat, tiili, katot, vesi, lehvästö) saavat uuden
   2x-tarkan tekstuurin. Tekstuurit toistuvat 32 px välein -> ruudut liittyvät saumatta.
4. Hahmosarakkeisiin (23-26) kopioidaan characters_hd.png.

Tulos: assets/sprites/tilemap_hd.png (916 x 610). Peli piirtää sen alkuperäisen
tilemapin kokoisena (ImageTexture.set_size_override), joten ruudukko ei muutu.

Ajo: python gen_world_hd.py <projektin juuri>
"""
import os, sys, math, colorsys
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))

T, SEP = 16, 1
T2, SEP2 = 32, 2


def h2(x, y, seed=0):
    n = (x * 374761393 + y * 668265263 + seed * 2246822519) & 0xffffffff
    n = (n ^ (n >> 13)) * 1274126177 & 0xffffffff
    return ((n ^ (n >> 16)) & 0xffff) / 65535.0


def lum(c):
    r, g, b = [v / 255 for v in c[:3]]
    return 0.299 * r + 0.587 * g + 0.114 * b


_sh = {}


def shade(c, d):
    """Sävy tummemmaksi (d<0, kohti sinistä) tai vaaleammaksi (d>0, kohti keltaista)."""
    key = (c, d)
    if key in _sh:
        return _sh[key]
    h, s, v = colorsys.rgb_to_hsv(*[x / 255 for x in c[:3]])
    hd = h * 360
    if d < 0:
        k = -d
        v *= 0.86 ** k
        s = min(1.0, s * 1.08 ** k + 0.02 * k)
        tgt = 235
    else:
        k = d
        v = min(1.0, v * 1.09 ** k + 0.02 * k)
        s *= 0.9 ** k
        tgt = 55
    diff = (tgt - hd + 540) % 360 - 180
    hd = (hd + max(-5 * k, min(5 * k, diff * 0.12 * k))) % 360
    out = tuple(int(round(x * 255)) for x in colorsys.hsv_to_rgb(hd / 360, s, v))
    _sh[key] = out
    return out


def mix(a, b, k):
    return tuple(int(round(a[i] * (1 - k) + b[i] * k)) for i in range(3))


# ------------------------------------------------------------------ KOHINA (32-jaksollinen)
def vnoise(x, y, cell, seed):
    n = 32 // cell
    gx, gy = x / cell, y / cell
    x0, y0 = int(gx) % n, int(gy) % n
    x1, y1 = (x0 + 1) % n, (y0 + 1) % n
    fx, fy = gx - int(gx), gy - int(gy)
    fx = fx * fx * (3 - 2 * fx)
    fy = fy * fy * (3 - 2 * fy)
    a, b, c, d = h2(x0, y0, seed), h2(x1, y0, seed), h2(x0, y1, seed), h2(x1, y1, seed)
    return (a * (1 - fx) + b * fx) * (1 - fy) + (c * (1 - fx) + d * fx) * fy


def chk(x, y):
    return (x + y) % 2 == 0


def _walks(seed, count, steps):
    """Muutama satunnainen halkeama 32x32-alueelle (jaksollinen)."""
    pts = set()
    for k in range(count):
        x = int(h2(k, 1, seed) * 32)
        y = int(h2(k, 2, seed) * 32)
        dx = 1 if h2(k, 3, seed) > 0.5 else -1
        for s in range(steps):
            pts.add((x % 32, y % 32))
            r = h2(k, s + 10, seed)
            if r < 0.45:
                x += dx
            elif r < 0.8:
                y += 1
            else:
                x += dx
                y += 1
    return pts


CRACKS = _walks(77, 2, 6)
GRASS_TUFTS = set()
for k in range(14):
    GRASS_TUFTS.add((int(h2(k, 1, 51) * 32), int(h2(k, 2, 51) * 32)))


# ------------------------------------------------------------------ MATERIAALIT 2x
def tex_grass(base, x, y):
    v = vnoise(x, y, 16, 31) * 0.6 + vnoise(x, y, 8, 32) * 0.4
    b = base
    if v < 0.3 and chk(x, y) and (y % 2 == 0 or v < 0.24):
        b = shade(base, -1)
    elif v > 0.7 and chk(x, y) and x % 2 == 0:
        b = shade(base, 1)
    # ruohotupsut: vaalea kärki, tumma tyvi
    for tx, ty in GRASS_TUFTS:
        dx, dy = (x - tx) % 32, (y - ty) % 32
        if (dx, dy) in ((0, 0), (2, 1)):
            return shade(b, 1)
        if (dx, dy) in ((1, 1), (0, 1), (1, 2), (2, 2)):
            return shade(b, -1)
    if h2(x, y, 7) > 0.997:
        return (240, 204, 96)
    if h2(x, y, 8) > 0.997:
        return (240, 238, 228)
    return b


def tex_asphalt(base, x, y):
    r = h2(x, y, 3)
    v = vnoise(x, y, 16, 33)
    if (x, y) in CRACKS:
        return shade(base, -2)
    if r < 0.09 or (v < 0.32 and chk(x, y) and r < 0.5):
        return shade(base, -1)
    if r > 0.975 or (v > 0.75 and r > 0.85):
        return shade(base, 1)
    return base


def tex_pavers(base, x, y, size=16):
    row = y // size
    off = size // 2 if row % 2 else 0
    tx = (x + off) % 32
    gx, gy = tx % size, y % size
    pid = (tx // size, row % (32 // size))
    if gx == size - 1 or gy == size - 1:
        return shade(base, -1)
    if gy == 0 or gx == 0:
        return shade(base, 1) if h2(*pid, 9) > 0.2 else base
    b = base
    t = h2(pid[0], pid[1], 4)
    if t < 0.3 and chk(x, y):
        b = shade(base, -1)
    elif t > 0.85 and chk(x, y):
        b = shade(base, 1)
    if (gy == size - 2 or gx == size - 2) and chk(x, y):
        b = shade(base, -1)
    if h2(x, y, 6) > 0.96:
        return shade(b, -1)
    return b


def tex_brick(base, x, y):
    row = y // 4
    off = 4 if row % 2 else 0
    gx, gy = (x + off) % 8, y % 4
    if gy == 3 or gx == 7:
        return shade(base, -1)
    bid = ((x + off) // 8 % 4, row % 8)
    b = base
    t = h2(bid[0], bid[1], 14)
    if t < 0.28:
        b = shade(base, -1) if chk(x, y) else base
    elif t > 0.88:
        b = shade(base, 1) if chk(x, y) else base
    if gy == 0 and h2(x, y, 15) > 0.4:
        b = shade(b, 1)
    return b


def tex_water(base, x, y):
    band = y // 6
    w = (x + band * 5 + int(vnoise(x, y, 16, 41) * 6)) % 12
    if y % 6 == 2 and w < 4:
        return shade(base, 1)
    if y % 6 == 3 and 1 <= w < 5:
        return shade(base, -1)
    if h2(x, y, 12) > 0.992:
        return (230, 248, 255)
    if vnoise(x, y, 16, 42) < 0.3 and chk(x, y):
        return shade(base, -1)
    return base


def tex_roof(base, x, y):
    row = y // 8
    off = 4 if row % 2 else 0
    gx, gy = (x + off) % 8, y % 8
    if gy == 7:
        return shade(base, -2)
    if gx == 0:
        return shade(base, -1)
    if gy == 0:
        return shade(base, 1)
    if gy == 6 or (gy == 5 and gx % 3 == 1):
        return shade(base, -1)
    if gx == 1 and gy <= 3:
        return shade(base, 1)
    sid = ((x + off) // 8 % 4, row % 4)
    if h2(sid[0], sid[1], 13) < 0.25 and gy in (2, 3) and gx > 1:
        return shade(base, 1)
    return base


# lehvästö: ryppäiden keskipisteet 8 px ruudukossa, satunnaisesti siirrettynä
def _leaf_centers():
    cs = []
    for gy in range(4):
        for gx in range(4):
            cx = gx * 8 + 2 + int(h2(gx, gy, 61) * 4)
            cy = gy * 8 + 2 + int(h2(gx, gy, 62) * 4)
            cs.append((cx, cy))
    return cs


LEAVES = _leaf_centers()


def tex_foliage(base, x, y):
    best, bd = None, 99
    for cx, cy in LEAVES:
        dx = (x - cx + 16) % 32 - 16
        dy = (y - cy + 16) % 32 - 16
        d = math.hypot(dx * 0.9, dy)
        if d < bd:
            bd, best = d, (dx, dy)
    dx, dy = best
    if bd > 4.6:
        return shade(base, -1)
    if dy <= -2 and abs(dx) <= 2:
        if dy <= -3 and dx <= 0:
            return shade(base, 2) if h2(x, y, 63) > 0.5 else shade(base, 1)
        return shade(base, 1)
    if dy >= 2 and (dx >= 1 or dy >= 3):
        return shade(base, -1)
    return base


def _pav(size):
    return lambda b, x, y: tex_pavers(b, x, y, size)


# alue -> [(alkuperäiset täyttövärit, perusväri, tekstuuri)]
MATERIALS = {
    "park": [({(56, 203, 171), (63, 216, 171), (66, 223, 171), (59, 210, 171)}, (56, 203, 171), tex_grass)],
    "pavers": [({(198, 188, 159), (192, 178, 154), (183, 170, 147)}, (198, 188, 159), _pav(16))],
    "plaza": [({(170, 168, 189), (178, 172, 193), (161, 155, 176)}, (170, 168, 189), _pav(16))],
    "facade": [({(170, 174, 186), (165, 171, 180), (158, 163, 172)}, (170, 174, 186), tex_brick)],
    "water": [({(89, 182, 216), (100, 192, 225), (107, 204, 234)}, (89, 182, 216), tex_water)],
    "road": [({(92, 98, 120), (84, 90, 110), (100, 107, 131)}, (92, 98, 120), tex_asphalt)],
    "roof_red": [({(194, 80, 77), (165, 66, 64)}, (194, 80, 77), tex_roof)],
    "roof_orange": [({(199, 123, 71), (169, 103, 59)}, (199, 123, 71), tex_roof)],
    "trees": [({(56, 203, 171), (66, 223, 171)}, (56, 203, 171), tex_foliage),
              ({(218, 96, 56), (255, 113, 67)}, (218, 96, 56), tex_foliage)],
}


def region(tc, tr):
    if tc <= 7 and tr <= 2: return "park"
    if 8 <= tc <= 15 and tr <= 2: return "plaza"
    if tc <= 7 and 3 <= tr <= 5: return "pavers"
    if 8 <= tc <= 15 and 3 <= tr <= 5: return "facade"
    if 8 <= tc <= 15 and 6 <= tr <= 8: return "water"
    if 16 <= tc <= 22 and tr <= 3: return "roof_red"
    if 16 <= tc <= 22 and 4 <= tr <= 7: return "roof_orange"
    if 16 <= tc <= 22 and 8 <= tr <= 13: return "trees"
    if tc <= 14 and 15 <= tr <= 17: return "road"
    return None


# korostuspikselit (alkuperäisen 16 px tekstuurin jäänteet), jotka sulautetaan pintaan
ACCENTS = {
    "roof_red": {(220, 97, 93)},
    "roof_orange": {(226, 145, 87)},
}


def material_pixel(reg, orig, x, y):
    for fills, base, fn in MATERIALS.get(reg, []):
        if orig in fills:
            return fn(base, x, y)
    return orig


# ------------------------------------------------------------------ 2x SKAALAUS
DL = 0.06   # kuinka paljon tummempi pikselin pitää olla ollakseen "viiva"


def upscale_tile(src, reg):
    """src: HxW [(orig_rgb, alpha) tai None] (yleensä 16x16). Palauttaa 2H x 2W RGBA-listan."""
    SH, SW = len(src), len(src[0])
    flat = [[None] * SW for _ in range(SH)]
    for y in range(SH):
        for x in range(SW):
            p = src[y][x]
            if p:
                flat[y][x] = p[0]
    out = [[None] * (SW * 2) for _ in range(SH * 2)]

    def get(x, y):
        if 0 <= x < SW and 0 <= y < SH:
            return src[y][x]
        return None   # ruudun ulkopuoli = läpinäkyvä

    def inside(x, y):
        return 0 <= x < SW and 0 <= y < SH

    def darker(p, q):
        """p tummempi kuin q (q läpinäkymätön)"""
        return q is not None and lum(flat_of(q)) - lum(flat_of(p)) > DL

    cache = {}

    def flat_of(p):
        return p[0]

    for y in range(SH):
        for x in range(SW):
            p = src[y][x]
            if not p:
                continue
            for sy in (0, 1):
                for sx in (0, 1):
                    hx = x + (1 if sx else -1)
                    ox = x - (1 if sx else -1)
                    vy = y + (1 if sy else -1)
                    oy = y - (1 if sy else -1)
                    hn, ho = get(hx, y), get(ox, y)
                    vn, vo = get(x, vy), get(x, oy)
                    rep = None
                    # vaakasuunta: korvataan puolikas joka osoittaa vaaleampaan naapuriin
                    if hn is not None and darker(p, hn):
                        if ho is None:
                            rep = hn                  # ääriviiva: sisäpuoli pois
                        elif darker(p, ho) and sx == 1:
                            rep = hn                  # pystyviiva: oikea puolikas pois
                    if vn is not None and darker(p, vn):
                        if vo is None:
                            rep = rep or vn
                        elif darker(p, vo) and sy == 1:
                            rep = rep or vn
                    # kupera kulma: molemmat sivut ja kulma tyhjiä
                    if inside(hx, y) and inside(x, vy) and inside(hx, vy) and \
                            hn is None and vn is None and get(hx, vy) is None and ho is not None and vo is not None:
                        out[y * 2 + sy][x * 2 + sx] = None
                        continue
                    if rep is not None:
                        out[y * 2 + sy][x * 2 + sx] = (rep[0], p[1], flat_of(p))
                    else:
                        out[y * 2 + sy][x * 2 + sx] = (p[0], p[1], None)
    img = [[None] * (SW * 2) for _ in range(SH * 2)]
    for Y in range(SH * 2):
        for X in range(SW * 2):
            o = out[Y][X]
            if o is None:
                continue
            oc, a, ao = o
            new = oc
            if reg:
                new = material_pixel(reg, oc, X, Y)
            if ao is not None:
                new = mix(new, ao, 0.3)
            img[Y][X] = new + (a,)
    return img


def build(root):
    src_img = Image.open(os.path.join(HERE, "sprites_alkuperaiset", "tilemap.png")).convert("RGBA")
    W, H = src_img.size
    cols, rows = (W + SEP) // (T + SEP), (H + SEP) // (T + SEP)
    out = Image.new("RGBA", (W * 2, H * 2), (0, 0, 0, 0))
    px = src_img.load()
    op = out.load()
    for tr in range(rows):
        for tc in range(cols):
            ox, oy = tc * (T + SEP), tr * (T + SEP)
            src = [[None] * T for _ in range(T)]
            any_px = False
            for y in range(T):
                for x in range(T):
                    if ox + x < W and oy + y < H:
                        c = px[ox + x, oy + y]
                        if c[3] > 0:
                            src[y][x] = (c[:3], c[3])
                            any_px = True
            if not any_px:
                continue
            reg = region(tc, tr)
            if reg in ACCENTS:
                fills = set().union(*[m[0] for m in MATERIALS[reg]])
                base = MATERIALS[reg][0][1]
                fix = []
                for y in range(T):
                    for x in range(T):
                        p = src[y][x]
                        if p and p[0] in ACCENTS[reg]:
                            n = sum(1 for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))
                                    if 0 <= x + dx < T and 0 <= y + dy < T and src[y + dy][x + dx]
                                    and src[y + dy][x + dx][0] in fills | ACCENTS[reg])
                            if n >= 3:
                                fix.append((x, y))
                for x, y in fix:
                    src[y][x] = (base, src[y][x][1])
            tile = upscale_tile(src, region(tc, tr))
            for Y in range(T2):
                for X in range(T2):
                    c = tile[Y][X]
                    if c:
                        op[tc * (T2 + SEP2) + X, tr * (T2 + SEP2) + Y] = c
    # hahmot
    chp = os.path.join(root, "assets/sprites/player/characters_hd.png")
    if os.path.exists(chp):
        ch = Image.open(chp).convert("RGBA")
        for r in range(18):
            for c in range(4):
                cell = ch.crop((c * 32, r * 32, c * 32 + 32, r * 32 + 32))
                x0, y0 = (23 + c) * (T2 + SEP2), r * (T2 + SEP2)
                out.paste((0, 0, 0, 0), (x0, y0, x0 + 32, y0 + 32))
                out.alpha_composite(cell, (x0, y0))
    # autot: kootaan kokonaisina (ei saumoja ruutujen välissä), skaalataan ja jaetaan takaisin
    for color, sets in CAR_SETS.items():
        for d, (c0, c1, r0, r1) in sets.items():
            cw, chh = c1 - c0 + 1, r1 - r0 + 1
            lo = Image.new("RGBA", (cw * T, chh * T), (0, 0, 0, 0))
            for r in range(chh):
                for c in range(cw):
                    sx, sy = (c0 + c) * (T + SEP), (r0 + r) * (T + SEP)
                    lo.alpha_composite(src_img.crop((sx, sy, sx + T, sy + T)), (c * T, r * T))
            hd = upscale_vehicle(lo)
            for r in range(chh):
                for c in range(cw):
                    x0, y0 = (c0 + c) * (T2 + SEP2), (r0 + r) * (T2 + SEP2)
                    out.paste((0, 0, 0, 0), (x0, y0, x0 + T2, y0 + T2))
                    out.alpha_composite(hd.crop((c * T2, r * T2, c * T2 + T2, r * T2 + T2)), (x0, y0))
    pad(out, cols, rows)
    return out


# ------------------------------------------------------------------ AUTOT
## sama kuin city_generator.gd CAR_SETS: [sarake_alku, sarake_loppu, rivi_alku, rivi_loppu]
CAR_SETS = {
    "green": {"down": [21, 21, 14, 15], "up": [22, 22, 14, 15], "left": [21, 22, 16, 16], "right": [21, 22, 17, 17]},
    "yellow": {"down": [17, 17, 14, 15], "up": [20, 20, 14, 15], "left": [15, 16, 14, 15], "right": [18, 19, 14, 15]},
    "red": {"down": [17, 17, 16, 17], "up": [20, 20, 16, 17], "left": [15, 16, 16, 17], "right": [18, 19, 16, 17]},
}
GLASS = {(193, 219, 235), (205, 229, 242), (218, 238, 247), (209, 221, 239), (230, 238, 248)}
TIRES = {(96, 96, 90), (84, 84, 78), (55, 55, 51)}


def upscale_vehicle(im):
    """Koko ajoneuvon kuva 2x: ohuet ääriviivat + maalipinnan reunavalo/-varjo + lasin heijastus."""
    im = im.convert("RGBA")
    W, H = im.size
    p = im.load()
    src = [[(p[x, y][:3], p[x, y][3]) if p[x, y][3] else None for x in range(W)] for y in range(H)]
    up = upscale_tile(src, None)
    H2, W2 = len(up), len(up[0])
    org = [[None] * W2 for _ in range(H2)]
    for y in range(H):
        for x in range(W):
            if src[y][x]:
                for dy in (0, 1):
                    for dx in (0, 1):
                        org[y * 2 + dy][x * 2 + dx] = src[y][x][0]
    res = [row[:] for row in up]
    for Y in range(H2):
        for X in range(W2):
            c = up[Y][X]
            if c is None:
                continue
            o = org[Y][X]
            if o in TIRES:
                continue          # renkaat ennallaan (CarFX pyörittää ne)
            if o in GLASS:
                if (X - Y) % 10 in (0, 1) or (X - Y) % 10 == 4:
                    res[Y][X] = mix(c, (255, 255, 255), 0.55) + (c[3],)
                continue
            if lum(c) < 0.22:
                continue          # ääriviiva
            above = up[Y - 1][X] if Y > 0 else None
            below = up[Y + 1][X] if Y + 1 < H2 else None
            if above is None or lum(above) < lum(c) - 0.12:
                res[Y][X] = shade(c[:3], 1) + (c[3],)
            elif below is None or lum(below) < lum(c) - 0.12:
                res[Y][X] = shade(c[:3], -1) + (c[3],)
    out = Image.new("RGBA", (W2, H2), (0, 0, 0, 0))
    q = out.load()
    for Y in range(H2):
        for X in range(W2):
            if res[Y][X]:
                q[X, Y] = res[Y][X]
    return out


def build_vehicle_files(root):
    for rel in ("assets/sprites/vehicles", "assets/sprites/police"):
        d = os.path.join(root, rel)
        for f in sorted(os.listdir(d)):
            if f.endswith(".png") and "car_" in f and not f.endswith("_hd.png"):
                hd = upscale_vehicle(Image.open(os.path.join(d, f)))
                hd.save(os.path.join(d, f[:-4] + "_hd.png"))
                print("ok", rel + "/" + f[:-4] + "_hd.png", hd.size)


def pad(img, cols, rows):
    """Kopioi ruutujen reunapikselit 2 px väliin (1 px kummallekin ruudulle), jottei
    lähimmän pikselin näytteistys tuo ruutujen reunoille läpinäkyviä saumoja."""
    W, H = img.size
    p = img.load()
    st = T2 + SEP2
    for tr in range(rows):
        for tc in range(cols):
            x0, y0 = tc * st, tr * st
            for y in range(y0, y0 + T2):
                if x0 - 1 >= 0:
                    p[x0 - 1, y] = p[x0, y]
                if x0 + T2 < W:
                    p[x0 + T2, y] = p[x0 + T2 - 1, y]
            for x in range(max(0, x0 - 1), min(W, x0 + T2 + 1)):
                if y0 - 1 >= 0:
                    p[x, y0 - 1] = p[x, y0]
                if y0 + T2 < H:
                    p[x, y0 + T2] = p[x, y0 + T2 - 1]


if __name__ == "__main__":
    root = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "..")
    img = build(root)
    dst = os.path.join(root, "assets/sprites/tilemap_hd.png")
    img.save(dst)
    print("ok", img.size, dst)
    build_vehicle_files(root)
