# Suzuki PV -tyylinen mopo (ilman kuskia) ja Lamborghini-tyylinen superauto, 2x tarkkuus.
from PIL import Image, ImageDraw
S = 48
RED = (206, 30, 34); RED_D = (140, 16, 22); RED_L = (246, 96, 86); WHITE = (238, 238, 240)
CHR = (196, 200, 210); CHR_D = (120, 124, 134); BLK = (22, 20, 26); TIRE = (38, 38, 44)
SPOKE = (150, 152, 160); SEAT = (34, 30, 34); ENG = (96, 98, 106); LENS = (255, 240, 170); TAIL = (230, 40, 40)

def wheel(d, cx, cy, r=7):
	d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=BLK)
	d.ellipse((cx - r + 2, cy - r + 2, cx + r - 2, cy + r - 2), fill=TIRE)
	for a, b in (((-4, 0), (4, 0)), ((0, -4), (0, 4)), ((-3, -3), (3, 3)), ((-3, 3), (3, -3))):
		d.line((cx + a[0], cy + a[1], cx + b[0], cy + b[1]), fill=SPOKE)
	d.ellipse((cx - 1, cy - 1, cx + 1, cy + 1), fill=CHR)

def pv_side():
	im = Image.new('RGBA', (S, S), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
	wheel(d, 11, 35); wheel(d, 37, 35)
	d.arc((3, 26, 19, 42), 190, 350, fill=CHR, width=2)          # takalokasuoja
	d.arc((29, 26, 45, 42), 200, 340, fill=CHR, width=2)         # etulokasuoja
	d.line((11, 35, 21, 30), fill=CHR_D, width=2)               # takahaarukka
	d.line((32, 17, 37, 35), fill=CHR, width=2)                 # etuhaarukka
	d.line((21, 30, 32, 18), fill=BLK, width=2)                 # runko
	d.rectangle((19, 27, 28, 34), fill=ENG); d.line((19, 30, 28, 30), fill=CHR_D)   # moottori
	d.line((22, 34, 5, 30), fill=CHR, width=2)                  # pakoputki
	d.polygon([(16, 24), (22, 24), (22, 29), (16, 29)], fill=WHITE)   # sivukansi
	d.polygon([(22, 19), (31, 17), (33, 21), (30, 25), (22, 25)], fill=RED)   # tankki
	d.line((23, 22, 31, 20), fill=WHITE, width=1); d.line((23, 20, 30, 18), fill=RED_L)
	d.rectangle((7, 21, 22, 24), fill=SEAT); d.line((8, 21, 21, 21), fill=(70, 66, 72))   # satula
	d.rectangle((4, 22, 6, 25), fill=TAIL)
	d.ellipse((34, 13, 41, 20), fill=CHR); d.ellipse((37, 14, 40, 19), fill=LENS)   # ajovalo
	d.line((31, 11, 34, 15), fill=BLK, width=1); d.line((28, 10, 32, 11), fill=BLK, width=2)   # tanko
	d.line((33, 11, 34, 6), fill=CHR_D); d.rectangle((33, 4, 35, 6), fill=CHR)   # peili
	return im

def pv_front(back):
	im = Image.new('RGBA', (S, S), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
	cx = 24
	d.rectangle((cx - 3, 30, cx + 2, 46), fill=BLK); d.rectangle((cx - 2, 31, cx + 1, 45), fill=TIRE)
	if back:
		d.rectangle((cx - 5, 18, cx + 4, 27), fill=SEAT)
		d.polygon([(cx - 5, 13), (cx + 4, 13), (cx + 3, 18), (cx - 4, 18)], fill=RED)
		d.rectangle((cx - 4, 26, cx + 3, 30), fill=CHR)
		d.rectangle((cx - 2, 29, cx + 1, 31), fill=TAIL)
		d.rectangle((cx - 4, 32, cx + 3, 36), fill=WHITE)
		d.line((cx + 6, 28, cx + 7, 40), fill=CHR, width=2)           # pakoputki
	else:
		d.polygon([(cx - 5, 16), (cx + 4, 16), (cx + 3, 23), (cx - 4, 23)], fill=RED)   # tankki takana
		d.line((cx - 4, 18, cx - 4, 34), fill=CHR, width=1); d.line((cx + 3, 18, cx + 3, 34), fill=CHR, width=1)
		d.rectangle((cx - 4, 27, cx + 3, 30), fill=CHR)                # lokasuoja
		d.ellipse((cx - 5, 15, cx + 4, 24), fill=CHR); d.ellipse((cx - 3, 17, cx + 2, 22), fill=LENS)
	d.rectangle((cx - 12, 12, cx + 11, 13), fill=BLK)
	d.rectangle((cx - 13, 11, cx - 11, 14), fill=SEAT); d.rectangle((cx + 10, 11, cx + 12, 14), fill=SEAT)
	d.line((cx - 12, 11, cx - 13, 5), fill=CHR_D); d.rectangle((cx - 15, 3, cx - 12, 5), fill=CHR)
	d.line((cx + 11, 11, cx + 12, 5), fill=CHR_D); d.rectangle((cx + 11, 3, cx + 14, 5), fill=CHR)
	return im

sheet = Image.new('RGBA', (S * 4, S * 2), (0, 0, 0, 0))
for row in range(2):
	r = pv_side()
	sheet.paste(r.transpose(Image.FLIP_LEFT_RIGHT), (0, S * row))
	sheet.paste(pv_front(False), (S, S * row))
	sheet.paste(pv_front(True), (S * 2, S * row))
	sheet.paste(r, (S * 3, S * row))
sheet.save('assets/sprites/vehicles/moped_hd.png')

# --- superauto (kiiltävän keltainen kiila) ---
Y = (255, 194, 14); Y_D = (205, 140, 0); Y_L = (255, 232, 120); OUT = (70, 48, 0)
GL = (34, 38, 52); GL_L = (90, 110, 140); CARB = (26, 26, 30); RIM = (150, 152, 158)

def car_side():
	im = Image.new('RGBA', (58, 30), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
	d.rounded_rectangle((2, 4, 55, 22), 4, fill=OUT)
	d.rounded_rectangle((3, 5, 54, 20), 3, fill=Y)               # katto / yläpinta
	d.polygon([(46, 6), (55, 9), (55, 16), (46, 19)], fill=Y_L)  # kiilanokka
	d.rectangle((3, 20, 54, 25), fill=Y_D)                        # kylki
	d.polygon([(18, 21), (27, 21), (25, 24), (18, 24)], fill=CARB)   # ilmanotto
	d.rounded_rectangle((20, 7, 39, 18), 3, fill=GL)              # ohjaamo
	d.polygon([(33, 7), (39, 8), (39, 17), (33, 18)], fill=GL_L)  # tuulilasi
	d.line((22, 8, 30, 8), fill=GL_L)
	for x in range(8, 19, 2):
		d.line((x, 9, x, 16), fill=CARB)                          # moottoriluukun säleet
	d.rectangle((50, 8, 54, 9), fill=(255, 255, 240)); d.rectangle((50, 16, 54, 17), fill=(255, 255, 240))
	d.rectangle((3, 8, 4, 10), fill=TAIL); d.rectangle((3, 15, 4, 17), fill=TAIL)
	d.line((5, 11, 5, 14), fill=CARB)                             # takasiipi
	for wx in (12, 44):
		d.ellipse((wx - 6, 20, wx + 6, 29), fill=CARB)
		d.ellipse((wx - 3, 22, wx + 3, 27), fill=RIM)
		d.ellipse((wx - 1, 24, wx + 1, 25), fill=CARB)
	d.line((6, 19, 52, 19), fill=Y_L)
	return im

def car_down():
	im = Image.new('RGBA', (32, 50), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
	for wy in (8, 34):
		d.rectangle((0, wy, 4, wy + 9), fill=CARB); d.rectangle((27, wy, 31, wy + 9), fill=CARB)
		d.rectangle((1, wy + 3, 3, wy + 6), fill=RIM); d.rectangle((28, wy + 3, 30, wy + 6), fill=RIM)
	d.rounded_rectangle((2, 1, 29, 47), 4, fill=OUT)
	d.rounded_rectangle((3, 2, 28, 46), 3, fill=Y)
	d.rectangle((4, 2, 27, 4), fill=CARB)                         # takasiipi
	for y in range(6, 14, 2):
		d.line((7, y, 24, y), fill=CARB)                          # moottoriluukku
	d.rounded_rectangle((6, 15, 25, 26), 3, fill=GL)              # katto/ohjaamo
	d.polygon([(6, 26), (25, 26), (23, 32), (8, 32)], fill=GL_L)  # tuulilasi
	d.line((10, 27, 15, 31), fill=(200, 220, 240))
	d.line((15, 33, 15, 42), fill=Y_D); d.line((10, 34, 9, 42), fill=Y_L); d.line((21, 34, 22, 42), fill=Y_L)
	d.polygon([(4, 39), (11, 41), (10, 43), (4, 42)], fill=(255, 255, 240))    # valot
	d.polygon([(27, 39), (20, 41), (21, 43), (27, 42)], fill=(255, 255, 240))
	d.rectangle((9, 44, 22, 46), fill=CARB)                       # etuhelma
	return im

def car_up():
	im = Image.new('RGBA', (32, 50), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
	for wy in (6, 32):
		d.rectangle((0, wy, 4, wy + 9), fill=CARB); d.rectangle((27, wy, 31, wy + 9), fill=CARB)
		d.rectangle((1, wy + 3, 3, wy + 6), fill=RIM); d.rectangle((28, wy + 3, 30, wy + 6), fill=RIM)
	d.rounded_rectangle((2, 1, 29, 47), 4, fill=OUT)
	d.rounded_rectangle((3, 2, 28, 46), 3, fill=Y)
	d.line((15, 4, 15, 12), fill=Y_D); d.line((9, 4, 8, 12), fill=Y_L); d.line((22, 4, 23, 12), fill=Y_L)
	d.polygon([(8, 14), (23, 14), (25, 19), (6, 19)], fill=GL_L)  # tuulilasi
	d.rounded_rectangle((6, 19, 25, 29), 3, fill=GL)
	for y in range(32, 41, 2):
		d.line((7, y, 24, y), fill=CARB)
	d.rectangle((4, 42, 27, 44), fill=CARB)
	d.rectangle((4, 42, 9, 43), fill=TAIL); d.rectangle((22, 42, 27, 43), fill=TAIL)
	d.rectangle((12, 45, 14, 47), fill=RIM); d.rectangle((17, 45, 19, 47), fill=RIM)   # pakoputket
	return im

side = car_side()
side.save('assets/sprites/vehicles/supercar_right_hd.png')
side.transpose(Image.FLIP_LEFT_RIGHT).save('assets/sprites/vehicles/supercar_left_hd.png')
car_down().save('assets/sprites/vehicles/supercar_down_hd.png')
car_up().save('assets/sprites/vehicles/supercar_up_hd.png')

prev = Image.new('RGBA', (S * 4 + 170, S * 2), (110, 110, 115, 255))
prev.paste(sheet, (0, 0), sheet)
x = S * 4 + 6
for n in ('right', 'down', 'up'):
	t = Image.open('assets/sprites/vehicles/supercar_%s_hd.png' % n)
	prev.paste(t, (x, 4), t); x += t.width + 6
prev.resize((prev.width * 4, prev.height * 4), Image.NEAREST).save('_varmuuskopio/tori/vehicles2_preview.png')
print('ok')
