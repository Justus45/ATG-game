# Kallen hahmokuva (kalle_hd.png): skinhead. Pohjana kalju hahmotyyppi 4, josta:
# ruskettuneempi iho ja sänki päälaella, tatuoinnit (kyynel silmän alla, ohimo, takaraivon
# hämähäkinseitti, niska), musta nahkatakki vetoketjuineen, tummat farkut ja maiharit.
# Sarakkeet 0 vasen, 1 alas, 2 ylös, 3 oikea; rivit = askel 0-2.
from PIL import Image
SRC='assets/sprites/player/characters_hd.png'
OUT='assets/sprites/player/kalle_hd.png'
BASE_ROW=12
SKIN={(246,188,145):(232,168,124),(222,146,110):(200,126,92),(255,212,176):(244,194,156),
      (255,232,208):(248,212,178),(206,150,120):(186,128,96)}
JACKET={(138,142,156):(38,35,40),(98,102,116):(24,22,26),(174,178,190):(82,76,84),(40,40,50):(12,11,14)}
PANTS={(38,40,48):(46,56,82),(84,86,98):(72,86,116),(58,60,70):(34,42,62)}
SHOES={(242,242,246):(52,40,32),(20,18,26):(18,14,14),(70,69,80):(30,24,22)}
INK=(34,58,84,255)
src=Image.open(SRC).convert('RGBA')
out=Image.new('RGBA',(128,96),(0,0,0,0))
def isskin(p): return p[3]>128 and p[0]>180 and p[1]>110 and p[0]>p[2]+40
for step in range(3):
    for col in range(4):
        fr=src.crop((col*32,(BASE_ROW+step)*32,col*32+32,(BASE_ROW+step)*32+32)); px=fr.load()
        jy=[]
        for y in range(32):
            for x in range(32):
                p=px[x,y]
                if p[3]<128: continue
                k=p[:3]
                if k in SKIN: px[x,y]=SKIN[k]+(255,)
                elif k in JACKET and y>=13: px[x,y]=JACKET[k]+(255,); jy.append((x,y))
                elif k in PANTS and y>=20: px[x,y]=PANTS[k]+(255,)
                elif k in SHOES and y>=26: px[x,y]=SHOES[k]+(255,)
        # sänki päälaella
        top_rows = range(3,11) if col==2 else range(3,7)
        for y in top_rows:
            for x in range(32):
                if isskin(px[x,y]):
                    r,g,b,a=px[x,y]; px[x,y]=(r-22,g-20,b-12,255)
        def ink(x,y):
            if 0<=x<32 and 0<=y<32 and px[x,y][3]>128: px[x,y]=INK
        if jy:
            xs=[p[0] for p in jy]; cx=(min(xs)+max(xs))//2; top=min(p[1] for p in jy)
            if col==1:
                for y in range(top+2,top+9):
                    if px[cx,y][3]>128 and px[cx,y][:3] in [v for v in JACKET.values()]: px[cx,y]=(160,160,168,255)
        if col==1:
            ink(12,13); ink(12,14)            # kyynel vasemman silmän alla
            for (x,y) in [(21,7),(22,8),(21,8),(22,7)]:
                if isskin(px[x,y]) or px[x,y][:3]!=(0,0,0): ink(x,y)   # ohimotatuointi
        elif col==2:
            for (x,y) in [(16,5),(15,6),(17,6),(16,7),(14,7),(18,7),(16,8),(15,9),(17,9),(16,10)]: ink(x,y)  # seitti
        elif col==0:
            for (x,y) in [(17,7),(18,7),(17,8),(19,8),(18,9)]: ink(x,y)
            for (x,y) in [(19,13),(19,14)]: ink(x,y)   # niska
        else:
            for (x,y) in [(14,7),(13,7),(14,8),(12,8),(13,9)]: ink(x,y)
            for (x,y) in [(12,13),(12,14)]: ink(x,y)
        out.paste(fr,(col*32,step*32))
out.save(OUT)
prev=Image.new('RGBA',out.size,(120,140,120,255)); prev.alpha_composite(out)
prev.resize((out.size[0]*5,out.size[1]*5),Image.NEAREST).save('_varmuuskopio/_kalle_preview.png')
print('ok')
