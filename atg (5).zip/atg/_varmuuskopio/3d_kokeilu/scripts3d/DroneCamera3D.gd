class_name DroneCamera3D
extends Camera3D
## Dronekamera: leijuu pelaajan (tai ajettavan auton) yläpuolella viistosti etelästä,
## katsoo kohti kohdetta. Autolla kamera nousee vauhdin mukaan ja katsoo ajosuuntaan.
## Hiiren rulla = zoomi, F4 = kamerakulma.

const PITCHES := [58.0, 74.0, 44.0]

var distance := 26.0
var zoom := 1.0
var _zoom_s := 1.0
var _pitch_i := 0
var _pitch := 58.0
var _look := Vector3.ZERO
var _speed_k := 0.0
var _shake := 0.0
var _started := false


func _ready() -> void:
	fov = 48.0
	near = 0.3
	far = 600.0
	if not InputMap.has_action("camera_angle"):
		InputMap.add_action("camera_angle")
		var ev := InputEventKey.new()
		ev.physical_keycode = KEY_F4
		InputMap.action_add_event("camera_angle", ev)


func shake(amount: float) -> void:
	_shake = maxf(_shake, amount)


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and (event as InputEventMouseButton).pressed:
		var mb := event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_WHEEL_UP:
			zoom = clampf(zoom * 0.9, 0.45, 2.2)
		elif mb.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			zoom = clampf(zoom * 1.1, 0.45, 2.2)
	elif event.is_action_pressed("camera_angle"):
		_pitch_i = (_pitch_i + 1) % PITCHES.size()


func _process(dt: float) -> void:
	var lv := Effects3D.level(get_tree())
	if lv == null:
		return
	var focus: Vector3 = lv.focus_position()
	var lead := Vector3.ZERO
	var car: Car3D = lv.focus_car()
	var spd := 0.0
	if car:
		spd = absf(car.speed)
		lead = Vector3(car.velocity.x, 0, car.velocity.z) * 0.55
		if lead.length() > 12.0:
			lead = lead.normalized() * 12.0
	_speed_k = lerpf(_speed_k, clampf(spd / 25.0, 0.0, 1.0), clampf(dt * 1.5, 0.0, 1.0))
	if not _started:
		_started = true
		_look = focus
	_look = _look.lerp(focus + lead, clampf(dt * 4.0, 0.0, 1.0))
	_zoom_s = lerpf(_zoom_s, zoom, clampf(dt * 6.0, 0.0, 1.0))
	_pitch = lerpf(_pitch, float(PITCHES[_pitch_i]), clampf(dt * 4.0, 0.0, 1.0))
	var d := distance * _zoom_s * (1.0 + _speed_k * 0.4)
	var p := deg_to_rad(_pitch)
	var pos := _look + Vector3(0.0, sin(p), cos(p)) * d
	if _shake > 0.01:
		pos += Vector3(randf_range(-1, 1), randf_range(-1, 1), randf_range(-1, 1)) * _shake
		_shake = move_toward(_shake, 0.0, dt * maxf(_shake * 5.0, 1.0))
	look_at_from_position(pos, _look, Vector3.UP)
