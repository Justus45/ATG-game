class_name Police3D
extends Node
## Etsintäkuulutus 3D-versiossa: rikokset nostavat "lämpöä", lämpö antaa tähdet (1-5).
## Tähtien mukaan kaupunkiin tulee poliisiautoja (ajavat teitä pitkin pelaajan luo),
## jotka päästävät poliiseja ulos. Kun poliisi ei näe pelaajaa tarpeeksi pitkään,
## etsintä loppuu. Pidätys: poliisi pääsee viereen (1 tähti) tai auto saarretaan.

const STAR_HEAT := [0, 1, 4, 9, 15, 22]
const SIGHT := 42.0

var heat := 0
var stars := 0
var searching := false
var _unseen := 0.0
var _spawn_cd := 0.0
var _bust := 0.0
var _gun_cd := 0.0
var _hud_stars := -1
var _hud_search := false


func _ready() -> void:
	add_to_group("police3d")


func player() -> Player3D:
	return Effects3D.player(get_tree()) as Player3D


func player_in_car() -> bool:
	var p := player()
	return p != null and p.current_car != null


func target_position() -> Vector3:
	var p := player()
	if p == null:
		return Vector3.ZERO
	if p.current_car and is_instance_valid(p.current_car):
		return p.current_car.global_position
	return p.global_position


func crime(points: int, _at: Vector3) -> void:
	var p := player()
	if p == null or p.dead:
		return
	heat += points
	Game.note_crime()
	_unseen = 0.0
	_recalc()


## Pelaaja ampui: lähellä olevat pakenevat, todistajat soittavat poliisille.
func gunshot(at: Vector3) -> void:
	var witnesses := 0
	for p in get_tree().get_nodes_in_group("pedestrians"):
		var n3 := p as Node3D
		if n3 and not bool(p.get("dead")) and n3.global_position.distance_to(at) < 26.0:
			p.scare(at)
			witnesses += 1
	var cops_near := false
	for o in _units():
		if (o as Node3D).global_position.distance_to(at) < 35.0:
			cops_near = true
			break
	if (cops_near or witnesses > 0) and stars == 0 and _gun_cd <= 0.0:
		_gun_cd = 4.0
		crime(1, at)


func _recalc() -> void:
	var s := 0
	for i in range(1, STAR_HEAT.size()):
		if heat >= int(STAR_HEAT[i]):
			s = i
	if s != stars:
		if s > stars and s >= 1:
			Effects3D.msg(get_tree(), ["", "Poliisi on kannoillasi!", "Poliisi ampuu!", "Lisää partioita!", "Koko poliisivoimat!", "Kaikki yksiköt perään!"][s], 2.0)
		stars = s
	_update_hud()


func _update_hud() -> void:
	var hud := Effects3D.hud(get_tree())
	if hud == null:
		return
	if _hud_stars != stars:
		_hud_stars = stars
		hud.set_wanted(stars)
	if _hud_search != searching:
		_hud_search = searching
		hud.set_searching(searching)


func _units() -> Array:
	var out: Array = []
	for o in get_tree().get_nodes_in_group("officers"):
		if not bool(o.get("dead")):
			out.append(o)
	for c in get_tree().get_nodes_in_group("cars"):
		var car := c as Car3D
		if car and car.police and not car.exploded and car.mode == Car3D.Mode.POLICE:
			out.append(car)
	return out


func add_bust(dt: float) -> void:
	_bust += dt * 2.0


func _process(dt: float) -> void:
	_spawn_cd -= dt
	_gun_cd -= dt
	_bust = maxf(_bust - dt, 0.0)
	var p := player()
	if p == null:
		return
	var tgt := target_position()
	_prune(tgt)
	if stars <= 0:
		Sfx.set_siren(0.0)
		searching = false
		_update_hud()
		return
	if p.dead:
		return
	# Näkeekö joku poliisi pelaajan?
	var seen := false
	var nearest := INF
	for u in _units():
		var n3 := u as Node3D
		var d := n3.global_position.distance_to(tgt)
		nearest = minf(nearest, d)
		if not seen and d < SIGHT and Effects3D.los(n3, n3.global_position + Vector3(0, 1.4, 0), tgt + Vector3(0, 1.2, 0)):
			seen = true
	if seen:
		_unseen = 0.0
	else:
		_unseen += dt
	searching = _unseen > 2.0
	_update_hud()
	if _unseen > 10.0 + stars * 4.0:
		Effects3D.msg(get_tree(), "Poliisi luopui etsinnästä.", 2.5)
		heat = 0
		stars = 0
		_unseen = 0.0
		_bust = 0.0
		_update_hud()
		return
	Sfx.set_siren(clampf(1.0 - nearest / 70.0, 0.0, 1.0) if nearest < INF else 0.0)
	_maintain(tgt)
	if _bust > 1.6:
		_bust = 0.0
		var lv := Effects3D.level(get_tree())
		if lv and lv.has_method("player_busted"):
			lv.player_busted()


func _maintain(tgt: Vector3) -> void:
	if _spawn_cd > 0.0:
		return
	var city := Effects3D.city(get_tree())
	var lv := Effects3D.level(get_tree())
	if city == null or lv == null:
		return
	var cars := 0
	for c in get_tree().get_nodes_in_group("cars"):
		var car := c as Car3D
		if car and car.police and not car.exploded and car.mode == Car3D.Mode.POLICE:
			cars += 1
	var want_cars := mini(stars + (1 if stars >= 3 else 0), 6)
	if cars < want_cars:
		var spot := city.random_lane_spot(tgt, 50.0, 95.0)
		if not spot.is_empty():
			var car: Car3D = lv.spawn_car(spot, true)
			car.mode = Car3D.Mode.POLICE
			car.npc_owned = true
			_spawn_cd = 3.0
			return
	var foot := get_tree().get_nodes_in_group("officers").size()
	if stars >= 3 and foot < stars * 2:
		for t in 20:
			var c := city.world_to_cell(tgt) + Vector2i(randi_range(-24, 24), randi_range(-24, 24))
			if city.ped_walkable(c):
				var p3 := city.cell_center(c)
				var d := p3.distance_to(tgt)
				if d > 32.0 and d < 55.0:
					lv.spawn_officer(p3)
					_spawn_cd = 2.0
					return


## Poliisiauto pysähtyi pelaajan lähelle: kaksi poliisia ulos.
func unload_officers(car: Car3D) -> void:
	var lv := Effects3D.level(get_tree())
	if lv == null:
		return
	if get_tree().get_nodes_in_group("officers").size() > 14:
		return
	for sx: float in [-2.0, 2.0]:
		lv.spawn_officer(car.global_position + car.global_transform.basis.x * sx)


func _prune(tgt: Vector3) -> void:
	for o in get_tree().get_nodes_in_group("officers"):
		var n3 := o as Node3D
		var d := n3.global_position.distance_to(tgt)
		var dead_long := bool(o.get("dead")) and float(o.get("_dead_t")) > 25.0
		if d > 110.0 or (stars == 0 and d > 45.0) or dead_long:
			o.queue_free()
	for c in get_tree().get_nodes_in_group("cars"):
		var car := c as Car3D
		if car == null or not car.police or car.mode == Car3D.Mode.PLAYER:
			continue
		var d := car.global_position.distance_to(tgt)
		if d > 130.0 or (stars == 0 and d > 70.0):
			car.queue_free()


## Kaikki poliisit pois (pidätys / kuolema).
func clear() -> void:
	heat = 0
	stars = 0
	_unseen = 0.0
	_bust = 0.0
	searching = false
	for o in get_tree().get_nodes_in_group("officers"):
		o.queue_free()
	for c in get_tree().get_nodes_in_group("cars"):
		var car := c as Car3D
		if car and car.police and car.mode != Car3D.Mode.PLAYER:
			car.queue_free()
	Sfx.set_siren(0.0)
	_update_hud()
