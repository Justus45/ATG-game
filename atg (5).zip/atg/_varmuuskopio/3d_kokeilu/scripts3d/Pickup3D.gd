class_name Pickup3D
extends Area3D
## Maassa leijuva poimittava: ase (WeaponDB-id) tai raha. Pelaaja poimii kävelemällä päälle.

var kind := "weapon"     ## "weapon" / "money"
var weapon_id := "pistol"
var amount := 10
var _t := 0.0
var _vis: Node3D
var _arm := 0.4          ## lyhyt viive, ettei pudotettu ase poimiudu heti takaisin


func _ready() -> void:
	collision_layer = Effects3D.L_PICKUPS
	collision_mask = Effects3D.L_PEOPLE
	monitoring = true
	var cs := CollisionShape3D.new()
	var sph := SphereShape3D.new()
	sph.radius = 0.8
	cs.shape = sph
	cs.position.y = 0.8
	add_child(cs)
	_vis = Node3D.new()
	add_child(_vis)
	if kind == "weapon":
		var s := Sprite3D.new()
		s.texture = WeaponDB.icon(weapon_id)
		s.pixel_size = 0.06
		s.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		s.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
		s.alpha_cut = SpriteBase3D.ALPHA_CUT_DISCARD
		s.shaded = false
		s.position.y = 0.9
		_vis.add_child(s)
		var ring := MeshInstance3D.new()
		var tm := TorusMesh.new()
		tm.inner_radius = 0.45
		tm.outer_radius = 0.55
		ring.mesh = tm
		ring.material_override = Effects3D.mat(Color(1.0, 0.85, 0.2), 2.0)
		ring.position.y = 0.05
		add_child(ring)
	else:
		Effects3D.box(_vis, Vector3(0.45, 0.06, 0.25), Vector3(0, 0.35, 0), Color(0.3, 0.75, 0.3), 0.6)
		Effects3D.box(_vis, Vector3(0.45, 0.06, 0.25), Vector3(0.05, 0.42, 0.04), Color(0.35, 0.8, 0.35), 0.6)
	body_entered.connect(_on_body)


func _process(dt: float) -> void:
	_t += dt
	_arm -= dt
	_vis.rotation.y = _t * 2.0
	_vis.position.y = sin(_t * 3.0) * 0.08
	if _arm <= 0.0 and monitoring:
		for b in get_overlapping_bodies():
			_on_body(b)


func _on_body(b: Node) -> void:
	if _arm > 0.0 or is_queued_for_deletion():
		return
	if not (b is Player3D) or bool(b.get("dead")):
		return
	var p := b as Player3D
	if kind == "weapon":
		p.give_weapon(weapon_id, true)
		Effects3D.msg(get_tree(), "Poimit: %s" % WeaponDB.display_name(weapon_id), 1.8)
		Effects3D.sound(get_tree(), "clink", global_position)
	else:
		p.add_money(amount)
	queue_free()
