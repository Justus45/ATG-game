class_name Pedestrian3D
extends CharacterBody3D
## Jalankulkija: kävelee jalkakäytäviä ja puistoja pitkin ruudusta toiseen, pakenee
## laukauksia ja uhkaa, voidaan ryöstää (R), kuolee luodeista / auton alle jäädessään
## ja pudottaa rahaa. Pelaajan tekemä tappo on rikos (Police3D).

var hp := 3.0
var dead := false
var robbed := false
var model: Humanoid3D
var _cell := Vector2i.ZERO
var _dir := Vector2i(1, 0)
var _target := Vector3.ZERO
var _speed := 1.4
var _flee_t := 0.0
var _threat := Vector3.ZERO
var _dead_t := 0.0
var _wait := 0.0
var _fly := Vector3.ZERO


func _ready() -> void:
	add_to_group("pedestrians")
	add_to_group("people")
	add_to_group("damageable")
	motion_mode = CharacterBody3D.MOTION_MODE_FLOATING
	collision_layer = Effects3D.L_PEOPLE
	collision_mask = Effects3D.L_WORLD | Effects3D.L_CARS
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.3
	cap.height = 1.75
	cs.shape = cap
	cs.position.y = 0.88
	add_child(cs)
	if model == null:
		var rng := RandomNumberGenerator.new()
		rng.randomize()
		model = Humanoid3D.new()
		add_child(model)
		model.build_random(rng)
	_speed = randf_range(1.1, 1.7)
	_wait = randf_range(0.0, 2.0)


func place(c: Vector2i) -> void:
	var city := Effects3D.city(get_tree())
	_cell = c
	global_position = city.cell_center(c) + Vector3(randf_range(-0.5, 0.5), 0, randf_range(-0.5, 0.5))
	var dirs: Array[Vector2i] = [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]
	_dir = dirs[randi() % 4]
	_pick_next(city)


func _pick_next(city: City3D) -> void:
	var opts: Array[Vector2i] = []
	for d: Vector2i in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
		if d == -_dir:
			continue
		if city.ped_walkable(_cell + d):
			opts.append(d)
	var nd := _dir
	if opts.is_empty():
		nd = -_dir
		if not city.ped_walkable(_cell + nd):
			_target = global_position
			_wait = 1.0
			return
	elif not opts.has(_dir) or randf() < 0.15:
		nd = opts[randi() % opts.size()]
	_dir = nd
	_cell += nd
	_target = city.cell_center(_cell) + Vector3(randf_range(-0.35, 0.35), 0, randf_range(-0.35, 0.35))


func _physics_process(dt: float) -> void:
	if dead:
		_dead_t += dt
		if _fly.length() > 0.1:
			_fly = _fly.move_toward(Vector3.ZERO, 14.0 * dt)
			global_position += _fly * dt
		return
	var city := Effects3D.city(get_tree())
	if city == null:
		return
	var move := Vector3.ZERO
	if _flee_t > 0.0:
		_flee_t -= dt
		var away := global_position - _threat
		away.y = 0.0
		if away.length() < 0.1:
			away = Vector3(randf() - 0.5, 0, randf() - 0.5)
		move = away.normalized() * 5.0
		if _flee_t <= 0.0:
			_cell = city.world_to_cell(global_position)
			_pick_next(city)
	elif _wait > 0.0:
		_wait -= dt
	else:
		var to := _target - global_position
		to.y = 0.0
		if to.length() < 0.25:
			if randf() < 0.02:
				_wait = randf_range(1.0, 3.0)
			_pick_next(city)
		else:
			move = to.normalized() * _speed
	velocity = move
	move_and_slide()
	global_position.y = 0.0
	if move.length() > 0.1:
		rotation.y = lerp_angle(rotation.y, atan2(-move.x, -move.z), clampf(dt * 10.0, 0.0, 1.0))
		if _flee_t <= 0.0 and get_slide_collision_count() > 0 and get_real_velocity().length() < 0.2:
			_pick_next(city)
	model.animate(dt, move.length())


func scare(from: Vector3) -> void:
	if dead:
		return
	_flee_t = randf_range(5.0, 8.0)
	_threat = from


func get_robbed(by: Node3D) -> void:
	robbed = true
	scare(by.global_position)
	Effects3D.float_text(get_tree(), global_position + Vector3(0, 2.1, 0), ["Älä ammu!", "Ota rahat!", "Apua!"][randi() % 3], Color(1, 1, 0.7))


func take_damage(amount: float, source: Node = null) -> void:
	if dead:
		return
	hp -= amount
	if source is Node3D:
		scare((source as Node3D).global_position)
	if hp <= 0.0:
		_die(source)


func blast(at: Vector3, k: float, source: Node) -> void:
	if dead:
		return
	var away := global_position - at
	away.y = 0.0
	_fly = away.normalized() * 10.0 * k
	_die(source)


func hit_by_car(vel: Vector3, car: Node) -> bool:
	if dead or vel.length() < 2.5:
		return false
	_fly = vel * 0.8
	var src: Node = car
	if car != null and car.get("mode") == Car3D.Mode.PLAYER:
		src = Effects3D.player(get_tree())
	Effects3D.sound(get_tree(), "thud", global_position)
	_die(src)
	return true


func _die(source: Node) -> void:
	dead = true
	collision_layer = 0
	collision_mask = 0
	model.die()
	Effects3D.blood(get_tree(), global_position + Vector3(0, 0.5, 0))
	if randf() < 0.75:
		var lv := Effects3D.level(get_tree())
		if lv and lv.has_method("spawn_money_pickup"):
			lv.spawn_money_pickup(global_position + Vector3(randf_range(-0.5, 0.5), 0, randf_range(-0.5, 0.5)), randi_range(5, 30))
	if source != null and source.is_in_group("player"):
		var pol := Effects3D.police(get_tree())
		if pol:
			pol.crime(2, global_position)
	for p in get_tree().get_nodes_in_group("pedestrians"):
		var n3 := p as Node3D
		if n3 and n3 != self and n3.global_position.distance_to(global_position) < 14.0:
			p.scare(global_position)
