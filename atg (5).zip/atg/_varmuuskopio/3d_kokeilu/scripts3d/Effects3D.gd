class_name Effects3D
extends RefCounted
## Yhteiset apufunktiot 3D-versiolle: materiaalit, laatikot, osumat (hitscan),
## luotiviivat, kipinät, veri, räjähdykset, äänet ja viestit.

const L_WORLD := 1      ## talot, puut, lamput, reunat
const L_CARS := 2
const L_PEOPLE := 4
const L_PICKUPS := 8

static var _mats := {}
static var _boxes := {}
static var _blood: Array = []


static func mat(c: Color, emissive: float = 0.0) -> StandardMaterial3D:
	var key := "%s|%.2f" % [c.to_html(true), emissive]
	if _mats.has(key):
		return _mats[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 0.75
	if c.a < 0.999:
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	if emissive > 0.0:
		m.emission_enabled = true
		m.emission = c
		m.emission_energy_multiplier = emissive
	_mats[key] = m
	return m


static func box_mesh(size: Vector3) -> BoxMesh:
	var key := "%.3f|%.3f|%.3f" % [size.x, size.y, size.z]
	if _boxes.has(key):
		return _boxes[key]
	var b := BoxMesh.new()
	b.size = size
	_boxes[key] = b
	return b


static func box(parent: Node3D, size: Vector3, pos: Vector3, c: Color, emissive: float = 0.0) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = box_mesh(size)
	mi.material_override = mat(c, emissive)
	mi.position = pos
	parent.add_child(mi)
	return mi


static func city(tree: SceneTree) -> City3D:
	return tree.get_first_node_in_group("city3d") as City3D


static func level(tree: SceneTree) -> Node:
	return tree.get_first_node_in_group("level3d")


static func police(tree: SceneTree) -> Node:
	return tree.get_first_node_in_group("police3d")


static func player(tree: SceneTree) -> Node3D:
	return tree.get_first_node_in_group("player") as Node3D


static func hud(tree: SceneTree) -> Node:
	var s := tree.current_scene
	return s.get_node_or_null("Hud") if s else null


static func msg(tree: SceneTree, text: String, seconds: float = 2.5) -> void:
	var h := hud(tree)
	if h and h.has_method("show_message"):
		h.show_message(text, seconds)


## Ääni etäisyyden mukaan vaimennettuna (Sfx-autoloadin generoidut äänet).
static func sound(tree: SceneTree, name: String, at: Vector3, vol: float = 0.0, pitch: float = 1.0) -> void:
	var cam := tree.root.get_camera_3d()
	var d := 0.0
	if cam:
		var focus := cam.global_position
		var lv := level(tree)
		if lv and lv.has_method("focus_position"):
			focus = lv.focus_position()
		d = focus.distance_to(at)
	if d > 80.0:
		return
	Sfx.play_ui(name, vol - d * 0.35, pitch * randf_range(0.94, 1.06))


## Näköyhteys (vain maailman esteet: talot, puut).
static func los(from_node: Node3D, a: Vector3, b: Vector3) -> bool:
	var q := PhysicsRayQueryParameters3D.create(a, b, L_WORLD)
	return from_node.get_world_3d().direct_space_state.intersect_ray(q).is_empty()


## Ampuu säteen from -> to. Osuma kohteeseen, jolla take_damage(). Palauttaa osuman.
static func hitscan(from_node: Node3D, from: Vector3, to: Vector3, damage: float, source: Node, exclude: Array = []) -> Dictionary:
	var q := PhysicsRayQueryParameters3D.create(from, to, L_WORLD | L_CARS | L_PEOPLE)
	q.exclude = exclude
	var hit := from_node.get_world_3d().direct_space_state.intersect_ray(q)
	var end := to
	if not hit.is_empty():
		end = hit.position
		var col = hit.collider
		if col and col.has_method("take_damage"):
			col.take_damage(damage, source)
			if col.is_in_group("people"):
				blood(from_node.get_tree(), end)
			else:
				sparks(from_node.get_tree(), end, Color(1.0, 0.85, 0.4), 6)
		else:
			sparks(from_node.get_tree(), end, Color(0.9, 0.9, 0.8), 5)
	tracer(from_node.get_tree(), from, end)
	return hit


static func _root3d(tree: SceneTree) -> Node:
	var lv := level(tree)
	return lv if lv else tree.current_scene


static func tracer(tree: SceneTree, a: Vector3, b: Vector3) -> void:
	var len := a.distance_to(b)
	if len < 0.05:
		return
	var mi := MeshInstance3D.new()
	mi.mesh = box_mesh(Vector3(0.035, 0.035, len))
	mi.material_override = mat(Color(1.0, 0.9, 0.5), 4.0)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_root3d(tree).add_child(mi)
	var dir := (b - a).normalized()
	var up := Vector3.UP if absf(dir.dot(Vector3.UP)) < 0.98 else Vector3.RIGHT
	mi.global_transform = Transform3D(Basis.looking_at(dir, up), (a + b) * 0.5)
	tree.create_timer(0.05).timeout.connect(mi.queue_free)


static func flash(tree: SceneTree, at: Vector3, col: Color, energy: float, range_m: float, time: float) -> void:
	var l := OmniLight3D.new()
	l.light_color = col
	l.light_energy = energy
	l.omni_range = range_m
	_root3d(tree).add_child(l)
	l.global_position = at
	var tw := l.create_tween()
	tw.tween_property(l, "light_energy", 0.0, time)
	tw.tween_callback(l.queue_free)


static func sparks(tree: SceneTree, at: Vector3, col: Color, count: int) -> void:
	var p := CPUParticles3D.new()
	p.one_shot = true
	p.explosiveness = 1.0
	p.amount = maxi(count, 1)
	p.lifetime = 0.35
	p.mesh = box_mesh(Vector3(0.06, 0.06, 0.06))
	p.material_override = mat(col, 3.0)
	p.direction = Vector3.UP
	p.spread = 80.0
	p.initial_velocity_min = 2.0
	p.initial_velocity_max = 5.0
	p.gravity = Vector3(0, -12, 0)
	_root3d(tree).add_child(p)
	p.global_position = at
	p.emitting = true
	tree.create_timer(1.0).timeout.connect(p.queue_free)


static func blood(tree: SceneTree, at: Vector3) -> void:
	sparks(tree, at, Color(0.6, 0.02, 0.02), 8)
	var mi := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2.ONE * randf_range(0.6, 1.2)
	mi.mesh = pm
	mi.material_override = mat(Color(0.45, 0.02, 0.02, 0.85))
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_root3d(tree).add_child(mi)
	mi.global_position = Vector3(at.x + randf_range(-0.3, 0.3), 0.015 + randf() * 0.01, at.z + randf_range(-0.3, 0.3))
	mi.rotation.y = randf() * TAU
	_blood.append(mi)
	while _blood.size() > 70:
		var old = _blood.pop_front()
		if is_instance_valid(old):
			old.queue_free()


static func smoke(tree: SceneTree, at: Vector3, dark: bool) -> void:
	var p := CPUParticles3D.new()
	p.one_shot = true
	p.amount = 1
	p.lifetime = 1.4
	var sm := SphereMesh.new()
	sm.radius = 0.35
	sm.height = 0.7
	sm.radial_segments = 6
	sm.rings = 3
	p.mesh = sm
	p.material_override = mat(Color(0.1, 0.1, 0.1, 0.55) if dark else Color(0.7, 0.7, 0.7, 0.45))
	p.direction = Vector3.UP
	p.spread = 15.0
	p.initial_velocity_min = 1.0
	p.initial_velocity_max = 2.0
	p.gravity = Vector3(0, 0.5, 0)
	p.scale_amount_min = 0.8
	p.scale_amount_max = 1.6
	_root3d(tree).add_child(p)
	p.global_position = at
	p.emitting = true
	tree.create_timer(2.0).timeout.connect(p.queue_free)


## Räjähdys: valo, liekit, savu, ääni ja vahinko säteellä.
static func explosion(tree: SceneTree, at: Vector3, source: Node) -> void:
	flash(tree, at + Vector3(0, 1.5, 0), Color(1.0, 0.6, 0.25), 12.0, 18.0, 0.6)
	sparks(tree, at + Vector3(0, 0.8, 0), Color(1.0, 0.55, 0.1), 40)
	for i in 6:
		smoke(tree, at + Vector3(randf_range(-1, 1), 1.0, randf_range(-1, 1)), true)
	sound(tree, "explosion", at, 4.0)
	var lv := level(tree)
	if lv and lv.has_method("shake"):
		lv.shake(at, 0.8)
	for n in tree.get_nodes_in_group("damageable"):
		var n3 := n as Node3D
		if n3 == null or n == source:
			continue
		var d := n3.global_position.distance_to(at)
		if d < 7.0:
			if n.has_method("blast"):
				n.blast(at, 1.0 - d / 7.0, source)
			elif n.has_method("take_damage"):
				n.take_damage(10.0 * (1.0 - d / 7.0), source)


static func float_text(tree: SceneTree, at: Vector3, text: String, col: Color) -> void:
	var l := Label3D.new()
	l.text = text
	l.font_size = 64
	l.pixel_size = 0.012
	l.outline_size = 12
	l.modulate = col
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.no_depth_test = true
	_root3d(tree).add_child(l)
	l.global_position = at
	var tw := l.create_tween()
	tw.set_parallel(true)
	tw.tween_property(l, "global_position", at + Vector3(0, 1.6, 0), 1.0)
	tw.tween_property(l, "modulate:a", 0.0, 1.0)
	tw.chain().tween_callback(l.queue_free)
