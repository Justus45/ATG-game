class_name Car3D
extends CharacterBody3D
## 3D-auto. Sama luokka hoitaa pelaajan ajaman auton, pysäköidyt autot, liikenteen
## (kaistat ja risteykset City3D:n reittipisteillä) sekä poliisiautot (jahtaavat pelaajaa
## teitä pitkin, pysähtyvät ja päästävät poliisit ulos, rammaavat autoa).
##
## Ajo: W/ylös kaasu, S/alas jarru ja peruutus, A/D ohjaus, välilyönti käsijarru (sladi).
## Kolarit vahingoittavat autoa; kunnon loppuessa auto syttyy palamaan ja räjähtää.

enum Mode { PARKED, PLAYER, TRAFFIC, POLICE }

const COLORS := [
	Color(0.75, 0.12, 0.1), Color(0.12, 0.45, 0.2), Color(0.9, 0.75, 0.15), Color(0.15, 0.3, 0.7),
	Color(0.85, 0.85, 0.85), Color(0.15, 0.15, 0.17), Color(0.55, 0.15, 0.55), Color(0.9, 0.45, 0.1),
	Color(0.4, 0.6, 0.75), Color(0.5, 0.5, 0.52),
]
const MAX_HEALTH := 100.0
const BURN_TIME := 4.5

var mode := Mode.PARKED
var body_color := Color(0.75, 0.12, 0.1)
var police := false
var max_speed := 24.0
var accel := 11.0
var brake_force := 26.0
var reverse_max := 7.0
var steer_rate := 2.3
var health := MAX_HEALTH
var burning := false
var exploded := false
## true = auto kuuluu jollekulle muulle: sisään nouseminen on varkaus
var npc_owned := true
var driver: Node = null
var speed := 0.0
var siren_on := false
var unloaded := false

var _burn_t := 0.0
var _by_player := false
var _exit_cd := 0.0
var _crash_cd := 0.0
var _horn_cd := 0.0
var _smoke_acc := 0.0
var _steer_vis := 0.0
var _wheel_rot := 0.0
var _t := 0.0
var _model: Node3D
var _body_mi: MeshInstance3D
var _roof_mi: MeshInstance3D
var _wheels: Array[Node3D] = []
var _front: Array[Node3D] = []
var _bar: Array[MeshInstance3D] = []
var _siren_light: OmniLight3D
var _heads: Array[SpotLight3D] = []
var _fire: CPUParticles3D
var _dmg_step := 0

# --- Tekoäly ---
var _wp: Array = []
var _route_j := Vector2i(-1, -1)
var _route_d := Vector2i(0, 1)
var _lock := Vector2i(-1, -1)
var _blocked_t := 0.0
var _cruise := 10.0
var _reverse_t := 0.0
var _stuck_t := 0.0

static var _wheel_mesh: CylinderMesh


func _ready() -> void:
	add_to_group("cars")
	add_to_group("damageable")
	motion_mode = CharacterBody3D.MOTION_MODE_FLOATING
	collision_layer = Effects3D.L_CARS
	collision_mask = Effects3D.L_WORLD | Effects3D.L_CARS | Effects3D.L_PEOPLE
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = Vector3(1.9, 1.4, 4.3)
	cs.shape = bs
	cs.position.y = 0.75
	add_child(cs)
	if police:
		max_speed = 27.0
		accel = 13.0
	_build_model()


func _build_model() -> void:
	_model = Node3D.new()
	_model.name = "Model"
	add_child(_model)
	var c := Color(0.95, 0.95, 0.97) if police else body_color
	_body_mi = Effects3D.box(_model, Vector3(1.84, 0.62, 4.2), Vector3(0, 0.66, 0), c)
	if police:
		Effects3D.box(_model, Vector3(1.88, 0.22, 4.0), Vector3(0, 0.55, 0), Color(0.08, 0.12, 0.42))
		Effects3D.box(_model, Vector3(1.86, 0.3, 1.0), Vector3(0, 0.66, -1.5), Color(0.05, 0.05, 0.08))
	Effects3D.box(_model, Vector3(1.62, 0.55, 2.1), Vector3(0, 1.24, 0.25), Color(0.1, 0.14, 0.2))
	_roof_mi = Effects3D.box(_model, Vector3(1.66, 0.08, 1.9), Vector3(0, 1.54, 0.3), c)
	Effects3D.box(_model, Vector3(1.88, 0.2, 0.14), Vector3(0, 0.44, -2.12), Color(0.15, 0.15, 0.15))
	Effects3D.box(_model, Vector3(1.88, 0.2, 0.14), Vector3(0, 0.44, 2.12), Color(0.15, 0.15, 0.15))
	for sx: float in [-0.62, 0.62]:
		Effects3D.box(_model, Vector3(0.38, 0.16, 0.06), Vector3(sx, 0.78, -2.11), Color(1.0, 0.97, 0.8), 2.5)
		Effects3D.box(_model, Vector3(0.38, 0.16, 0.06), Vector3(sx, 0.78, 2.11), Color(0.95, 0.05, 0.05), 1.5)
	if _wheel_mesh == null:
		_wheel_mesh = CylinderMesh.new()
		_wheel_mesh.top_radius = 0.36
		_wheel_mesh.bottom_radius = 0.36
		_wheel_mesh.height = 0.28
		_wheel_mesh.radial_segments = 10
		_wheel_mesh.material = Effects3D.mat(Color(0.07, 0.07, 0.07))
	for p: Vector3 in [Vector3(-0.88, 0.36, -1.35), Vector3(0.88, 0.36, -1.35), Vector3(-0.88, 0.36, 1.35), Vector3(0.88, 0.36, 1.35)]:
		var pivot := Node3D.new()
		pivot.position = p
		_model.add_child(pivot)
		var spin := Node3D.new()
		pivot.add_child(spin)
		var w := MeshInstance3D.new()
		w.mesh = _wheel_mesh
		w.rotation.z = PI * 0.5
		spin.add_child(w)
		Effects3D.box(spin, Vector3(0.3, 0.12, 0.12), Vector3.ZERO, Color(0.6, 0.6, 0.62))
		_wheels.append(spin)
		if p.z < 0.0:
			_front.append(pivot)
	if police:
		_bar.append(Effects3D.box(_model, Vector3(0.6, 0.16, 0.3), Vector3(-0.36, 1.66, 0.3), Color(0.9, 0.1, 0.1), 1.0))
		_bar.append(Effects3D.box(_model, Vector3(0.6, 0.16, 0.3), Vector3(0.36, 1.66, 0.3), Color(0.1, 0.2, 0.95), 1.0))
		_siren_light = OmniLight3D.new()
		_siren_light.omni_range = 9.0
		_siren_light.light_energy = 0.0
		_siren_light.position = Vector3(0, 2.0, 0.3)
		add_child(_siren_light)


func set_headlights(on: bool) -> void:
	if on and _heads.is_empty():
		for sx: float in [-0.62, 0.62]:
			var s := SpotLight3D.new()
			s.position = Vector3(sx, 0.8, -2.2)
			s.rotation_degrees = Vector3(-8, 0, 0)
			s.spot_range = 24.0
			s.spot_angle = 32.0
			s.light_energy = 3.0
			s.light_color = Color(1.0, 0.95, 0.8)
			add_child(s)
			_heads.append(s)
	for s in _heads:
		s.visible = on and not exploded


# ----------------------------------------------------------------------------
#  AJO
# ----------------------------------------------------------------------------
func _physics_process(dt: float) -> void:
	_t += dt
	_exit_cd -= dt
	_crash_cd -= dt
	_horn_cd -= dt
	if exploded:
		velocity = velocity.move_toward(Vector3.ZERO, 20.0 * dt)
		move_and_slide()
		return
	if burning:
		_burn_t -= dt
		if _burn_t <= 0.0:
			_explode()
			return
	if health < 45.0:
		_smoke_acc += dt
		if _smoke_acc > (0.12 if burning else 0.3):
			_smoke_acc = 0.0
			Effects3D.smoke(get_tree(), global_position + (-global_transform.basis.z) * 1.6 + Vector3(0, 1.0, 0), burning or health < 20.0)

	var ctl := Vector3.ZERO
	match mode:
		Mode.PLAYER:
			ctl = _player_input()
			if Input.is_action_just_pressed("interact") and _exit_cd <= 0.0 and driver and driver.has_method("exit_car"):
				driver.exit_car()
		Mode.TRAFFIC:
			ctl = _ai_traffic(dt)
		Mode.POLICE:
			ctl = _ai_police(dt)
	_drive(dt, ctl.x, ctl.y, ctl.z > 0.5)
	_animate(dt, ctl.y)


func _player_input() -> Vector3:
	if driver and bool(driver.get("police_locked")):
		return Vector3(-1.0, 0.0, 1.0)
	var t := Input.get_axis("ui_down", "ui_up")
	var s := Input.get_axis("ui_left", "ui_right")
	var hb := 1.0 if Input.is_action_pressed("handbrake") else 0.0
	return Vector3(t, s, hb)


func _drive(dt: float, throttle: float, steer: float, handbrake: bool) -> void:
	if mode == Mode.PARKED and absf(speed) < 0.05 and velocity.length() < 0.05:
		velocity = Vector3.ZERO
		speed = 0.0
		return
	var vmax := max_speed
	if mode == Mode.PLAYER:
		vmax *= Game.car_speed_mult()
	if throttle > 0.05:
		if speed < -0.5:
			speed = move_toward(speed, 0.0, brake_force * dt)
		else:
			speed = move_toward(speed, vmax * throttle, accel * dt)
	elif throttle < -0.05:
		if speed > 0.5:
			speed = move_toward(speed, 0.0, brake_force * dt)
		else:
			speed = move_toward(speed, -reverse_max, accel * 0.7 * dt)
	else:
		speed = move_toward(speed, 0.0, 3.5 * dt)
	if handbrake:
		speed = move_toward(speed, 0.0, 8.0 * dt)
	var sf := clampf(absf(speed) / 5.0, 0.0, 1.0) * (1.0 - clampf((absf(speed) - 16.0) / 30.0, 0.0, 0.35))
	rotation.y += -steer * steer_rate * sf * signf(speed) * (1.45 if handbrake else 1.0) * dt
	var fwd := -global_transform.basis.z
	var grip := 2.0 if handbrake else 9.0
	if mode == Mode.PLAYER:
		grip *= Game.road_grip()
	var v := Vector3(velocity.x, 0.0, velocity.z).lerp(fwd * speed, clampf(grip * dt, 0.0, 1.0))
	velocity = v
	var pre := v
	move_and_slide()
	for i in get_slide_collision_count():
		var col := get_slide_collision(i)
		var other = col.get_collider()
		var n := col.get_normal()
		n.y = 0.0
		if n.length() < 0.01:
			continue
		n = n.normalized()
		if other != null and other.has_method("hit_by_car") and pre.length() > 2.5:
			if other.hit_by_car(pre, self):
				continue
		var impact := -pre.dot(n)
		if impact > 5.0 and _crash_cd <= 0.0:
			_crash_cd = 0.35
			var hurt := (impact - 5.0) * 1.6
			_hurt(hurt, false)
			Effects3D.sound(get_tree(), "crash", col.get_position(), clampf(impact * 0.4 - 6.0, -8.0, 3.0))
			Effects3D.sparks(get_tree(), col.get_position(), Color(1.0, 0.8, 0.3), 8)
			if other is Car3D:
				(other as Car3D)._hurt(hurt * 0.8, mode == Mode.PLAYER)
			if mode == Mode.PLAYER:
				var lv := Effects3D.level(get_tree())
				if lv and lv.has_method("shake"):
					lv.shake(global_position, clampf(impact / 25.0, 0.1, 0.6))
	speed = velocity.dot(-global_transform.basis.z)
	global_position.y = 0.0


func _animate(dt: float, steer: float) -> void:
	_wheel_rot += speed * dt / 0.36
	for w in _wheels:
		w.rotation.x = -_wheel_rot
	_steer_vis = lerpf(_steer_vis, -steer * 0.5, clampf(dt * 10.0, 0.0, 1.0))
	for f in _front:
		f.rotation.y = _steer_vis
	if police:
		var on := siren_on and not exploded
		var ph := int(_t * 6.0) % 2 == 0
		if _bar.size() == 2:
			_bar[0].material_override = Effects3D.mat(Color(1.0, 0.1, 0.1), 5.0 if (on and ph) else 0.3)
			_bar[1].material_override = Effects3D.mat(Color(0.1, 0.25, 1.0), 5.0 if (on and not ph) else 0.3)
		if _siren_light:
			_siren_light.light_energy = 2.5 if on else 0.0
			_siren_light.light_color = Color(1.0, 0.15, 0.15) if ph else Color(0.2, 0.35, 1.0)


# ----------------------------------------------------------------------------
#  NOUSU JA POISTUMINEN
# ----------------------------------------------------------------------------
func can_enter() -> bool:
	return not exploded and not burning and mode != Mode.PLAYER


func enter(p: Node) -> void:
	var was_traffic := mode == Mode.TRAFFIC or mode == Mode.POLICE
	if _lock != Vector2i(-1, -1):
		var city := Effects3D.city(get_tree())
		if city:
			city.unlock(_lock, self)
		_lock = Vector2i(-1, -1)
	driver = p
	mode = Mode.PLAYER
	siren_on = false
	_exit_cd = 0.4
	_wp.clear()
	if npc_owned:
		npc_owned = false
		var pol := Effects3D.police(get_tree())
		if pol:
			pol.crime(3 if police else 1, global_position)
		Effects3D.msg(get_tree(), "Varastit poliisiauton!" if police else "Varastit auton!", 1.8)
	if was_traffic:
		var lv := Effects3D.level(get_tree())
		if lv and lv.has_method("spawn_fleeing_driver"):
			lv.spawn_fleeing_driver(global_position + global_transform.basis.x * 2.2, police)


func release() -> void:
	driver = null
	mode = Mode.PARKED
	set_headlights(false)


func exit_spot() -> Vector3:
	var space := get_world_3d().direct_space_state
	for off: Vector3 in [-global_transform.basis.x * 2.0, global_transform.basis.x * 2.0, global_transform.basis.z * 3.3, -global_transform.basis.z * 3.3]:
		var p := global_position + off
		var q := PhysicsShapeQueryParameters3D.new()
		var sph := SphereShape3D.new()
		sph.radius = 0.45
		q.shape = sph
		q.transform = Transform3D(Basis.IDENTITY, p + Vector3(0, 0.9, 0))
		q.collision_mask = Effects3D.L_WORLD | Effects3D.L_CARS
		q.exclude = [get_rid()]
		if space.intersect_shape(q, 1).is_empty():
			return p
	return global_position + global_transform.basis.x * 2.0


# ----------------------------------------------------------------------------
#  VAURIOT
# ----------------------------------------------------------------------------
func take_damage(amount: float, source: Node = null) -> void:
	_hurt(amount * 7.0, source != null and source.is_in_group("player"))


func blast(_at: Vector3, k: float, source: Node) -> void:
	_hurt(140.0 * k, source != null and source.is_in_group("player"))


func _hurt(amount: float, by_player: bool) -> void:
	if exploded:
		return
	if by_player:
		_by_player = true
	health -= amount
	var step := int((MAX_HEALTH - clampf(health, 0.0, MAX_HEALTH)) / 25.0)
	if step != _dmg_step and _body_mi:
		_dmg_step = step
		var base := Color(0.95, 0.95, 0.97) if police else body_color
		var c := base.darkened(0.12 * step)
		_body_mi.material_override = Effects3D.mat(c)
		_roof_mi.material_override = Effects3D.mat(c)
	if health <= 0.0 and not burning:
		burning = true
		_burn_t = BURN_TIME
		Effects3D.sound(get_tree(), "ignite", global_position, 2.0)
		_fire = CPUParticles3D.new()
		_fire.amount = 40
		_fire.lifetime = 0.6
		var sm := SphereMesh.new()
		sm.radius = 0.25
		sm.height = 0.5
		sm.radial_segments = 6
		sm.rings = 3
		_fire.mesh = sm
		_fire.material_override = Effects3D.mat(Color(1.0, 0.5, 0.1), 4.0)
		_fire.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
		_fire.emission_box_extents = Vector3(0.7, 0.2, 1.4)
		_fire.direction = Vector3.UP
		_fire.spread = 20.0
		_fire.initial_velocity_min = 1.5
		_fire.initial_velocity_max = 3.0
		_fire.gravity = Vector3(0, 2, 0)
		_fire.scale_amount_min = 0.6
		_fire.scale_amount_max = 1.4
		_fire.position = Vector3(0, 1.2, -0.8)
		add_child(_fire)
		var fl := OmniLight3D.new()
		fl.light_color = Color(1.0, 0.55, 0.2)
		fl.light_energy = 3.0
		fl.omni_range = 8.0
		fl.position = Vector3(0, 2.0, 0)
		_fire.add_child(fl)


func is_burning() -> bool:
	return burning


func _explode() -> void:
	burning = false
	exploded = true
	siren_on = false
	if _fire:
		_fire.emitting = false
	for mi in _model.find_children("*", "MeshInstance3D", true, false):
		(mi as MeshInstance3D).material_override = Effects3D.mat(Color(0.09, 0.08, 0.08))
	set_headlights(false)
	if _siren_light:
		_siren_light.light_energy = 0.0
	var src: Node = self
	if _by_player:
		src = Effects3D.player(get_tree())
	var d := driver
	if d and d.has_method("exit_car"):
		d.exit_car()
		if d.has_method("take_damage"):
			d.take_damage(999.0, self)
	mode = Mode.PARKED
	Effects3D.explosion(get_tree(), global_position, src)
	if _lock != Vector2i(-1, -1):
		var city := Effects3D.city(get_tree())
		if city:
			city.unlock(_lock, self)


# ----------------------------------------------------------------------------
#  LIIKENTEEN TEKOÄLY
# ----------------------------------------------------------------------------
func setup_traffic(spot: Dictionary) -> void:
	global_position = spot.pos
	rotation.y = float(spot.yaw)
	_route_j = spot.j
	_route_d = spot.d
	_wp.clear()
	mode = Mode.TRAFFIC
	_cruise = randf_range(8.5, 12.5)
	speed = _cruise * 0.7
	velocity = -global_transform.basis.z * speed


func _init_route_from_position(city: City3D) -> void:
	var fwd := -global_transform.basis.z
	var d := Vector2i(int(signf(fwd.x)), 0) if absf(fwd.x) > absf(fwd.z) else Vector2i(0, int(signf(fwd.z)))
	if d == Vector2i.ZERO:
		d = Vector2i(0, 1)
	var j := city.nearest_junction(global_position)
	if (city.junction_center(j) - global_position).dot(Vector3(d.x, 0, d.y)) < 0.0 and city.has_junction(j + d):
		j += d
	_route_j = j
	_route_d = d
	_wp.clear()


func _extend_route(city: City3D) -> void:
	if not city.has_junction(_route_j):
		_init_route_from_position(city)
		if not city.has_junction(_route_j):
			return
	var d := _route_d
	var r := City3D.right_of(d)
	var opts: Array[Vector2i] = []
	for o: Vector2i in [d, r, -r]:
		if city.has_junction(_route_j + o):
			opts.append(o)
	if opts.is_empty():
		opts.append(-d)
	var e: Vector2i = opts[randi() % opts.size()]
	if opts.has(d) and randf() < 0.5:
		e = d
	for w in city.route_through(_route_j, d, e):
		_wp.append(w)
	_route_j += e
	_route_d = e


## Etäisyys lähimpään esteeseen (auto, ihminen) edessä, tai -1.
func _obstacle_ahead(length: float) -> float:
	var fwd := -global_transform.basis.z
	var a := global_position + fwd * 2.3 + Vector3(0, 0.8, 0)
	var q := PhysicsRayQueryParameters3D.create(a, a + fwd * length, Effects3D.L_CARS | Effects3D.L_PEOPLE)
	q.exclude = [get_rid()]
	var hit := get_world_3d().direct_space_state.intersect_ray(q)
	if hit.is_empty():
		return -1.0
	var col = hit.collider
	if col != null and col.get("dead") == true:
		return -1.0
	if col != null and col.is_in_group("player") and _horn_cd <= 0.0 and absf(speed) < 3.0:
		_horn_cd = randf_range(2.5, 5.0)
		Effects3D.sound(get_tree(), "horn", global_position, -6.0)
	return a.distance_to(hit.position)


func _steer_to(p: Vector3) -> Array:
	var to := p - global_position
	to.y = 0.0
	var desired := atan2(-to.x, -to.z)
	var diff := wrapf(desired - rotation.y, -PI, PI)
	return [clampf(-diff * 2.5, -1.0, 1.0), diff, to.length()]


func _throttle_for(target_speed: float) -> float:
	if speed < target_speed - 0.5:
		return 1.0
	if speed > target_speed + 0.8:
		return -1.0
	return 0.0


func _ai_traffic(dt: float) -> Vector3:
	var city := Effects3D.city(get_tree())
	if city == null:
		return Vector3.ZERO
	if _wp.size() < 4:
		_extend_route(city)
	if _wp.is_empty():
		return Vector3.ZERO
	var fwd := -global_transform.basis.z
	for k in 2:
		var w0: Dictionary = _wp[0]
		var to0: Vector3 = w0.p - global_position
		to0.y = 0.0
		if to0.length() < 2.2 or (to0.length() < 5.0 and to0.dot(fwd) < 0.0):
			_wp.pop_front()
			if w0.get("exit", false):
				city.unlock(w0.j, self)
				_lock = Vector2i(-1, -1)
			if _wp.size() < 4:
				_extend_route(city)
			if _wp.is_empty():
				return Vector3.ZERO
		else:
			break
	var w: Dictionary = _wp[0]
	var st := _steer_to(w.p)
	var steer: float = st[0]
	var diff: float = st[1]
	var dist: float = st[2]
	var target := _cruise
	if w.get("entry", false) and dist < 8.0 and _lock != w.j:
		if city.try_lock(w.j, self):
			_lock = w.j
		else:
			target = clampf((dist - 2.5) * 1.5, 0.0, _cruise)
	if w.get("turn", false) and dist < 10.0:
		target = minf(target, 6.0)
	if absf(diff) > 0.6:
		target = minf(target, 5.0)
	var ahead := _obstacle_ahead(3.0 + absf(speed) * 0.9)
	if ahead >= 0.0:
		target = minf(target, maxf(0.0, (ahead - 2.0) * 1.3))
	if target < 0.5:
		_blocked_t += dt
		if _blocked_t > 9.0 and w.get("entry", false):
			city._locks[w.j] = self   # jumissa: otetaan risteys väkisin
			_lock = w.j
			_blocked_t = 0.0
	else:
		_blocked_t = 0.0
	var thr := _throttle_for(target)
	if target < 0.1 and speed < 0.3:
		thr = 0.0
	return Vector3(thr, steer, 0.0)


# ----------------------------------------------------------------------------
#  POLIISIN TEKOÄLY
# ----------------------------------------------------------------------------
func _ai_police(dt: float) -> Vector3:
	var city := Effects3D.city(get_tree())
	var pol := Effects3D.police(get_tree())
	if city == null or pol == null:
		return Vector3.ZERO
	if int(pol.stars) <= 0:
		siren_on = false
		unloaded = false
		_init_route_from_position(city)
		mode = Mode.TRAFFIC
		_cruise = 10.0
		return Vector3.ZERO
	siren_on = true
	var tgt: Vector3 = pol.target_position()
	var on_foot := not bool(pol.player_in_car())
	var pos := global_position
	var dist := pos.distance_to(tgt)
	var aim := tgt
	var direct := dist < 32.0 and Effects3D.los(self, pos + Vector3(0, 1.0, 0), tgt + Vector3(0, 1.0, 0))
	if not direct:
		var jc := city.nearest_junction(pos)
		var jt := city.nearest_junction(tgt)
		var cc := city.junction_center(jc)
		if jc == jt:
			aim = tgt if pos.distance_to(cc) < 9.0 else cc
		else:
			var dd := jt - jc
			var stp := Vector2i(signi(dd.x), 0) if absi(dd.x) >= absi(dd.y) else Vector2i(0, signi(dd.y))
			var nc := city.junction_center(jc + stp)
			aim = nc if pos.distance_to(nc) < cc.distance_to(nc) else cc
			if pos.distance_to(cc) < 7.0:
				aim = nc
	var st := _steer_to(aim)
	var steer: float = st[0]
	var diff: float = st[1]
	var target := 26.0 if dist > 40.0 else 16.0
	if absf(diff) > 0.7:
		target = minf(target, 7.0)
	if on_foot:
		if unloaded and dist > 45.0:
			unloaded = false
		if dist < 16.0 or unloaded:
			target = 0.0
			if not unloaded and absf(speed) < 1.5:
				unloaded = true
				pol.unload_officers(self)
	# Seinä edessä: väistö
	var fwd := -global_transform.basis.z
	var a := pos + Vector3(0, 0.8, 0) + fwd * 2.2
	var space := get_world_3d().direct_space_state
	var q := PhysicsRayQueryParameters3D.create(a, a + fwd * 7.0, Effects3D.L_WORLD)
	if not space.intersect_ray(q).is_empty() and target > 0.0:
		var ql := PhysicsRayQueryParameters3D.create(a, a + fwd.rotated(Vector3.UP, 0.6) * 8.0, Effects3D.L_WORLD)
		var qr := PhysicsRayQueryParameters3D.create(a, a + fwd.rotated(Vector3.UP, -0.6) * 8.0, Effects3D.L_WORLD)
		var left_free := space.intersect_ray(ql).is_empty()
		var right_free := space.intersect_ray(qr).is_empty()
		if left_free and not right_free:
			steer = -1.0
		elif right_free and not left_free:
			steer = 1.0
		target = minf(target, 8.0)
	if _reverse_t > 0.0:
		_reverse_t -= dt
		return Vector3(-1.0, -steer, 0.0)
	var thr := _throttle_for(target)
	if thr > 0.0 and absf(speed) < 1.0:
		_stuck_t += dt
		if _stuck_t > 1.2:
			_stuck_t = 0.0
			_reverse_t = 1.1
	else:
		_stuck_t = 0.0
	return Vector3(thr, steer, 0.0)
