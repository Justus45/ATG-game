class_name Humanoid3D
extends Node3D
## Palikkahahmo (low-poly): jalat, vartalo, kädet, pää, hiukset/lakki.
## Malli katsoo -Z-suuntaan, origo jalkojen kohdalla. animate() heiluttaa raajoja,
## aiming nostaa oikean käden eteen, die() kaataa hahmon selälleen.

var aiming := false
var dead := false
var _body: Node3D
var _hip_l: Node3D
var _hip_r: Node3D
var _sh_l: Node3D
var _sh_r: Node3D
var _gun: MeshInstance3D
var _phase := 0.0
var _punch_t := 0.0

const SKINS := [Color(0.96, 0.8, 0.66), Color(0.86, 0.66, 0.5), Color(0.62, 0.43, 0.3), Color(0.42, 0.28, 0.2)]
const HAIRS := [Color(0.15, 0.1, 0.06), Color(0.35, 0.22, 0.1), Color(0.8, 0.65, 0.3), Color(0.08, 0.08, 0.08), Color(0.55, 0.55, 0.55)]


func build(shirt: Color, pants: Color, skin: Color, hair: Color, cap: bool = false, cap_col: Color = Color.BLACK) -> void:
	_body = Node3D.new()
	add_child(_body)
	_hip_l = _limb(Vector3(-0.13, 0.86, 0), Vector3(0.2, 0.86, 0.24), pants)
	_hip_r = _limb(Vector3(0.13, 0.86, 0), Vector3(0.2, 0.86, 0.24), pants)
	Effects3D.box(_hip_l, Vector3(0.22, 0.1, 0.32), Vector3(0, -0.81, -0.04), Color(0.12, 0.1, 0.09))
	Effects3D.box(_hip_r, Vector3(0.22, 0.1, 0.32), Vector3(0, -0.81, -0.04), Color(0.12, 0.1, 0.09))
	Effects3D.box(_body, Vector3(0.52, 0.64, 0.3), Vector3(0, 1.18, 0), shirt)
	Effects3D.box(_body, Vector3(0.34, 0.34, 0.34), Vector3(0, 1.69, 0), skin)
	Effects3D.box(_body, Vector3(0.06, 0.06, 0.02), Vector3(-0.08, 1.71, -0.175), Color(0.05, 0.05, 0.05))
	Effects3D.box(_body, Vector3(0.06, 0.06, 0.02), Vector3(0.08, 1.71, -0.175), Color(0.05, 0.05, 0.05))
	if cap:
		Effects3D.box(_body, Vector3(0.37, 0.12, 0.37), Vector3(0, 1.9, 0), cap_col)
		Effects3D.box(_body, Vector3(0.37, 0.04, 0.16), Vector3(0, 1.85, -0.25), cap_col)
	else:
		Effects3D.box(_body, Vector3(0.36, 0.1, 0.36), Vector3(0, 1.88, 0.01), hair)
		Effects3D.box(_body, Vector3(0.36, 0.22, 0.08), Vector3(0, 1.76, 0.15), hair)
	_sh_l = _limb(Vector3(-0.34, 1.46, 0), Vector3(0.15, 0.6, 0.17), shirt)
	_sh_r = _limb(Vector3(0.34, 1.46, 0), Vector3(0.15, 0.6, 0.17), shirt)
	Effects3D.box(_sh_l, Vector3(0.13, 0.13, 0.13), Vector3(0, -0.66, 0), skin)
	Effects3D.box(_sh_r, Vector3(0.13, 0.13, 0.13), Vector3(0, -0.66, 0), skin)


func build_random(rng: RandomNumberGenerator) -> void:
	var shirt := Color.from_hsv(rng.randf(), rng.randf_range(0.3, 0.8), rng.randf_range(0.4, 0.9))
	var pants := Color.from_hsv(rng.randf_range(0.55, 0.7), rng.randf_range(0.1, 0.5), rng.randf_range(0.15, 0.45))
	build(shirt, pants, SKINS[rng.randi() % SKINS.size()], HAIRS[rng.randi() % HAIRS.size()])


func _limb(pivot: Vector3, size: Vector3, c: Color) -> Node3D:
	var p := Node3D.new()
	p.position = pivot
	_body.add_child(p)
	Effects3D.box(p, size, Vector3(0, -size.y * 0.5, 0), c)
	return p


## Ase oikeaan käteen. long = kivääri / haulikko.
func set_gun(on: bool, long: bool = false) -> void:
	if _gun:
		_gun.queue_free()
		_gun = null
	if on and _sh_r:
		_gun = Effects3D.box(_sh_r, Vector3(0.08, 0.12, 0.7 if long else 0.32), Vector3(0, -0.66, -0.2 if long else -0.1), Color(0.1, 0.1, 0.11))


func punch() -> void:
	_punch_t = 0.22


func animate(dt: float, speed: float) -> void:
	if dead or _body == null:
		return
	var k := clampf(speed / 2.5, 0.0, 1.0)
	_phase += dt * (4.0 + speed * 1.6) * (1.0 if k > 0.05 else 0.0)
	var s := sin(_phase) * 0.75 * k
	_hip_l.rotation.x = s
	_hip_r.rotation.x = -s
	_sh_l.rotation.x = -s * 0.8
	if _punch_t > 0.0:
		_punch_t -= dt
		_sh_r.rotation.x = PI * 0.5 * sin(clampf(_punch_t / 0.22, 0.0, 1.0) * PI)
	elif aiming:
		_sh_r.rotation.x = lerpf(_sh_r.rotation.x, PI * 0.5, clampf(dt * 20.0, 0.0, 1.0))
	else:
		_sh_r.rotation.x = s * 0.8
	_body.position.y = absf(sin(_phase)) * 0.05 * k


func die() -> void:
	if dead:
		return
	dead = true
	if _hip_l:
		_hip_l.rotation.x = 0.1
		_hip_r.rotation.x = -0.1
		_sh_l.rotation.x = PI * 0.8
		_sh_r.rotation.x = PI * 0.75
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(self, "rotation:x", -PI * 0.5, 0.35).set_ease(Tween.EASE_IN)
	tw.tween_property(self, "position:y", 0.16, 0.35)


func revive() -> void:
	dead = false
	rotation.x = 0.0
	position.y = 0.0
