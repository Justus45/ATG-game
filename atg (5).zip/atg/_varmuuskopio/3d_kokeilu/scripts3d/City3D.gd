class_name City3D
extends Node3D
## 3D-kaupunki. Sama rakenne kuin 2D:n city_generator.gd:ssä: ruutukaava, leveät
## avenuet joka neljäs tie, jalkakäytävät, korttelit jaettuna tontteihin (kerrostalot),
## puistot, aukiot, lammet ja parkkipaikat. Pinnat teksturoidaan samasta tilemap.png:stä
## kuin 2D-pelissä (tie, viivat, suojatiet, ruoho, katot, ikkunat, ovet).
##
## 1 ruutu = T metriä. Ruudun (x, y) keskipiste maailmassa = ((x + 0.5) * T, 0, (y + 0.5) * T).
## Pohjoinen = -Z (ruudun yläreuna), itä = +X.

const T := 2.0                 ## ruudun koko metreinä
const ROW_H := 1.6             ## yhden julkisivurivin (kerroksen) korkeus metreinä
const ATLAS_PATH := "res://assets/sprites/tilemap.png"
const TS := 16
const STRIDE := 17
const CHUNK := 32

enum K { GRASS, ROAD, SIDEWALK, BUILDING, PARK, PLAZA, WATER, PARKING }

@export var map_size := 192
@export var seed_value := 0
@export var road_width := 3
@export var avenue_width := 5
@export var avenue_every := 4
@export var block_min := 12
@export var block_max := 22
@export var sidewalk_width := 2
@export var lot_min := 4
@export var lot_max := 10
@export_range(0.0, 1.0) var park_chance := 0.15
@export_range(0.0, 1.0) var plaza_chance := 0.08
@export_range(0.0, 1.0) var parking_chance := 0.08
@export var lamp_spacing := 7

var rng := RandomNumberGenerator.new()
var map_w := 0
var map_h := 0
var road_x: Array[Vector2i] = []
var road_y: Array[Vector2i] = []
var col_road := PackedByteArray()
var row_road := PackedByteArray()
var solid := PackedByteArray()
var kind := PackedByteArray()
var tiles := PackedInt32Array()          ## atlaksen ruutu per solu (x + y * 256)

var buildings: Array[Dictionary] = []    ## {rect, rows, roof, front, door, ws, label, color}
var trees: Array[Vector3] = []
var lamps: Array[Vector3] = []
var water_rects: Array[Rect2i] = []
var parking_spots: Array[Dictionary] = []    ## {pos: Vector3, yaw: float}
var start_spots: Array[Dictionary] = []      ## aloitusparkkipaikan ruudut (pelaajan auto)
var player_start := Vector3.ZERO
var police_door := Vector3.ZERO
var hospital_door := Vector3.ZERO
var pickup_spots: Array[Vector3] = []

var _atlas: Texture2D
var _atlas_size := Vector2.ONE
var _mat: StandardMaterial3D
var _static: StaticBody3D
var _locks := {}                         ## risteys -> auto (liikenteen vuorottelu)


func _ready() -> void:
	add_to_group("city3d")


# ----------------------------------------------------------------------------
#  APUFUNKTIOT (muut skriptit käyttävät näitä)
# ----------------------------------------------------------------------------
func in_bounds(c: Vector2i) -> bool:
	return c.x >= 0 and c.y >= 0 and c.x < map_w and c.y < map_h


func idx(c: Vector2i) -> int:
	return c.y * map_w + c.x


func cell_center(c: Vector2i) -> Vector3:
	return Vector3((c.x + 0.5) * T, 0.0, (c.y + 0.5) * T)


func world_to_cell(p: Vector3) -> Vector2i:
	return Vector2i(floori(p.x / T), floori(p.z / T))


func is_road(c: Vector2i) -> bool:
	return in_bounds(c) and (col_road[c.x] == 1 or row_road[c.y] == 1)


func is_solid(c: Vector2i) -> bool:
	return not in_bounds(c) or solid[idx(c)] == 1


func ped_walkable(c: Vector2i) -> bool:
	if not in_bounds(c) or solid[idx(c)] == 1:
		return false
	var k := kind[idx(c)]
	return k != K.ROAD and k != K.WATER


func world_size() -> Vector2:
	return Vector2(map_w * T, map_h * T)


# --- Risteykset: (i, j) = road_x[i] x road_y[j] ---
func has_junction(j: Vector2i) -> bool:
	return j.x >= 0 and j.y >= 0 and j.x < road_x.size() and j.y < road_y.size()


func junction_center(j: Vector2i) -> Vector3:
	var rx := road_x[j.x]
	var ry := road_y[j.y]
	return Vector3((rx.x + rx.y) * 0.5 * T, 0.0, (ry.x + ry.y) * 0.5 * T)


func junction_rect(j: Vector2i) -> Rect2:
	var rx := road_x[j.x]
	var ry := road_y[j.y]
	return Rect2(rx.x * T, ry.x * T, (rx.y - rx.x) * T, (ry.y - ry.x) * T)


func nearest_junction(p: Vector3) -> Vector2i:
	var bi := 0
	var bd := INF
	for i in road_x.size():
		var d := absf((road_x[i].x + road_x[i].y) * 0.5 * T - p.x)
		if d < bd:
			bd = d
			bi = i
	var bj := 0
	bd = INF
	for j in road_y.size():
		var d := absf((road_y[j].x + road_y[j].y) * 0.5 * T - p.z)
		if d < bd:
			bd = d
			bj = j
	return Vector2i(bi, bj)


## Suunta Vector2i (x, z). Oikea käsi suuntaan d nähden.
static func right_of(d: Vector2i) -> Vector2i:
	return Vector2i(-d.y, d.x)


## Tien leveys (ruutuina) sillä tiellä, jota pitkin suunta d kulkee risteyksessä j.
func _road_w_along(j: Vector2i, d: Vector2i) -> int:
	if d.x == 0:
		return road_x[j.x].y - road_x[j.x].x   # pystytie
	return road_y[j.y].y - road_y[j.y].x


## Kaistan sivusiirtymä tien keskeltä (oikeanpuoleinen liikenne).
func lane_offset(j: Vector2i, d: Vector2i) -> Vector3:
	var off := _road_w_along(j, d) * T * 0.25
	var r := right_of(d)
	return Vector3(r.x, 0.0, r.y) * off


## Risteyksen puoliulottuvuus suunnassa d (risteävän tien puolileveys).
func _half_ext(j: Vector2i, d: Vector2i) -> float:
	var rect := junction_rect(j)
	return (rect.size.y if d.x == 0 else rect.size.x) * 0.5


## Kaistapisteet risteyksen läpi: tulo suunnassa d, lähtö suuntaan e.
func route_through(j: Vector2i, d: Vector2i, e: Vector2i) -> Array:
	var c := junction_center(j)
	var dv := Vector3(d.x, 0.0, d.y)
	var ev := Vector3(e.x, 0.0, e.y)
	var entry := c - dv * (_half_ext(j, d) + 0.5) + lane_offset(j, d)
	var exit := c + ev * (_half_ext(j, e) + 0.5) + lane_offset(j, e)
	var out: Array = [{"p": entry, "j": j, "entry": true}]
	if e != d:
		var corner := c + lane_offset(j, d) + lane_offset(j, e)
		out.append({"p": corner, "j": j, "entry": false, "turn": true})
	out.append({"p": exit, "j": j, "entry": false, "exit": true})
	return out


func try_lock(j: Vector2i, car: Node3D) -> bool:
	var cur = _locks.get(j, null)
	if cur == null or cur == car or not is_instance_valid(cur):
		_locks[j] = car
		return true
	var c3 := cur as Node3D
	if c3 == null or c3.global_position.distance_to(junction_center(j)) > 26.0:
		_locks[j] = car
		return true
	return false


func unlock(j: Vector2i, car: Node3D) -> void:
	if _locks.get(j, null) == car:
		_locks.erase(j)


## Satunnainen kaistapiste tieosuudelta risteysten välissä. {pos, yaw, j (seuraava risteys), d}
func random_lane_spot(near: Vector3, min_d: float, max_d: float) -> Dictionary:
	for t in 30:
		var j := Vector2i(rng.randi_range(0, road_x.size() - 1), rng.randi_range(0, road_y.size() - 1))
		var dirs: Array[Vector2i] = [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]
		var d: Vector2i = dirs[rng.randi() % 4]
		var nj := j + d
		if not has_junction(nj):
			continue
		var a: Vector3 = route_through(j, d, d).back()["p"]
		var b: Vector3 = route_through(nj, d, d)[0]["p"]
		var p := a.lerp(b, rng.randf_range(0.15, 0.85))
		var dist := p.distance_to(near)
		if dist < min_d or dist > max_d:
			continue
		return {"pos": p, "yaw": atan2(-float(d.x), -float(d.y)), "j": nj, "d": d}
	return {}


# ----------------------------------------------------------------------------
#  GENEROINTI
# ----------------------------------------------------------------------------
func generate() -> void:
	if seed_value == 0:
		rng.randomize()
	else:
		rng.seed = hash(seed_value)
	map_w = map_size
	map_h = map_size
	road_x = _road_ranges(map_w)
	road_y = _road_ranges(map_h)
	col_road.resize(map_w)
	col_road.fill(0)
	row_road.resize(map_h)
	row_road.fill(0)
	for r in road_x:
		for x in range(r.x, r.y):
			col_road[x] = 1
	for r in road_y:
		for y in range(r.x, r.y):
			row_road[y] = 1
	var n := map_w * map_h
	solid.resize(n)
	solid.fill(0)
	kind.resize(n)
	kind.fill(K.GRASS)
	tiles.resize(n)
	tiles.fill(_enc(CityGenerator.GRASS))

	# Tiet ja tiemerkinnät
	for y in map_h:
		for x in map_w:
			var c := Vector2i(x, y)
			if is_road(c):
				kind[idx(c)] = K.ROAD
				_set_tile(c, CityGenerator.ROAD)
	_paint_markings()

	# Erikoiskorttelit: aloitus (parkkipaikka), poliisiasema, sairaala
	var blocks: Array[Rect2i] = []
	for i in road_x.size() - 1:
		for j in road_y.size() - 1:
			blocks.append(Rect2i(road_x[i].y, road_y[j].y, road_x[i + 1].x - road_x[i].y, road_y[j + 1].x - road_y[j].y))
	var start_block := blocks[0] if not blocks.is_empty() else Rect2i()
	var specials := {}
	var far: Array[Rect2i] = blocks.duplicate()
	var sp := Vector2(start_block.position)
	far.sort_custom(func(a: Rect2i, b: Rect2i) -> bool: return Vector2(a.position).distance_squared_to(sp) < Vector2(b.position).distance_squared_to(sp))
	if far.size() > 3:
		specials[far[2]] = "hospital"
		specials[far[far.size() / 2]] = "police"

	for b in blocks:
		_fill_block(b, b == start_block, str(specials.get(b, "")))


func _enc(a: Vector2i) -> int:
	return a.x + a.y * 256


func _set_tile(c: Vector2i, a: Vector2i) -> void:
	if in_bounds(c):
		tiles[idx(c)] = _enc(a)


func _road_ranges(n: int) -> Array[Vector2i]:
	var out: Array[Vector2i] = []
	var pos := 0
	var i := 0
	while true:
		var w := avenue_width if i % avenue_every == 0 else road_width
		out.append(Vector2i(pos, pos + w))
		pos += w
		i += 1
		var remaining := n - pos - road_width
		if remaining < 2 * block_min + avenue_width:
			out.append(Vector2i(n - road_width, n))
			break
		var b := rng.randi_range(block_min, mini(block_max, remaining - block_min - avenue_width))
		pos += b
	return out


func _paint_markings() -> void:
	for r in road_x:
		var w := r.y - r.x
		var mid := r.x + w / 2
		for y in map_h:
			if row_road[y] == 1:
				continue
			if y % 2 == 0:
				_set_tile(Vector2i(mid, y), CityGenerator.ROAD_DASH_V)
	for r in road_y:
		var w := r.y - r.x
		var mid := r.x + w / 2
		for x in map_w:
			if col_road[x] == 1:
				continue
			if x % 2 == 0:
				_set_tile(Vector2i(x, mid), CityGenerator.ROAD_DASH_H)
	# Suojatiet risteysten reunoille
	for rx in road_x:
		for ry in road_y:
			for y: int in [ry.x - 1, ry.y]:
				if y < 0 or y >= map_h or row_road[y] == 1:
					continue
				for x in range(rx.x, rx.y):
					var t: Vector2i = CityGenerator.CROSS_V[1]
					if x == rx.x:
						t = CityGenerator.CROSS_V[0]
					elif x == rx.y - 1:
						t = CityGenerator.CROSS_V[2]
					_set_tile(Vector2i(x, y), t)
			for x: int in [rx.x - 1, rx.y]:
				if x < 0 or x >= map_w or col_road[x] == 1:
					continue
				for y in range(ry.x, ry.y):
					var t: Vector2i = CityGenerator.CROSS_H[1]
					if y == ry.x:
						t = CityGenerator.CROSS_H[0]
					elif y == ry.y - 1:
						t = CityGenerator.CROSS_H[2]
					_set_tile(Vector2i(x, y), t)


func _fill_block(block: Rect2i, is_start: bool, special: String) -> void:
	# Jalkakäytävä: uloin rivi keltaista laattaa, sisempi ruohoa (kuten 2D:ssä)
	for y in range(block.position.y, block.end.y):
		for x in range(block.position.x, block.end.x):
			var d := mini(mini(x - block.position.x, block.end.x - 1 - x), mini(y - block.position.y, block.end.y - 1 - y))
			if d < sidewalk_width:
				var c := Vector2i(x, y)
				kind[idx(c)] = K.SIDEWALK
				_set_tile(c, CityGenerator.SIDEWALK if d == 0 else CityGenerator.GRASS)
	_street_furniture(block)
	var inner := block.grow(-sidewalk_width)
	if inner.size.x < 4 or inner.size.y < 4:
		return
	if is_start:
		_make_parking(inner, true)
		return
	if special != "":
		_make_special(inner, special)
		return
	var roll := rng.randf()
	if roll < park_chance:
		_make_park(inner)
	elif roll < park_chance + plaza_chance:
		_make_plaza(inner)
	elif roll < park_chance + plaza_chance + parking_chance:
		_make_parking(inner, false)
	else:
		_make_buildings(inner)


func _street_furniture(block: Rect2i) -> void:
	var r := block
	# Lamput uloimmalle riville neljälle sivulle, ei kulmiin
	for x in range(r.position.x + 2, r.end.x - 2, lamp_spacing):
		_lamp(Vector2i(x, r.position.y), Vector3(0, 0, -0.6))
		_lamp(Vector2i(x, r.end.y - 1), Vector3(0, 0, 0.6))
	for y in range(r.position.y + 2, r.end.y - 2, lamp_spacing):
		_lamp(Vector2i(r.position.x, y), Vector3(-0.6, 0, 0))
		_lamp(Vector2i(r.end.x - 1, y), Vector3(0.6, 0, 0))
	# Katupuita sisemmälle jalkakäytävän riville
	for x in range(r.position.x + 4, r.end.x - 4, 5):
		if rng.randf() < 0.5:
			_tree(Vector2i(x, r.position.y + 1))
		if rng.randf() < 0.5:
			_tree(Vector2i(x, r.end.y - 2))


func _lamp(c: Vector2i, off: Vector3) -> void:
	if not in_bounds(c):
		return
	lamps.append(cell_center(c) + off)


func _tree(c: Vector2i) -> void:
	if not in_bounds(c) or solid[idx(c)] == 1:
		return
	solid[idx(c)] = 1
	trees.append(cell_center(c) + Vector3(rng.randf_range(-0.3, 0.3), 0, rng.randf_range(-0.3, 0.3)))


func _patch(rect: Rect2i, o: Vector2i, s: Vector2i, k: int) -> void:
	for y in range(rect.position.y, rect.end.y):
		for x in range(rect.position.x, rect.end.x):
			var dx := x - rect.position.x
			var dy := y - rect.position.y
			var sx := 0 if dx == 0 else (s.x - 1 if dx == rect.size.x - 1 else 1 + (dx - 1) % maxi(s.x - 2, 1))
			var sy := 0 if dy == 0 else (s.y - 1 if dy == rect.size.y - 1 else 1 + (dy - 1) % maxi(s.y - 2, 1))
			var c := Vector2i(x, y)
			_set_tile(c, o + Vector2i(sx, sy))
			kind[idx(c)] = k


func _make_park(inner: Rect2i) -> void:
	_patch(inner, CityGenerator.PARK.o, CityGenerator.PARK.s, K.PARK)
	if inner.size.x >= 8 and inner.size.y >= 7 and rng.randf() < 0.5:
		var pw := rng.randi_range(3, mini(6, inner.size.x - 4))
		var ph := rng.randi_range(3, mini(5, inner.size.y - 4))
		var pond := Rect2i(inner.position + Vector2i(rng.randi_range(2, inner.size.x - pw - 2), rng.randi_range(2, inner.size.y - ph - 2)), Vector2i(pw, ph))
		_patch(pond, CityGenerator.WATER.o, CityGenerator.WATER.s, K.WATER)
		for y in range(pond.position.y, pond.end.y):
			for x in range(pond.position.x, pond.end.x):
				solid[idx(Vector2i(x, y))] = 1
		water_rects.append(pond)
	for i in int(inner.size.x * inner.size.y / 9.0):
		var c := inner.position + Vector2i(rng.randi_range(1, inner.size.x - 2), rng.randi_range(1, inner.size.y - 2))
		if kind[idx(c)] == K.PARK:
			_tree(c)
	pickup_spots.append(cell_center(inner.get_center()))


func _make_plaza(inner: Rect2i) -> void:
	_patch(inner, CityGenerator.PLAZA.o, CityGenerator.PLAZA.s, K.PLAZA)
	pickup_spots.append(cell_center(inner.get_center()))


func _make_parking(inner: Rect2i, is_start: bool) -> void:
	for y in range(inner.position.y, inner.end.y):
		for x in range(inner.position.x, inner.end.x):
			var c := Vector2i(x, y)
			kind[idx(c)] = K.PARKING
			_set_tile(c, CityGenerator.ROAD)
	# Rivit: 2 ruudun parkkiruudut, 2 ruudun ajokaista
	var row_y := inner.position.y
	var facing_south := true
	while row_y + 1 < inner.end.y:
		for x in range(inner.position.x, inner.end.x - 1, 2):
			var o := Vector2i(x, row_y)
			for sy in 2:
				for sx in 2:
					_set_tile(o + Vector2i(sx, sy), CityGenerator.PARKING_STALL.o + Vector2i(sx, sy))
			var spot := {"pos": Vector3((x + 1) * T, 0.0, (row_y + 1) * T), "yaw": 0.0 if facing_south else PI}
			if is_start:
				start_spots.append(spot)
			else:
				parking_spots.append(spot)
		row_y += 4
		facing_south = not facing_south
	if is_start:
		player_start = Vector3((inner.position.x + inner.size.x * 0.5) * T, 0.0, (inner.end.y + 0.5) * T)


func _split(rect: Rect2i, out: Array[Rect2i]) -> void:
	var w := rect.size.x
	var h := rect.size.y
	var can_x := w >= lot_min * 2 + 1
	var can_y := h >= lot_min * 2 + 1
	var too_big := w > lot_max or h > lot_max
	if (not can_x and not can_y) or (not too_big and rng.randf() < 0.4):
		out.append(rect)
		return
	var split_x := (w >= h) if (can_x and can_y) else can_x
	if split_x:
		var cut := rng.randi_range(lot_min, w - lot_min - 1)
		_split(Rect2i(rect.position, Vector2i(cut, h)), out)
		_split(Rect2i(rect.position + Vector2i(cut + 1, 0), Vector2i(w - cut - 1, h)), out)
	else:
		var cut := rng.randi_range(lot_min, h - lot_min - 1)
		_split(Rect2i(rect.position, Vector2i(w, cut)), out)
		_split(Rect2i(rect.position + Vector2i(0, cut + 1), Vector2i(w, h - cut - 1)), out)


func _front_of(lot: Rect2i, inner: Rect2i) -> Vector2i:
	if lot.end.y == inner.end.y:
		return Vector2i(0, 1)
	if lot.position.y == inner.position.y:
		return Vector2i(0, -1)
	if lot.end.x == inner.end.x:
		return Vector2i(1, 0)
	if lot.position.x == inner.position.x:
		return Vector2i(-1, 0)
	return Vector2i(0, 1)


func _add_building(lot: Rect2i, rows: int, front: Vector2i, label: String = "", roof := -1) -> Dictionary:
	for y in range(lot.position.y, lot.end.y):
		for x in range(lot.position.x, lot.end.x):
			var c := Vector2i(x, y)
			solid[idx(c)] = 1
			kind[idx(c)] = K.BUILDING
	var side_len := lot.size.x if front.x == 0 else lot.size.y
	var b := {
		"rect": lot, "rows": rows, "front": front,
		"roof": roof if roof >= 0 else rng.randi() % CityGenerator.ROOFS.size(),
		"door": rng.randi_range(1, maxi(side_len - 2, 1)) if label == "" else side_len / 2,
		"ws": rng.randi() % CityGenerator.WINDOW_SETS.size(),
		"label": label,
	}
	buildings.append(b)
	return b


func _make_buildings(inner: Rect2i) -> void:
	var lots: Array[Rect2i] = []
	_split(inner, lots)
	for lot in lots:
		var rows := rng.randi_range(3, 7)
		if rng.randf() < 0.15:
			rows += rng.randi_range(3, 6)   # välillä korkea kerrostalo
		_add_building(lot, rows, _front_of(lot, inner))


func _make_special(inner: Rect2i, what: String) -> void:
	var w := mini(inner.size.x, 12)
	var h := mini(inner.size.y, 9)
	var lot := Rect2i(inner.position.x + (inner.size.x - w) / 2, inner.end.y - h, w, h)
	var label := "SAIRAALA" if what == "hospital" else "POLIISI"
	var b := _add_building(lot, 4, Vector2i(0, 1), label, 1 if what == "hospital" else 0)
	var door := Vector3((lot.position.x + int(b.door) + 0.5) * T, 0.0, (lot.end.y + 0.8) * T)
	if what == "hospital":
		hospital_door = door
	else:
		police_door = door
	# Loppu kortteli aukioksi
	for y in range(inner.position.y, inner.end.y):
		for x in range(inner.position.x, inner.end.x):
			var c := Vector2i(x, y)
			if kind[idx(c)] == K.GRASS:
				_set_tile(c, CityGenerator.PLAZA.o + Vector2i(1, 1))
				kind[idx(c)] = K.PLAZA


# ----------------------------------------------------------------------------
#  3D-RAKENNUS
# ----------------------------------------------------------------------------
func build() -> void:
	_atlas = load(ATLAS_PATH) as Texture2D
	_atlas_size = _atlas.get_size() if _atlas else Vector2.ONE
	_mat = StandardMaterial3D.new()
	_mat.albedo_texture = _atlas
	_mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	_mat.roughness = 1.0
	_mat.cull_mode = BaseMaterial3D.CULL_DISABLED

	_static = StaticBody3D.new()
	_static.name = "Static"
	_static.collision_layer = 1
	_static.collision_mask = 0
	add_child(_static)

	_build_ground()
	_build_buildings()
	_build_trees()
	_build_lamps()
	_build_bounds()


func _uv(a: Vector2i) -> Rect2:
	var p := Vector2(a.x * STRIDE + 0.05, a.y * STRIDE + 0.05) / _atlas_size
	var s := Vector2(TS - 0.1, TS - 0.1) / _atlas_size
	return Rect2(p, s)


## Neliö: kulmat ulkoa katsottuna vasen-ylä, oikea-ylä, oikea-ala, vasen-ala.
func _quad(st: SurfaceTool, tl: Vector3, tr: Vector3, br: Vector3, bl: Vector3, n: Vector3, uv: Rect2) -> void:
	var u0 := uv.position
	var u1 := uv.end
	var vs := [tl, tr, br, tl, br, bl]
	var us := [u0, Vector2(u1.x, u0.y), u1, u0, u1, Vector2(u0.x, u1.y)]
	for i in 6:
		st.set_normal(n)
		st.set_uv(us[i])
		st.add_vertex(vs[i])


func _build_ground() -> void:
	for cy in range(0, map_h, CHUNK):
		for cx in range(0, map_w, CHUNK):
			var st := SurfaceTool.new()
			st.begin(Mesh.PRIMITIVE_TRIANGLES)
			for y in range(cy, mini(cy + CHUNK, map_h)):
				for x in range(cx, mini(cx + CHUNK, map_w)):
					var c := Vector2i(x, y)
					var e := tiles[idx(c)]
					var a := Vector2i(e % 256, e / 256)
					var h := -0.12 if kind[idx(c)] == K.WATER else 0.0
					var x0 := x * T
					var z0 := y * T
					_quad(st, Vector3(x0, h, z0), Vector3(x0 + T, h, z0), Vector3(x0 + T, h, z0 + T), Vector3(x0, h, z0 + T), Vector3.UP, _uv(a))
			var mi := MeshInstance3D.new()
			mi.mesh = st.commit()
			mi.material_override = _mat
			mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			add_child(mi)
	# Lampien vesi: sininen, hieman läpinäkyvä pinta
	var wm := StandardMaterial3D.new()
	wm.albedo_color = Color(0.25, 0.5, 0.75, 0.55)
	wm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	wm.roughness = 0.1
	wm.metallic_specular = 0.9
	for r in water_rects:
		var pm := PlaneMesh.new()
		pm.size = Vector2(r.size) * T - Vector2(0.4, 0.4)
		var mi := MeshInstance3D.new()
		mi.mesh = pm
		mi.material_override = wm
		mi.position = Vector3((r.position.x + r.size.x * 0.5) * T, -0.05, (r.position.y + r.size.y * 0.5) * T)
		add_child(mi)
		var cs := CollisionShape3D.new()
		var bs := BoxShape3D.new()
		bs.size = Vector3(r.size.x * T, 2.0, r.size.y * T)
		cs.shape = bs
		cs.position = mi.position + Vector3(0, 1.0, 0)
		_static.add_child(cs)


func _facade_tile(b: Dictionary, side: Vector2i, col: int, len: int, row: int) -> Vector2i:
	var ws: Array = CityGenerator.WINDOW_SETS[int(b.ws)]
	var is_front: bool = side == b.front
	if row == 0:
		if is_front and col == int(b.door):
			return CityGenerator.DOORS[int(b.rect.position.x + b.rect.position.y) % CityGenerator.DOORS.size()]
		if col > 0 and col < len - 1 and col % 2 == 1:
			return ws[1]
		return CityGenerator.WALL
	if col > 0 and col < len - 1 and col % 2 == 1:
		return ws[0]
	return CityGenerator.WALL


func _build_buildings() -> void:
	var chunks := {}
	for b in buildings:
		var r: Rect2i = b.rect
		var key := Vector2i(r.position.x / CHUNK, r.position.y / CHUNK)
		if not chunks.has(key):
			var st := SurfaceTool.new()
			st.begin(Mesh.PRIMITIVE_TRIANGLES)
			chunks[key] = st
		_building_mesh(chunks[key], b)
		# Törmäys
		var h := int(b.rows) * ROW_H
		var cs := CollisionShape3D.new()
		var bs := BoxShape3D.new()
		bs.size = Vector3(r.size.x * T, h, r.size.y * T)
		cs.shape = bs
		cs.position = Vector3((r.position.x + r.size.x * 0.5) * T, h * 0.5, (r.position.y + r.size.y * 0.5) * T)
		_static.add_child(cs)
		if str(b.label) != "":
			_sign(b)
	for key in chunks:
		var mi := MeshInstance3D.new()
		mi.mesh = (chunks[key] as SurfaceTool).commit()
		mi.material_override = _mat
		add_child(mi)


func _building_mesh(st: SurfaceTool, b: Dictionary) -> void:
	var r: Rect2i = b.rect
	var rows := int(b.rows)
	var x0 := r.position.x * T
	var x1 := r.end.x * T
	var z0 := r.position.y * T
	var z1 := r.end.y * T
	var top := rows * ROW_H
	for row in rows:
		var ya := row * ROW_H
		var yb := ya + ROW_H
		# Etelä (+Z) ja pohjoinen (-Z)
		for i in r.size.x:
			var xa := x0 + i * T
			var xb := xa + T
			_quad(st, Vector3(xa, yb, z1), Vector3(xb, yb, z1), Vector3(xb, ya, z1), Vector3(xa, ya, z1), Vector3(0, 0, 1),
				_uv(_facade_tile(b, Vector2i(0, 1), i, r.size.x, row)))
			var ni := r.size.x - 1 - i
			_quad(st, Vector3(xb, yb, z0), Vector3(xa, yb, z0), Vector3(xa, ya, z0), Vector3(xb, ya, z0), Vector3(0, 0, -1),
				_uv(_facade_tile(b, Vector2i(0, -1), ni, r.size.x, row)))
		# Itä (+X) ja länsi (-X)
		for i in r.size.y:
			var za := z0 + i * T
			var zb := za + T
			var ei := r.size.y - 1 - i
			_quad(st, Vector3(x1, yb, zb), Vector3(x1, yb, za), Vector3(x1, ya, za), Vector3(x1, ya, zb), Vector3(1, 0, 0),
				_uv(_facade_tile(b, Vector2i(1, 0), ei, r.size.y, row)))
			_quad(st, Vector3(x0, yb, za), Vector3(x0, yb, zb), Vector3(x0, ya, zb), Vector3(x0, ya, za), Vector3(-1, 0, 0),
				_uv(_facade_tile(b, Vector2i(-1, 0), i, r.size.y, row)))
	# Katto: 2D:n kattopala 9-slicena
	var roof: Dictionary = CityGenerator.ROOFS[int(b.roof)]
	var o: Vector2i = roof.o
	var s: Vector2i = roof.s
	var mx: Array = roof.mx
	var my := int(roof.my)
	for dy in r.size.y:
		for dx in r.size.x:
			var sx := 0 if dx == 0 else (s.x - 1 if dx == r.size.x - 1 else int(mx[(dx - 1) % mx.size()]))
			var sy := 0 if dy == 0 else (s.y - 1 if dy == r.size.y - 1 else my)
			var xa := x0 + dx * T
			var za := z0 + dy * T
			_quad(st, Vector3(xa, top, za), Vector3(xa + T, top, za), Vector3(xa + T, top, za + T), Vector3(xa, top, za + T),
				Vector3.UP, _uv(o + Vector2i(sx, sy)))
	# Kattolaitteita (ilmastointi)
	if r.size.x >= 4 and r.size.y >= 4 and rng.randf() < 0.65:
		for k in rng.randi_range(1, 3):
			var cx := x0 + rng.randf_range(1.5, r.size.x * T - 1.5)
			var cz := z0 + rng.randf_range(1.5, r.size.y * T - 1.5)
			var uv := _uv(CityGenerator.ROOF_PROPS[rng.randi() % CityGenerator.ROOF_PROPS.size()])
			_box(st, Vector3(cx, top, cz), Vector3(1.3, 0.9, 1.3), uv)


func _box(st: SurfaceTool, base: Vector3, size: Vector3, uv: Rect2) -> void:
	var h := size * 0.5
	var a := base.x - h.x
	var b := base.x + h.x
	var c := base.z - h.z
	var d := base.z + h.z
	var y0 := base.y
	var y1 := base.y + size.y
	_quad(st, Vector3(a, y1, c), Vector3(b, y1, c), Vector3(b, y1, d), Vector3(a, y1, d), Vector3.UP, uv)
	_quad(st, Vector3(a, y1, d), Vector3(b, y1, d), Vector3(b, y0, d), Vector3(a, y0, d), Vector3(0, 0, 1), uv)
	_quad(st, Vector3(b, y1, c), Vector3(a, y1, c), Vector3(a, y0, c), Vector3(b, y0, c), Vector3(0, 0, -1), uv)
	_quad(st, Vector3(b, y1, d), Vector3(b, y1, c), Vector3(b, y0, c), Vector3(b, y0, d), Vector3(1, 0, 0), uv)
	_quad(st, Vector3(a, y1, c), Vector3(a, y1, d), Vector3(a, y0, d), Vector3(a, y0, c), Vector3(-1, 0, 0), uv)


func _sign(b: Dictionary) -> void:
	var r: Rect2i = b.rect
	var l := Label3D.new()
	l.text = str(b.label)
	l.font_size = 96
	l.pixel_size = 0.02
	l.outline_size = 18
	l.modulate = Color(1, 1, 1) if b.label == "SAIRAALA" else Color(0.75, 0.85, 1.0)
	l.outline_modulate = Color(0.75, 0.1, 0.1) if b.label == "SAIRAALA" else Color(0.1, 0.2, 0.7)
	l.position = Vector3((r.position.x + r.size.x * 0.5) * T, ROW_H * 2.6, r.end.y * T + 0.08)
	add_child(l)
	var top := Label3D.new()
	top.text = "+" if b.label == "SAIRAALA" else "P"
	top.font_size = 256
	top.pixel_size = 0.03
	top.outline_size = 24
	top.modulate = l.outline_modulate
	top.outline_modulate = Color.WHITE
	top.rotation_degrees = Vector3(-90, 0, 0)
	top.position = Vector3((r.position.x + r.size.x * 0.5) * T, int(b.rows) * ROW_H + 0.05, (r.position.y + r.size.y * 0.5) * T)
	add_child(top)


func _build_trees() -> void:
	if trees.is_empty():
		return
	var trunk := CylinderMesh.new()
	trunk.top_radius = 0.14
	trunk.bottom_radius = 0.2
	trunk.height = 1.8
	trunk.radial_segments = 6
	var tm := StandardMaterial3D.new()
	tm.albedo_color = Color(0.42, 0.28, 0.16)
	trunk.material = tm
	var crown := SphereMesh.new()
	crown.radius = 1.25
	crown.height = 2.3
	crown.radial_segments = 8
	crown.rings = 4
	var cm := StandardMaterial3D.new()
	cm.vertex_color_use_as_albedo = true
	cm.roughness = 0.9
	crown.material = cm

	var mm_t := MultiMesh.new()
	mm_t.transform_format = MultiMesh.TRANSFORM_3D
	mm_t.mesh = trunk
	mm_t.instance_count = trees.size()
	var mm_c := MultiMesh.new()
	mm_c.transform_format = MultiMesh.TRANSFORM_3D
	mm_c.use_colors = true
	mm_c.mesh = crown
	mm_c.instance_count = trees.size()
	for i in trees.size():
		var p := trees[i]
		var s := rng.randf_range(0.85, 1.25)
		mm_t.set_instance_transform(i, Transform3D(Basis.IDENTITY.scaled(Vector3(s, s, s)), p + Vector3(0, 0.9 * s, 0)))
		var b := Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3(s, s * rng.randf_range(0.9, 1.2), s))
		mm_c.set_instance_transform(i, Transform3D(b, p + Vector3(0, 2.6 * s, 0)))
		mm_c.set_instance_color(i, Color(0.2, 0.5, 0.22).lerp(Color(0.35, 0.6, 0.2), rng.randf()))
		var cs := CollisionShape3D.new()
		var cyl := CylinderShape3D.new()
		cyl.radius = 0.3
		cyl.height = 2.0
		cs.shape = cyl
		cs.position = p + Vector3(0, 1.0, 0)
		_static.add_child(cs)
	var a := MultiMeshInstance3D.new()
	a.multimesh = mm_t
	add_child(a)
	var c := MultiMeshInstance3D.new()
	c.multimesh = mm_c
	add_child(c)


func _build_lamps() -> void:
	if lamps.is_empty():
		return
	var pole := CylinderMesh.new()
	pole.top_radius = 0.06
	pole.bottom_radius = 0.09
	pole.height = 4.8
	pole.radial_segments = 6
	var pm := StandardMaterial3D.new()
	pm.albedo_color = Color(0.22, 0.24, 0.27)
	pm.metallic = 0.5
	pole.material = pm
	var head := BoxMesh.new()
	head.size = Vector3(0.45, 0.18, 0.45)
	var hm := StandardMaterial3D.new()
	hm.albedo_color = Color(1.0, 0.92, 0.7)
	hm.emission_enabled = true
	hm.emission = Color(1.0, 0.85, 0.55)
	hm.emission_energy_multiplier = 2.0
	head.material = hm
	var mp := MultiMesh.new()
	mp.transform_format = MultiMesh.TRANSFORM_3D
	mp.mesh = pole
	mp.instance_count = lamps.size()
	var mh := MultiMesh.new()
	mh.transform_format = MultiMesh.TRANSFORM_3D
	mh.mesh = head
	mh.instance_count = lamps.size()
	for i in lamps.size():
		mp.set_instance_transform(i, Transform3D(Basis.IDENTITY, lamps[i] + Vector3(0, 2.4, 0)))
		mh.set_instance_transform(i, Transform3D(Basis.IDENTITY, lamps[i] + Vector3(0, 4.85, 0)))
		var cs := CollisionShape3D.new()
		var cyl := CylinderShape3D.new()
		cyl.radius = 0.15
		cyl.height = 3.0
		cs.shape = cyl
		cs.position = lamps[i] + Vector3(0, 1.5, 0)
		_static.add_child(cs)
	var a := MultiMeshInstance3D.new()
	a.multimesh = mp
	add_child(a)
	var b := MultiMeshInstance3D.new()
	b.multimesh = mh
	b.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(b)


func _build_bounds() -> void:
	var ws := world_size()
	var t := 20.0
	for r: Rect2 in [Rect2(-t, -t, ws.x + 2 * t, t), Rect2(-t, ws.y, ws.x + 2 * t, t), Rect2(-t, 0, t, ws.y), Rect2(ws.x, 0, t, ws.y)]:
		var cs := CollisionShape3D.new()
		var bs := BoxShape3D.new()
		bs.size = Vector3(r.size.x, 10.0, r.size.y)
		cs.shape = bs
		cs.position = Vector3(r.get_center().x, 5.0, r.get_center().y)
		_static.add_child(cs)
	# Maa kartan ulkopuolella (ettei näy tyhjää)
	var pm := PlaneMesh.new()
	pm.size = ws + Vector2(400, 400)
	var mi := MeshInstance3D.new()
	mi.mesh = pm
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.22, 0.34, 0.2)
	mi.material_override = m
	mi.position = Vector3(ws.x * 0.5, -0.02, ws.y * 0.5)
	add_child(mi)
