extends Node3D
## ATG 3D: pääkohtaus. Rakentaa kaupungin, valaistuksen, pelaajan, autot, liikenteen,
## jalankulkijat, poliisin, dronekameran ja HUD:n. Kello ja sää tulevat Game-autoloadista.

const HUD_SCENE := preload("res://scenes/ui/hud.tscn")
const SKY_KEYS := [
	[0.0, Color(0.13, 0.15, 0.3)], [270.0, Color(0.13, 0.15, 0.3)], [330.0, Color(0.36, 0.3, 0.48)],
	[390.0, Color(0.95, 0.74, 0.64)], [480.0, Color(1.0, 1.0, 1.0)], [1020.0, Color(1.0, 1.0, 1.0)],
	[1110.0, Color(1.0, 0.82, 0.6)], [1185.0, Color(0.66, 0.45, 0.58)], [1260.0, Color(0.27, 0.27, 0.45)],
	[1350.0, Color(0.13, 0.15, 0.3)], [1440.0, Color(0.13, 0.15, 0.3)],
]
const PED_TARGET := 45
const CAR_TARGET := 22
const PARKED_FILL := 0.6
const LAMP_LIGHTS := 14

var city: City3D
var player: Player3D
var police: Police3D
var camera: DroneCamera3D
var hud: Node
var sun: DirectionalLight3D
var env: Environment
var _lamp_lights: Array[OmniLight3D] = []
var _rain: CPUParticles3D
var _pop_t := 0.0
var _light_t := 0.0
var _night := 0.0
var _respawn_t := -1.0


func _ready() -> void:
	add_to_group("level3d")
	_setup_input()

	# --- Valaistus ja ympäristö ---
	var we := WorldEnvironment.new()
	env = Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.5, 0.65, 0.85)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.75, 0.8, 0.9)
	env.ambient_light_energy = 0.55
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.glow_enabled = true
	env.glow_intensity = 0.6
	env.glow_hdr_threshold = 1.2
	env.ssao_enabled = true
	env.ssao_radius = 1.2
	env.ssao_intensity = 1.4
	env.fog_enabled = false
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 90.0
	sun.light_energy = 1.1
	sun.rotation_degrees = Vector3(-55, -35, 0)
	add_child(sun)

	# --- Kaupunki ---
	city = City3D.new()
	city.name = "City3D"
	add_child(city)
	city.generate()
	city.build()

	# --- HUD (sama kuin 2D-pelissä) ja minikartta ---
	hud = HUD_SCENE.instantiate()
	hud.name = "Hud"
	add_child(hud)
	var mm := Minimap3D.new()
	hud.add_child(mm)

	# --- Pelaaja ja oma auto ---
	player = Player3D.new()
	player.name = "Player"
	add_child(player)
	player.global_position = city.player_start
	player.add_money(0)
	if not city.start_spots.is_empty():
		var s: Dictionary = city.start_spots[mini(1, city.start_spots.size() - 1)]
		var car := spawn_car({"pos": s.pos, "yaw": s.yaw}, false, Color(0.85, 0.2, 0.15))
		car.npc_owned = false
	# Aloituspistooli maassa pelaajan vieressä (kuten 2D:ssä)
	var pistol := spawn_weapon_pickup("pistol", city.player_start + Vector3(2.5, 0, 0.5))
	pistol.name = "Pistol"
	var extra := ["rifle", "shotgun", "knife", "bottle", "cue", "pistol"]
	var spots := city.pickup_spots.duplicate()
	spots.shuffle()
	for i in mini(spots.size(), extra.size() + 4):
		spawn_weapon_pickup(extra[i % extra.size()], spots[i])

	# Pysäköidyt autot
	for spot: Dictionary in city.parking_spots:
		if randf() < PARKED_FILL:
			spawn_car({"pos": spot.pos, "yaw": float(spot.yaw) + randf_range(-0.05, 0.05)}, false)

	police = Police3D.new()
	police.name = "Police3D"
	add_child(police)

	camera = DroneCamera3D.new()
	add_child(camera)
	camera.make_current()

	for i in LAMP_LIGHTS:
		var l := OmniLight3D.new()
		l.light_color = Color(1.0, 0.8, 0.5)
		l.omni_range = 11.0
		l.light_energy = 0.0
		l.shadow_enabled = false
		add_child(l)
		_lamp_lights.append(l)

	_rain = CPUParticles3D.new()
	_rain.amount = 1400
	_rain.lifetime = 0.9
	var rm := BoxMesh.new()
	rm.size = Vector3(0.02, 0.5, 0.02)
	_rain.mesh = rm
	_rain.material_override = Effects3D.mat(Color(0.7, 0.8, 1.0, 0.5))
	_rain.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	_rain.emission_box_extents = Vector3(40, 1, 40)
	_rain.direction = Vector3(0.1, -1, 0)
	_rain.spread = 3.0
	_rain.gravity = Vector3(0, -30, 0)
	_rain.initial_velocity_min = 18.0
	_rain.initial_velocity_max = 22.0
	_rain.emitting = false
	add_child(_rain)

	# Täytetään kaupunki heti alussa
	for i in 3:
		_populate(true)

	# Tallennuksen lataus (F9): Game ei liity 3D-kenttään itse, joten sovelletaan tässä
	if not Game._pending_load.is_empty():
		Game._apply_save(Game._pending_load)
		Game._pending_load = {}
		Game.msg("Tallennus ladattu: päivä %d." % Game.day, 3.0)
	else:
		Game.msg("ATG 3D  ·  WASD liiku, hiiri tähtää, E autoon, Shift juokse, rulla zoomaa, F4 kamerakulma", 6.0)


func _setup_input() -> void:
	_add_key("ui_up", KEY_W)
	_add_key("ui_left", KEY_A)
	_add_key("ui_down", KEY_S)
	_add_key("ui_right", KEY_D)
	_add_key("sprint", KEY_SHIFT)
	_add_key("handbrake", KEY_SPACE)
	_add_key("next_weapon", KEY_Q)
	_add_key("interact", KEY_E)
	_add_key("rob", KEY_R)
	_add_key("drop_weapon", KEY_G)
	if not InputMap.has_action("shoot"):
		InputMap.add_action("shoot")
		var mb := InputEventMouseButton.new()
		mb.button_index = MOUSE_BUTTON_LEFT
		InputMap.action_add_event("shoot", mb)


func _add_key(action: String, key: Key) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	for ev in InputMap.action_get_events(action):
		if ev is InputEventKey and (ev as InputEventKey).physical_keycode == key:
			return
	var k := InputEventKey.new()
	k.physical_keycode = key
	InputMap.action_add_event(action, k)


# ----------------------------------------------------------------------------
#  APUFUNKTIOT MUILLE SKRIPTEILLE
# ----------------------------------------------------------------------------
func focus_car() -> Car3D:
	if player and player.current_car and is_instance_valid(player.current_car):
		return player.current_car
	return null


func focus_position() -> Vector3:
	var c := focus_car()
	if c:
		return c.global_position
	return player.global_position if player else Vector3.ZERO


func shake(at: Vector3, amount: float) -> void:
	if camera == null:
		return
	var d := at.distance_to(focus_position())
	camera.shake(amount * clampf(1.0 - d / 40.0, 0.0, 1.0))


func spawn_car(spot: Dictionary, is_police: bool, color: Color = Color(0, 0, 0, 0)) -> Car3D:
	var car := Car3D.new()
	car.police = is_police
	car.body_color = color if color.a > 0.0 else Car3D.COLORS[randi() % Car3D.COLORS.size()]
	add_child(car)
	car.global_position = spot.pos
	car.rotation.y = float(spot.yaw)
	if spot.has("j"):
		car.setup_traffic(spot)
	return car


func spawn_officer(at: Vector3) -> Officer3D:
	var o := Officer3D.new()
	add_child(o)
	o.global_position = at
	return o


func spawn_weapon_pickup(id: String, at: Vector3) -> Pickup3D:
	var p := Pickup3D.new()
	p.kind = "weapon"
	p.weapon_id = id
	p.add_to_group("pickups")
	add_child(p)
	p.global_position = Vector3(at.x, 0.0, at.z)
	return p


func spawn_money_pickup(at: Vector3, amount: int) -> Pickup3D:
	var p := Pickup3D.new()
	p.kind = "money"
	p.amount = amount
	add_child(p)
	p.global_position = Vector3(at.x, 0.0, at.z)
	return p


func spawn_fleeing_driver(at: Vector3, was_police: bool) -> void:
	if was_police:
		var o := spawn_officer(at)
		o.global_position = at
		return
	var ped := Pedestrian3D.new()
	add_child(ped)
	ped.global_position = at
	ped.scare(focus_position())


func on_player_car_changed() -> void:
	for c in get_tree().get_nodes_in_group("cars"):
		var car := c as Car3D
		if car:
			car.set_headlights(car == focus_car() and _night > 0.3)


# ----------------------------------------------------------------------------
#  KUOLEMA JA PIDÄTYS
# ----------------------------------------------------------------------------
func player_died() -> void:
	Effects3D.msg(get_tree(), "KUOLIT", 3.0)
	_respawn_t = 3.5


func player_busted() -> void:
	var lost := int(player.money * 0.3)
	if player.current_car:
		player.exit_car()
	player.add_money(-lost)
	player.weapons.clear()
	player._equip("")
	Game.note_arrest(30)
	police.clear()
	var at := city.police_door if city.police_door != Vector3.ZERO else city.player_start
	player.respawn(at)
	Game.skip_minutes(120.0, 0.0)
	Effects3D.msg(get_tree(), "PIDÄTETTY!  Menetit aseet ja %d $. Vapauduit poliisiasemalta." % lost, 4.5)


func _respawn() -> void:
	var lost := int(player.money * 0.2)
	player.add_money(-lost)
	police.clear()
	var at := city.hospital_door if city.hospital_door != Vector3.ZERO else city.player_start
	player.respawn(at)
	Game.skip_minutes(180.0, 0.0)
	Effects3D.msg(get_tree(), "Heräsit sairaalasta. Hoito maksoi %d $." % lost, 4.0)


# ----------------------------------------------------------------------------
#  PÄÄSILMUKKA
# ----------------------------------------------------------------------------
func _process(dt: float) -> void:
	if not get_tree().paused:
		_advance_clock(dt)
	_update_light(dt)
	if _respawn_t > 0.0:
		_respawn_t -= dt
		if _respawn_t <= 0.0:
			_respawn()
	_pop_t -= dt
	if _pop_t <= 0.0:
		_pop_t = 0.5
		_populate(false)


func _advance_clock(dt: float) -> void:
	Game.minutes += dt * Game.GAME_MIN_PER_SEC
	if Game.minutes >= 1440.0:
		Game.minutes -= 1440.0
		Game.day += 1
		Game.day_changed.emit(Game.day)
	Game._update_weather(dt)


func _sky_color() -> Color:
	var m := Game.minutes
	for i in SKY_KEYS.size() - 1:
		var a: Array = SKY_KEYS[i]
		var b: Array = SKY_KEYS[i + 1]
		if m >= float(a[0]) and m <= float(b[0]):
			var t := (m - float(a[0])) / maxf(float(b[0]) - float(a[0]), 0.001)
			return (a[1] as Color).lerp(b[1] as Color, t)
	return Color.WHITE


func _update_light(dt: float) -> void:
	var sky := _sky_color()
	var clouds := Game.cloud_amount()
	var bright := sky.v
	_night = clampf(1.0 - (bright - 0.3) / 0.5, 0.0, 1.0)
	# Aurinko kiertää: aamulla idässä, illalla lännessä
	var day_t := clampf((Game.minutes - 300.0) / (1260.0 - 300.0), 0.0, 1.0)
	var elev := lerpf(12.0, 70.0, sin(day_t * PI))
	sun.rotation_degrees = Vector3(-elev, lerpf(-110.0, 110.0, day_t), 0.0)
	sun.light_color = sky.lerp(Color(0.6, 0.7, 1.0), _night * 0.5)
	sun.light_energy = lerpf(1.2, 0.12, _night) * (1.0 - clouds * 0.55)
	sun.shadow_opacity = 1.0 - clouds * 0.6
	env.ambient_light_color = sky.lerp(Color(0.35, 0.4, 0.7), _night * 0.6)
	env.ambient_light_energy = lerpf(0.55, 0.25, _night)
	env.background_color = Color(0.5, 0.65, 0.85).lerp(Color(0.04, 0.05, 0.12), _night).lerp(Color(0.55, 0.57, 0.6), clouds * 0.6)
	var fog := Game.fog_amount()
	env.fog_enabled = fog > 0.02 or _night > 0.5
	env.fog_light_color = env.background_color
	env.fog_density = 0.004 + fog * 0.03
	# Sade
	var rain := Game.rain_amount()
	var snow := Game.snow_amount()
	_rain.emitting = rain > 0.05 or snow > 0.05
	if _rain.emitting:
		_rain.global_position = focus_position() + Vector3(0, 18, -4)
		if snow > rain:
			_rain.gravity = Vector3(0, -3, 0)
			_rain.initial_velocity_min = 2.0
			_rain.initial_velocity_max = 3.0
			_rain.lifetime = 5.0
			_rain.material_override = Effects3D.mat(Color(1, 1, 1, 0.85))
		else:
			_rain.gravity = Vector3(0, -30, 0)
			_rain.initial_velocity_min = 18.0
			_rain.initial_velocity_max = 22.0
			_rain.lifetime = 0.9
			_rain.material_override = Effects3D.mat(Color(0.7, 0.8, 1.0, 0.5))
	Sfx.set_rain(rain)
	# Katuvalot: lähimmät lamput syttyvät yöllä
	_light_t -= dt
	if _light_t <= 0.0:
		_light_t = 0.4
		var fp := focus_position()
		var lit := _night > 0.25
		var near: Array = []
		if lit:
			for p: Vector3 in city.lamps:
				if absf(p.x - fp.x) < 45.0 and absf(p.z - fp.z) < 45.0:
					near.append(p)
			near.sort_custom(func(a: Vector3, b: Vector3) -> bool: return a.distance_squared_to(fp) < b.distance_squared_to(fp))
		for i in _lamp_lights.size():
			var l := _lamp_lights[i]
			if i < near.size():
				l.global_position = (near[i] as Vector3) + Vector3(0, 4.6, 0)
				l.light_energy = 2.2 * _night
				l.visible = true
			else:
				l.visible = false
		on_player_car_changed()


# ----------------------------------------------------------------------------
#  VÄESTÖ: jalankulkijat ja liikenne pelaajan ympärillä
# ----------------------------------------------------------------------------
func _populate(initial: bool) -> void:
	if city == null or player == null:
		return
	var fp := focus_position()
	var peds := get_tree().get_nodes_in_group("pedestrians")
	var alive := 0
	for p in peds:
		var n3 := p as Node3D
		var d := n3.global_position.distance_to(fp)
		var is_dead := bool(p.get("dead"))
		if d > 85.0 or (is_dead and float(p.get("_dead_t")) > 40.0 and d > 30.0):
			p.queue_free()
		elif not is_dead:
			alive += 1
	var tries := 40 if initial else 6
	var min_d := 8.0 if initial else 38.0
	while alive < PED_TARGET and tries > 0:
		tries -= 1
		var c := city.world_to_cell(fp) + Vector2i(randi_range(-34, 34), randi_range(-34, 34))
		if not city.ped_walkable(c):
			continue
		var d := city.cell_center(c).distance_to(fp)
		if d < min_d or d > 70.0:
			continue
		var ped := Pedestrian3D.new()
		add_child(ped)
		ped.place(c)
		alive += 1

	var traffic := 0
	for c in get_tree().get_nodes_in_group("cars"):
		var car := c as Car3D
		if car == null or car.police or car.mode == Car3D.Mode.PLAYER:
			continue
		var d := car.global_position.distance_to(fp)
		if car.mode == Car3D.Mode.TRAFFIC or (car.exploded and d > 60.0):
			if d > 115.0:
				car.queue_free()
				continue
			traffic += 1
	var n := 10 if initial else 2
	while traffic < CAR_TARGET and n > 0:
		n -= 1
		var spot := city.random_lane_spot(fp, 18.0 if initial else 55.0, 100.0)
		if spot.is_empty():
			continue
		if _car_near(spot.pos, 7.0):
			continue
		spawn_car(spot, false)
		traffic += 1


func _car_near(p: Vector3, r: float) -> bool:
	for c in get_tree().get_nodes_in_group("cars"):
		if (c as Node3D).global_position.distance_to(p) < r:
			return true
	return false
