class_name Player3D
extends CharacterBody3D
## Pelaaja 3D:nä.
##  WASD / nuolet: liiku   Shift: juokse   Hiiri: tähtää   Vasen hiiri / välilyönti: ammu tai lyö
##  E: autoon / autosta   R: ryöstä jalankulkija   G: pudota ase   Q: vaihda asetta (1-4 suoraan)

const WALK := 4.3
const RUN := 7.2
const MAX_HP := 100.0
const REGEN_DELAY := 6.0
const REGEN_RATE := 4.0
const ENEMY_HIT := 7.0          ## yhden vihollisluodin vahinko (take_damage(1))
const ROB_RANGE := 2.2
const CAR_RANGE := 3.4

var hp := MAX_HP
var money := 0
var dead := false
var menu_locked := false
var police_locked := false
var current_car: Car3D = null
var weapons: Array[String] = []
var weapon_id := ""
## Yhteensopivuus Game.gd:n tallennuksen kanssa (2D-pelin kentät)
var drunk := 0.0
var hangover := 0.0
var held_weapon := HeldInfo.new()

var model: Humanoid3D
var _cooldown := 0.0
var _since_hurt := 99.0
var _knock := Vector3.ZERO
var _stun := 0.0
var _aim := Vector3.ZERO
var _prompt_shown := false
var _bottle_hits := 0


class HeldInfo:
	var weapon_id := ""
	var player: Node = null
	func equip(id: String) -> void:
		if player:
			player.give_weapon(id, true)


func _ready() -> void:
	add_to_group("player")
	add_to_group("people")
	add_to_group("damageable")
	held_weapon.player = self
	motion_mode = CharacterBody3D.MOTION_MODE_FLOATING
	collision_layer = Effects3D.L_PEOPLE
	collision_mask = Effects3D.L_WORLD | Effects3D.L_CARS | Effects3D.L_PEOPLE
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.32
	cap.height = 1.8
	cs.shape = cap
	cs.position.y = 0.9
	add_child(cs)
	_build_model()


func _build_model() -> void:
	if model:
		model.queue_free()
	model = Humanoid3D.new()
	add_child(model)
	model.build(Color(0.85, 0.2, 0.15), Color(0.18, 0.2, 0.3), Color(0.95, 0.78, 0.62), Color(0.2, 0.12, 0.06))
	_refresh_gun()


func has_weapon() -> bool:
	return weapon_id != ""


func in_car() -> bool:
	return current_car != null


# ----------------------------------------------------------------------------
#  PÄIVITYS
# ----------------------------------------------------------------------------
func _physics_process(dt: float) -> void:
	if current_car:
		if is_instance_valid(current_car):
			global_position = current_car.global_position
		else:
			current_car = null
			visible = true
		return
	if dead:
		return
	_cooldown -= dt
	_since_hurt += dt
	_stun -= dt
	if _since_hurt > REGEN_DELAY and hp < MAX_HP:
		hp = minf(MAX_HP, hp + REGEN_RATE * dt)
		_refresh_hp()

	var locked := menu_locked or police_locked or _stun > 0.0
	var input := Vector2.ZERO
	if not locked:
		input = Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	var spd := RUN if Input.is_action_pressed("sprint") else WALK
	var move := Vector3(input.x, 0.0, input.y) * spd
	_knock = _knock.move_toward(Vector3.ZERO, 18.0 * dt)
	velocity = move + _knock
	move_and_slide()
	global_position.y = 0.0

	_aim = _mouse_ground(1.1)
	var shooting := not locked and Input.is_action_pressed("shoot")
	var face := Vector3.ZERO
	var ranged := weapon_id != "" and not bool(WeaponDB.get_data(weapon_id).get("melee", false))
	if shooting:
		face = _aim - global_position
	elif move.length() > 0.1:
		face = move
	face.y = 0.0
	if face.length() > 0.05:
		rotation.y = lerp_angle(rotation.y, atan2(-face.x, -face.z), clampf(dt * 16.0, 0.0, 1.0))
	model.aiming = shooting and ranged
	model.animate(dt, move.length())
	if shooting and _cooldown <= 0.0:
		_attack()
	_update_prompt()


func _unhandled_input(event: InputEvent) -> void:
	if dead or menu_locked:
		return
	if current_car:
		return
	if event.is_action_pressed("interact"):
		var car := _nearest_car()
		if car:
			enter_car(car)
	elif event.is_action_pressed("rob"):
		try_rob()
	elif event.is_action_pressed("drop_weapon"):
		drop_weapon()
	elif event.is_action_pressed("next_weapon"):
		_cycle_weapon()
	elif event is InputEventKey and event.is_pressed() and not event.is_echo():
		var k := (event as InputEventKey).physical_keycode
		if k >= KEY_1 and k <= KEY_4:
			var list: Array[String] = [""]
			list.append_array(weapons)
			var i := int(k - KEY_1)
			if i < list.size():
				_equip(list[i])


func _mouse_ground(height: float) -> Vector3:
	var cam := get_viewport().get_camera_3d()
	if cam == null:
		return global_position - global_transform.basis.z * 5.0
	var mp := get_viewport().get_mouse_position()
	var o := cam.project_ray_origin(mp)
	var d := cam.project_ray_normal(mp)
	if absf(d.y) < 0.0001:
		return global_position
	return o + d * ((height - o.y) / d.y)


func _update_prompt() -> void:
	var hud := Effects3D.hud(get_tree())
	if hud == null:
		return
	var car := _nearest_car()
	if car:
		hud.show_instruction("E: nouse autoon" + ("  (varkaus!)" if car.npc_owned else ""))
		_prompt_shown = true
	elif _prompt_shown:
		hud.hide_instruction()
		_prompt_shown = false


func _nearest_car() -> Car3D:
	var best: Car3D = null
	var bd := CAR_RANGE
	for c in get_tree().get_nodes_in_group("cars"):
		var car := c as Car3D
		if car == null or not car.can_enter():
			continue
		var d := car.global_position.distance_to(global_position)
		if d < bd:
			bd = d
			best = car
	return best


# ----------------------------------------------------------------------------
#  ASEET
# ----------------------------------------------------------------------------
func give_weapon(id: String, equip: bool = true) -> void:
	if id == "" or not WeaponDB.DATA.has(id):
		return
	if not weapons.has(id):
		weapons.append(id)
	if equip:
		_equip(id)


func _equip(id: String) -> void:
	weapon_id = id
	held_weapon.weapon_id = id
	_bottle_hits = 0
	_refresh_gun()
	var hud := Effects3D.hud(get_tree())
	if hud and hud.has_method("set_weapon"):
		hud.set_weapon(id)


func _refresh_gun() -> void:
	if model == null:
		return
	var ranged := weapon_id != "" and not bool(WeaponDB.get_data(weapon_id).get("melee", false))
	model.set_gun(ranged, weapon_id == "rifle" or weapon_id == "shotgun")


func _cycle_weapon() -> void:
	var list: Array[String] = [""]
	list.append_array(weapons)
	var i := list.find(weapon_id)
	_equip(list[(i + 1) % list.size()])


func drop_weapon() -> void:
	if weapon_id == "":
		return
	var lv := Effects3D.level(get_tree())
	if lv and lv.has_method("spawn_weapon_pickup"):
		lv.spawn_weapon_pickup(weapon_id, global_position - global_transform.basis.z * 1.2)
	weapons.erase(weapon_id)
	_equip("")


func _attack() -> void:
	if weapon_id == "":
		_melee(1.0, 1.3, 0.38)
		return
	var d := WeaponDB.get_data(weapon_id)
	if bool(d.get("melee", false)):
		_melee(float(d.damage), float(d.get("reach", 24.0)) / 8.0 + 0.4, float(d.fire_interval))
		if d.has("durability"):
			_bottle_hits += 1
			if _bottle_hits >= int(d.durability):
				Effects3D.sound(get_tree(), "glass_break", global_position)
				Effects3D.msg(get_tree(), "%s hajosi!" % str(d.name), 1.8)
				weapons.erase(weapon_id)
				_equip("")
		return
	_cooldown = float(d.fire_interval)
	var fwd := -global_transform.basis.z
	var origin := global_position + Vector3(0, 1.35, 0) + fwd * 0.55
	var dir := _aim - origin
	dir.y = 0.0
	if dir.length() < 0.5:
		dir = fwd
	dir = dir.normalized()
	var rng_m := float(d.range) / 8.0 + 6.0
	var pellets := int(d.get("pellets", 1))
	var spread := float(d.spread)
	for i in pellets:
		var dd := dir.rotated(Vector3.UP, randf_range(-spread, spread))
		Effects3D.hitscan(self, origin, origin + dd * rng_m, float(d.damage), self, [get_rid()])
	Effects3D.flash(get_tree(), origin, Color(1.0, 0.8, 0.4), 3.0, 6.0, 0.06)
	Effects3D.sound(get_tree(), "gun", origin, -3.0 if pellets == 1 else 1.0, 1.25 if weapon_id == "rifle" else (0.7 if weapon_id == "shotgun" else 1.0))
	var pol := Effects3D.police(get_tree())
	if pol:
		pol.gunshot(global_position)


func _melee(damage: float, reach: float, interval: float) -> void:
	_cooldown = interval
	model.punch()
	Effects3D.sound(get_tree(), "whoosh", global_position, -6.0)
	var fwd := -global_transform.basis.z
	var center := global_position + fwd * reach * 0.6
	var hit := false
	for n in get_tree().get_nodes_in_group("damageable"):
		if n == self:
			continue
		var n3 := n as Node3D
		if n3 == null or bool(n.get("dead")):
			continue
		var to := n3.global_position - global_position
		to.y = 0.0
		var r := reach + (1.6 if n is Car3D else 0.0)
		if to.length() < r and to.normalized().dot(fwd) > 0.45:
			n.take_damage(damage if not (n is Car3D) else damage * 0.4, self)
			hit = true
	if hit:
		Effects3D.sound(get_tree(), "punch_hit", center)
		var pol := Effects3D.police(get_tree())
		if pol:
			pol.crime(1, global_position)


# ----------------------------------------------------------------------------
#  AUTOT
# ----------------------------------------------------------------------------
func enter_car(car: Car3D) -> void:
	if car == null or not car.can_enter():
		return
	current_car = car
	visible = false
	collision_layer = 0
	collision_mask = 0
	velocity = Vector3.ZERO
	model.aiming = false
	car.enter(self)
	var hud := Effects3D.hud(get_tree())
	if hud:
		hud.hide_instruction()
	_prompt_shown = false
	var lv := Effects3D.level(get_tree())
	if lv and lv.has_method("on_player_car_changed"):
		lv.on_player_car_changed()


func exit_car() -> void:
	if current_car == null:
		return
	var car := current_car
	global_position = car.exit_spot()
	rotation.y = car.rotation.y
	current_car = null
	car.release()
	visible = true
	collision_layer = Effects3D.L_PEOPLE
	collision_mask = Effects3D.L_WORLD | Effects3D.L_CARS | Effects3D.L_PEOPLE
	var lv := Effects3D.level(get_tree())
	if lv and lv.has_method("on_player_car_changed"):
		lv.on_player_car_changed()


# ----------------------------------------------------------------------------
#  RYÖSTÖ JA RAHA
# ----------------------------------------------------------------------------
func try_rob() -> void:
	var best: Node3D = null
	var bd := ROB_RANGE
	for p in get_tree().get_nodes_in_group("pedestrians"):
		var ped := p as Node3D
		if ped == null or bool(ped.get("dead")) or bool(ped.get("robbed")):
			continue
		var d := ped.global_position.distance_to(global_position)
		if d < bd:
			bd = d
			best = ped
	if best == null:
		Effects3D.msg(get_tree(), "Ketään ei ole ryöstettävänä lähellä.", 1.5)
		return
	var amount := randi_range(8, 45)
	best.call("get_robbed", self)
	add_money(amount)
	var pol := Effects3D.police(get_tree())
	if pol:
		pol.crime(1, global_position)


func add_money(amount: int) -> void:
	money = maxi(money + amount, 0)
	var hud := Effects3D.hud(get_tree())
	if hud and hud.has_method("set_money"):
		hud.set_money(money)
	if amount > 0:
		Effects3D.float_text(get_tree(), global_position + Vector3(0, 2.1, 0), "+%d $" % amount, Color(0.5, 1.0, 0.45))
		Effects3D.sound(get_tree(), "coin", global_position, -4.0)


# ----------------------------------------------------------------------------
#  VAHINKO
# ----------------------------------------------------------------------------
func take_damage(amount: float, source: Node = null) -> void:
	if dead:
		return
	if current_car and amount < 900.0:
		return   # autossa luodit osuvat autoon
	hurt(amount * ENEMY_HIT, source)


func hurt(amount: float, _source: Node = null) -> void:
	if dead:
		return
	hp -= amount
	_since_hurt = 0.0
	_refresh_hp()
	if hp <= 0.0:
		_die()


func blast(at: Vector3, k: float, source: Node) -> void:
	if current_car:
		return
	hurt(80.0 * k, source)
	var away := global_position - at
	away.y = 0.0
	_knock = away.normalized() * 12.0 * k
	_stun = 0.6


func hit_by_car(vel: Vector3, car: Node) -> bool:
	if dead or current_car:
		return false
	var s := vel.length()
	if s < 3.0:
		return false
	_knock = vel * 0.9
	_stun = 0.7
	hurt(s * 2.2, car)
	Effects3D.sound(get_tree(), "thud", global_position)
	return true


func _refresh_hp() -> void:
	var hud := Effects3D.hud(get_tree())
	if hud and hud.has_method("set_health"):
		hud.set_health(hp, MAX_HP)


func _die() -> void:
	dead = true
	hp = 0.0
	model.die()
	var lv := Effects3D.level(get_tree())
	if lv and lv.has_method("player_died"):
		lv.player_died()


func respawn(at: Vector3) -> void:
	if current_car:
		exit_car()
	dead = false
	hp = MAX_HP
	_knock = Vector3.ZERO
	_stun = 0.0
	police_locked = false
	global_position = at
	rotation = Vector3.ZERO
	_build_model()
	_refresh_hp()
