class_name Officer3D
extends CharacterBody3D
## Jalkapoliisi. 1 tähti: juoksee pelaajan luo ja pidättää (pysy liian kauan vieressä).
## 2+ tähteä: ampuu, kun näkee pelaajan. Kuollut poliisi on vakava rikos.

const RUN := 5.0
const SHOOT_RANGE := 20.0

var hp := 5.0
var dead := false
var model: Humanoid3D
var _cool := 0.0
var _side_t := 0.0
var _side := Vector3.ZERO
var _fly := Vector3.ZERO
var _dead_t := 0.0


func _ready() -> void:
	add_to_group("officers")
	add_to_group("people")
	add_to_group("damageable")
	motion_mode = CharacterBody3D.MOTION_MODE_FLOATING
	collision_layer = Effects3D.L_PEOPLE
	collision_mask = Effects3D.L_WORLD | Effects3D.L_CARS
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.32
	cap.height = 1.8
	cs.shape = cap
	cs.position.y = 0.9
	add_child(cs)
	model = Humanoid3D.new()
	add_child(model)
	model.build(Color(0.12, 0.18, 0.4), Color(0.08, 0.1, 0.2), Humanoid3D.SKINS[randi() % 4], Color.BLACK, true, Color(0.06, 0.08, 0.2))
	model.set_gun(true)
	_cool = randf_range(0.5, 1.2)


func _physics_process(dt: float) -> void:
	if dead:
		_dead_t += dt
		if _fly.length() > 0.1:
			_fly = _fly.move_toward(Vector3.ZERO, 14.0 * dt)
			global_position += _fly * dt
		return
	var pol := Effects3D.police(get_tree())
	if pol == null:
		return
	_cool -= dt
	var move := Vector3.ZERO
	var stars := int(pol.stars)
	var tgt: Vector3 = pol.target_position()
	var to := tgt - global_position
	to.y = 0.0
	var dist := to.length()
	var face := to
	model.aiming = false
	if stars <= 0:
		move = Vector3.ZERO
	else:
		var sees := dist < 30.0 and Effects3D.los(self, global_position + Vector3(0, 1.4, 0), tgt + Vector3(0, 1.2, 0))
		if stars >= 2 and sees and dist < SHOOT_RANGE:
			model.aiming = true
			if dist > 7.0:
				move = to.normalized() * RUN * 0.45
			if _cool <= 0.0:
				_shoot(tgt, dist)
		elif dist > 1.1:
			move = to.normalized() * RUN
		if stars == 1 and dist < 1.8 and not bool(pol.player_in_car()):
			pol.add_bust(dt)
		elif dist < 2.5 and bool(pol.player_in_car()) and stars <= 2:
			pol.add_bust(dt * 0.6)
	if _side_t > 0.0:
		_side_t -= dt
		move = _side * RUN
	velocity = move
	move_and_slide()
	global_position.y = 0.0
	if move.length() > 0.5 and get_real_velocity().length() < 0.3 and _side_t <= 0.0:
		_side = move.normalized().rotated(Vector3.UP, PI * 0.5 * (1.0 if randf() < 0.5 else -1.0))
		_side_t = 0.8
	if face.length() > 0.05:
		rotation.y = lerp_angle(rotation.y, atan2(-face.x, -face.z), clampf(dt * 10.0, 0.0, 1.0))
	model.animate(dt, move.length())


func _shoot(tgt: Vector3, dist: float) -> void:
	_cool = randf_range(0.7, 1.1)
	var origin := global_position + Vector3(0, 1.35, 0) + (-global_transform.basis.z) * 0.5
	var dir := tgt + Vector3(0, 1.2, 0) - origin
	dir.y = 0.0
	dir = dir.normalized().rotated(Vector3.UP, randf_range(-1.0, 1.0) * (0.05 + dist * 0.006))
	var exclude: Array = [get_rid()]
	Effects3D.hitscan(self, origin, origin + dir * (SHOOT_RANGE + 6.0), 1.0, self, exclude)
	Effects3D.flash(get_tree(), origin, Color(1.0, 0.8, 0.4), 2.5, 5.0, 0.05)
	Effects3D.sound(get_tree(), "gun", origin, -5.0, 1.1)


func take_damage(amount: float, source: Node = null) -> void:
	if dead:
		return
	if source is Officer3D:
		return   # poliisit eivät ammu toisiaan
	hp -= amount
	if hp <= 0.0:
		_die(source)


func blast(at: Vector3, k: float, source: Node) -> void:
	if dead:
		return
	var away := global_position - at
	away.y = 0.0
	_fly = away.normalized() * 10.0 * k
	_die(source)


func hit_by_car(vel: Vector3, car: Node) -> bool:
	if dead or vel.length() < 3.0:
		return false
	if car is Car3D and (car as Car3D).police:
		return false
	_fly = vel * 0.8
	var src: Node = car
	if car != null and car.get("mode") == Car3D.Mode.PLAYER:
		src = Effects3D.player(get_tree())
	_die(src)
	return true


func _die(source: Node) -> void:
	dead = true
	collision_layer = 0
	collision_mask = 0
	model.aiming = false
	model.die()
	Effects3D.blood(get_tree(), global_position + Vector3(0, 0.5, 0))
	var pol := Effects3D.police(get_tree())
	if pol and source != null and source.is_in_group("player"):
		pol.crime(4, global_position)
	if randf() < 0.5:
		var lv := Effects3D.level(get_tree())
		if lv and lv.has_method("spawn_weapon_pickup") and randf() < 0.5:
			lv.spawn_weapon_pickup("pistol", global_position)
