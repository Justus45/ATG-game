class_name Minimap3D
extends Control
## Minikartta oikeaan yläkulmaan (samaan paikkaan kuin 2D:ssä): tiet, talot, nurmi,
## pelaaja valkoisena nuolena, poliisit punasinisinä pisteinä, poimittavat keltaisina.
## M = koko kaupungin kartta.

const VIEW := 34          ## ruutua pelaajasta joka suuntaan
const SIZE_PX := 126.0
const TOP := 64.0

const COL_GRASS := Color(0.30, 0.45, 0.28)
const COL_ROAD := Color(0.62, 0.64, 0.68)
const COL_SOLID := Color(0.20, 0.22, 0.30)
const COL_WATER := Color(0.25, 0.45, 0.75)
const COL_WALK := Color(0.72, 0.68, 0.5)

var _tex: ImageTexture
var _full := false


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	set_anchors_preset(Control.PRESET_TOP_RIGHT)
	offset_left = -SIZE_PX - 20.0
	offset_right = -20.0
	offset_top = TOP
	offset_bottom = TOP + SIZE_PX


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("full_map"):
		_full = not _full


func _build(city: City3D) -> void:
	var img := Image.create(city.map_w, city.map_h, false, Image.FORMAT_RGBA8)
	for y in city.map_h:
		for x in city.map_w:
			var i := y * city.map_w + x
			var k := city.kind[i]
			var c := COL_GRASS
			if k == City3D.K.ROAD or k == City3D.K.PARKING:
				c = COL_ROAD
			elif k == City3D.K.BUILDING:
				c = COL_SOLID
			elif k == City3D.K.WATER:
				c = COL_WATER
			elif k == City3D.K.PLAZA:
				c = COL_WALK
			img.set_pixel(x, y, c)
	_tex = ImageTexture.create_from_image(img)


func _process(_dt: float) -> void:
	if _tex == null:
		var city := Effects3D.city(get_tree())
		if city and city.map_w > 0:
			_build(city)
	queue_redraw()


func _draw() -> void:
	var city := Effects3D.city(get_tree())
	var lv := Effects3D.level(get_tree())
	if _tex == null or city == null or lv == null:
		return
	var focus: Vector3 = lv.focus_position()
	var fc := Vector2(focus.x / City3D.T, focus.z / City3D.T)
	var rect: Rect2
	var src: Rect2
	if _full:
		var vs := get_viewport_rect().size
		var side := floorf(minf(vs.x, vs.y) * 0.86)
		var gp := get_global_rect().position
		rect = Rect2((vs - Vector2(side, side)) * 0.5 - gp, Vector2(side, side))
		src = Rect2(0, 0, city.map_w, city.map_h)
	else:
		rect = Rect2(Vector2.ZERO, Vector2(SIZE_PX, SIZE_PX))
		var o := (fc - Vector2(VIEW, VIEW)).clamp(Vector2.ZERO, Vector2(city.map_w - VIEW * 2, city.map_h - VIEW * 2))
		src = Rect2(o, Vector2(VIEW * 2, VIEW * 2))
	draw_rect(rect.grow(3.0), Color(0, 0, 0, 0.7))
	draw_texture_rect_region(_tex, rect, src)
	var k := rect.size.x / src.size.x
	var to_map := func(p: Vector3) -> Vector2:
		return rect.position + (Vector2(p.x / City3D.T, p.z / City3D.T) - src.position) * k
	for o in get_tree().get_nodes_in_group("officers"):
		if not bool(o.get("dead")):
			_dot(to_map.call((o as Node3D).global_position), rect, Color(0.3, 0.5, 1.0), 2.0)
	for c in get_tree().get_nodes_in_group("cars"):
		var car := c as Car3D
		if car and car.police and not car.exploded:
			_dot(to_map.call(car.global_position), rect, Color(1.0, 0.25, 0.25) if int(Time.get_ticks_msec() / 250) % 2 == 0 else Color(0.3, 0.5, 1.0), 3.0)
	for p in get_tree().get_nodes_in_group("pickups"):
		_dot(to_map.call((p as Node3D).global_position), rect, Color(1.0, 0.85, 0.2), 2.0)
	for spot: Vector3 in [city.hospital_door, city.police_door]:
		if spot != Vector3.ZERO:
			_dot(to_map.call(spot), rect, Color(1, 1, 1) if spot == city.hospital_door else Color(0.4, 0.6, 1.0), 3.5)
	# Pelaaja: nuoli katsomissuuntaan
	var pp: Vector2 = to_map.call(focus)
	var yaw := 0.0
	var car2: Car3D = lv.focus_car()
	if car2:
		yaw = car2.rotation.y
	else:
		var pl := Effects3D.player(get_tree())
		if pl:
			yaw = pl.rotation.y
	var f := Vector2(-sin(yaw), -cos(yaw))
	var r := Vector2(f.y, -f.x)
	var s := 5.0 * (1.6 if _full else 1.0)
	draw_colored_polygon(PackedVector2Array([pp + f * s, pp - f * s * 0.6 + r * s * 0.7, pp - f * s * 0.6 - r * s * 0.7]), Color.WHITE)


func _dot(p: Vector2, rect: Rect2, c: Color, r: float) -> void:
	if rect.has_point(p):
		draw_circle(p, r, c)
