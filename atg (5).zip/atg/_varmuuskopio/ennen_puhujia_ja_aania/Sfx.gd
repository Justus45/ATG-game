extends Node
## Pelin äänet. Autoload "Sfx" (project.godot -> [autoload]).
## Kaikki äänet syntetisoidaan koodissa käynnistyksen yhteydessä, joten peli ei tarvitse
## äänitiedostoja. Jos haluat myöhemmin oikeat äänet, korvaa _streams-sanakirjan arvo
## ladatulla tiedostolla, esim. _streams["punch_hit"] = load("res://assets/sfx/punch.wav").
##
## Käyttö muista skripteistä:
##   Sfx.play("punch_hit", global_position)     # paikkasidottu ääni (kuuluu hiljempaa kaukaa)
##   Sfx.play_ui("cash")                         # ääni ilman sijaintia (käyttöliittymä)
##   Sfx.set_siren(0.0 .. 1.0)                   # PoliceManager säätää joka ruudussa
##   Sfx.play_music(0, jukebox_pos) / Sfx.stop_music()

const RATE := 22050
const MUSIC_RATE := 11025          ## jukeboksi soi lo-fi-laadulla (kevyempi laskea)
const POOL_SIZE := 16
const WORLD_HEARING := 650.0       ## pikseliä: kauempaa ei kuulu mitään

## Jukeboksin kappaleet (nimi näytetään HUD:ssa)
const TUNE_NAMES := ["Humppa-Heikki", "Tango Tammisaari"]

var _streams := {}
var _pool2d: Array[AudioStreamPlayer2D] = []
var _pool: Array[AudioStreamPlayer] = []
var _next2d := 0
var _next := 0
var _siren: AudioStreamPlayer
var _siren_target := 0.0
var _siren_level := 0.0
var _rain: AudioStreamPlayer
var _rain_target := 0.0
var _rain_level := 0.0
var _music: AudioStreamPlayer2D
var _tunes: Array[AudioStreamWAV] = []
var _music_task := -1
var _wanted_tune := -1
var _wanted_tune_pos := Vector2.ZERO
var _mb := PackedFloat32Array()   # musiikin työpuskuri (vain taustasäie käyttää)


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_streams["punch_hit"] = _wav(_gen_punch_hit())
	_streams["punch_miss"] = _wav(_gen_whoosh())
	_streams["step"] = _wav(_gen_step())
	_streams["gun"] = _wav(_gen_gun())
	_streams["coin"] = _wav(_gen_coin())
	_streams["clink"] = _wav(_gen_clink())
	_streams["can"] = _wav(_gen_can())
	_streams["gulp"] = _wav(_gen_gulp())
	_streams["cash"] = _wav(_gen_cash())
	_streams["clang"] = _wav(_gen_clang())
	_streams["phone"] = _wav(_gen_phone())
	_streams["denied"] = _wav(_gen_denied())
	_streams["siren"] = _wav(_gen_siren(), RATE, true)
	_streams["block"] = _wav(_gen_block())
	_streams["taser"] = _wav(_gen_taser())
	_streams["glass_break"] = _wav(_gen_glass_break())
	_streams["rain"] = _wav(_gen_rain(), RATE, true)
	_streams["dart"] = _wav(_gen_dart())
	_streams["pool"] = _wav(_gen_pool())
	_streams["thunder"] = _wav(_gen_thunder())
	_streams["crash"] = _wav(_gen_crash())
	_streams["thud"] = _wav(_gen_thud())
	_streams["horn"] = _wav(_gen_horn())
	_streams["explosion"] = _wav(_gen_explosion())
	_streams["ignite"] = _wav(_gen_ignite())

	for i in POOL_SIZE:
		var p2 := AudioStreamPlayer2D.new()
		p2.max_distance = WORLD_HEARING
		p2.attenuation = 1.4
		add_child(p2)
		_pool2d.append(p2)
	for i in 6:
		var p := AudioStreamPlayer.new()
		add_child(p)
		_pool.append(p)

	_siren = AudioStreamPlayer.new()
	_siren.stream = _streams["siren"]
	add_child(_siren)

	_rain = AudioStreamPlayer.new()
	_rain.stream = _streams["rain"]
	add_child(_rain)

	_music = AudioStreamPlayer2D.new()
	_music.max_distance = 900.0
	_music.attenuation = 0.7
	add_child(_music)

	# Jukeboksin kappaleet lasketaan taustalla, ettei peli nyki käynnistyessä
	_music_task = WorkerThreadPool.add_task(_build_tunes)


func _process(delta: float) -> void:
	# Sireeni nousee ja laskee pehmeästi
	_siren_level = move_toward(_siren_level, _siren_target, delta * 1.5)
	if _siren_level > 0.01:
		if not _siren.playing:
			_siren.play()
		_siren.volume_db = linear_to_db(_siren_level * 0.45)
	elif _siren.playing:
		_siren.stop()

	_rain_level = move_toward(_rain_level, _rain_target, delta * 0.4)
	if _rain_level > 0.01:
		if not _rain.playing:
			_rain.play()
		_rain.volume_db = linear_to_db(_rain_level * 0.35)
	elif _rain.playing:
		_rain.stop()

	if _music_task >= 0 and WorkerThreadPool.is_task_completed(_music_task):
		WorkerThreadPool.wait_for_task_completion(_music_task)
		_music_task = -1
		if _wanted_tune >= 0:
			play_music(_wanted_tune, _wanted_tune_pos)


# ----------------------------------------------------------------------------
#  JULKINEN RAJAPINTA
# ----------------------------------------------------------------------------
## Paikkasidottu ääni. pitch_var = satunnainen sävelkorkeuden vaihtelu (+-).
func play(sound: String, at: Vector2, volume_db: float = 0.0, pitch_var: float = 0.08, pitch: float = 1.0) -> void:
	if not _streams.has(sound):
		return
	var p := _pool2d[_next2d]
	_next2d = (_next2d + 1) % _pool2d.size()
	p.stream = _streams[sound]
	p.global_position = at
	p.volume_db = volume_db
	p.pitch_scale = maxf(pitch + randf_range(-pitch_var, pitch_var), 0.05)
	p.play()


## Ääni ilman sijaintia (rahan maksu, viestit).
func play_ui(sound: String, volume_db: float = 0.0, pitch: float = 1.0) -> void:
	if not _streams.has(sound):
		return
	var p := _pool[_next]
	_next = (_next + 1) % _pool.size()
	p.stream = _streams[sound]
	p.volume_db = volume_db
	p.pitch_scale = pitch
	p.play()


## 0 = hiljaa, 1 = poliisiauto aivan vieressä.
func set_siren(strength: float) -> void:
	_siren_target = clampf(strength, 0.0, 1.0)


## Ukkosen jyrinä viiveellä (salama ensin, ääni perässä).
func thunder(delay: float) -> void:
	await get_tree().create_timer(delay).timeout
	play_ui("thunder", randf_range(-6.0, 0.0), randf_range(0.85, 1.1))


## Sateen kohina 0..1 (Atmosphere säätää).
func set_rain(strength: float) -> void:
	_rain_target = clampf(strength, 0.0, 1.0)


func tune_count() -> int:
	return TUNE_NAMES.size()


func tune_name(i: int) -> String:
	return TUNE_NAMES[i] if i >= 0 and i < TUNE_NAMES.size() else ""


func play_music(tune: int, at: Vector2) -> void:
	_wanted_tune = tune
	_wanted_tune_pos = at
	if _music_task >= 0:
		return   # kappaleet vielä laskussa: alkaa soida kun valmista
	if tune < 0 or tune >= _tunes.size():
		return
	_music.global_position = at
	if _music.stream != _tunes[tune] or not _music.playing:
		_music.stream = _tunes[tune]
		_music.volume_db = -6.0
		_music.play()


func stop_music() -> void:
	_wanted_tune = -1
	_music.stop()


func music_playing() -> bool:
	return _music.playing or (_music_task >= 0 and _wanted_tune >= 0)


# ----------------------------------------------------------------------------
#  APUFUNKTIOT
# ----------------------------------------------------------------------------
static func _buf(seconds: float, rate: int = RATE) -> PackedFloat32Array:
	var b := PackedFloat32Array()
	b.resize(int(seconds * rate))
	b.fill(0.0)
	return b


static func _wav(buf: PackedFloat32Array, rate: int = RATE, loop: bool = false) -> AudioStreamWAV:
	var bytes := PackedByteArray()
	bytes.resize(buf.size() * 2)
	for i in buf.size():
		bytes.encode_s16(i * 2, int(clampf(buf[i], -1.0, 1.0) * 32000.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = rate
	w.stereo = false
	w.data = bytes
	if loop:
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = buf.size()
	return w


static func _normalize(b: PackedFloat32Array, peak: float = 0.9) -> PackedFloat32Array:
	var m := 0.0001
	for v in b:
		m = maxf(m, absf(v))
	var k := peak / m
	for i in b.size():
		b[i] *= k
	return b


# ----------------------------------------------------------------------------
#  ÄÄNTEN SYNTEESI
# ----------------------------------------------------------------------------
## Nyrkki osuu: matala tömähdys + lyhyt rätinä.
func _gen_punch_hit() -> PackedFloat32Array:
	var b := _buf(0.16)
	var ph := 0.0
	var lp := 0.0
	for i in b.size():
		var t := float(i) / RATE
		var f := lerpf(140.0, 45.0, minf(t / 0.08, 1.0))
		ph += TAU * f / RATE
		var body := sin(ph) * exp(-t * 28.0)
		lp += 0.35 * (randf_range(-1.0, 1.0) - lp)
		var crack := lp * exp(-t * 90.0) * 0.9
		b[i] = body + crack
	return _normalize(b)


## Huti: kohiseva suhahdus.
func _gen_whoosh() -> PackedFloat32Array:
	var b := _buf(0.15)
	var lp := 0.0
	var lp2 := 0.0
	for i in b.size():
		var t := float(i) / b.size()
		var a := lerpf(0.05, 0.35, t)
		lp += a * (randf_range(-1.0, 1.0) - lp)
		lp2 += 0.5 * (lp - lp2)
		b[i] = (lp - lp2 * 0.6) * sin(PI * t)
	return _normalize(b, 0.5)


## Askel: pehmeä, matala napsahdus.
func _gen_step() -> PackedFloat32Array:
	var b := _buf(0.06)
	var lp := 0.0
	for i in b.size():
		var t := float(i) / RATE
		lp += 0.18 * (randf_range(-1.0, 1.0) - lp)
		b[i] = lp * exp(-t * 70.0) + sin(TAU * 90.0 * t) * exp(-t * 60.0) * 0.4
	return _normalize(b, 0.6)


## Laukaus: terävä kohinapamaus + matala jysähdys.
func _gen_gun() -> PackedFloat32Array:
	var b := _buf(0.32)
	var lp := 0.0
	for i in b.size():
		var t := float(i) / RATE
		lp += lerpf(0.9, 0.15, minf(t / 0.1, 1.0)) * (randf_range(-1.0, 1.0) - lp)
		b[i] = lp * exp(-t * 16.0) + sin(TAU * 70.0 * t) * exp(-t * 22.0) * 0.8
	return _normalize(b)


## Kolikko: kaksi korkeaa piippausta.
func _gen_coin() -> PackedFloat32Array:
	var b := _buf(0.16)
	for i in b.size():
		var t := float(i) / RATE
		var f := 1320.0 if t < 0.05 else 1760.0
		var env := exp(-maxf(t - (0.0 if t < 0.05 else 0.05), 0.0) * 25.0)
		b[i] = signf(sin(TAU * f * t)) * 0.3 * env
	return _normalize(b, 0.45)


## Lasi kilahtaa tiskiin.
func _gen_clink() -> PackedFloat32Array:
	var b := _buf(0.35)
	for i in b.size():
		var t := float(i) / RATE
		b[i] = (sin(TAU * 2450.0 * t) + 0.6 * sin(TAU * 3710.0 * t) + 0.3 * sin(TAU * 5300.0 * t)) * exp(-t * 14.0)
	return _normalize(b, 0.4)


## Oluttölkki aukeaa: "pssh".
func _gen_can() -> PackedFloat32Array:
	var b := _buf(0.4)
	var hp := 0.0
	var prev := 0.0
	for i in b.size():
		var t := float(i) / RATE
		var x := randf_range(-1.0, 1.0)
		hp = 0.7 * (hp + x - prev)   # ylipäästö: kirkas sihinä
		prev = x
		var click := 0.0
		if t < 0.006:
			click = 1.0 - t / 0.006
		b[i] = hp * exp(-t * 7.0) * minf(t / 0.01, 1.0) * 0.6 + click
	return _normalize(b, 0.45)


## Kulaus: matala, kupliva "glug".
func _gen_gulp() -> PackedFloat32Array:
	var b := _buf(0.22)
	var ph := 0.0
	for i in b.size():
		var t := float(i) / RATE
		var f := 180.0 + 220.0 * sin(PI * t / 0.22)
		ph += TAU * f / RATE
		b[i] = sin(ph) * sin(PI * t / 0.22)
	return _normalize(b, 0.4)


## Kassakone: "ka-tsing".
func _gen_cash() -> PackedFloat32Array:
	var b := _buf(0.7)
	var lp := 0.0
	for i in b.size():
		var t := float(i) / RATE
		lp += 0.6 * (randf_range(-1.0, 1.0) - lp)
		var click := lp * exp(-t * 60.0) * 0.8
		var tb := maxf(t - 0.07, 0.0)
		var bell := 0.0
		if t >= 0.07:
			bell = (sin(TAU * 2093.0 * tb) + 0.7 * sin(TAU * 2637.0 * tb) + 0.4 * sin(TAU * 4186.0 * tb)) * exp(-tb * 6.0)
		b[i] = click + bell * 0.5
	return _normalize(b, 0.5)


## Sellin ovi: raskas metallinen kalahdus.
func _gen_clang() -> PackedFloat32Array:
	var b := _buf(1.1)
	var lp := 0.0
	var partials := [[110.0, 1.0, 3.0], [263.0, 0.7, 4.0], [431.0, 0.5, 5.0], [697.0, 0.35, 7.0], [1130.0, 0.25, 9.0]]
	for i in b.size():
		var t := float(i) / RATE
		var v := 0.0
		for p: Array in partials:
			v += sin(TAU * float(p[0]) * t) * float(p[1]) * exp(-t * float(p[2]))
		lp += 0.5 * (randf_range(-1.0, 1.0) - lp)
		v += lp * exp(-t * 40.0) * 1.2
		b[i] = v
	return _normalize(b, 0.7)


## Puhelin: kolme lyhyttä 425 Hz:n merkkiääntä (suomalainen soittoääni).
func _gen_phone() -> PackedFloat32Array:
	var b := _buf(0.9)
	for i in b.size():
		var t := float(i) / RATE
		var slot := fmod(t, 0.3)
		var on := 1.0 if slot < 0.16 else 0.0
		b[i] = sin(TAU * 425.0 * t) * on * 0.5
	return _normalize(b, 0.35)


## Ei onnistu: matala surina.
func _gen_denied() -> PackedFloat32Array:
	var b := _buf(0.25)
	for i in b.size():
		var t := float(i) / RATE
		b[i] = signf(sin(TAU * 140.0 * t)) * 0.3 * (1.0 - t / 0.25)
	return _normalize(b, 0.3)


## Poliisin sireeni: kaksisävel (ii-aa), silmukka. Sävelet ovat kokonaisia jaksoja,
## joten silmukka saumautuu ilman napsahdusta.
func _gen_siren() -> PackedFloat32Array:
	var b := _buf(1.2)
	var ph := 0.0
	for i in b.size():
		var t := float(i) / RATE
		var f := 740.0 if t < 0.6 else 555.0
		ph += TAU * f / RATE
		# pyöristetty kanttiaalto (parittomat harmoniset)
		b[i] = sin(ph) + sin(ph * 3.0) / 3.0 + sin(ph * 5.0) / 5.0
	return _normalize(b, 0.6)


## Torjunta: tylppä tömähdys + napsahdus.
func _gen_block() -> PackedFloat32Array:
	var b := _buf(0.12)
	for i in b.size():
		var t := float(i) / RATE
		b[i] = sin(TAU * 70.0 * t) * exp(-t * 35.0) + randf_range(-1.0, 1.0) * exp(-t * 200.0) * 0.6
	return _normalize(b, 0.6)


## Sähköase: rätisevä surina.
func _gen_taser() -> PackedFloat32Array:
	var b := _buf(0.7)
	for i in b.size():
		var t := float(i) / RATE
		var buzz := signf(sin(TAU * 95.0 * t)) * 0.4
		var crackle := randf_range(-1.0, 1.0) * (1.0 if randf() < 0.08 else 0.15)
		b[i] = (buzz + crackle) * (1.0 - t / 0.7)
	return _normalize(b, 0.55)


## Lasi särkyy.
func _gen_glass_break() -> PackedFloat32Array:
	var b := _buf(0.6)
	var prev := 0.0
	var tinkles: Array = []
	for k in 10:
		tinkles.append([randf_range(0.0, 0.35), randf_range(2500.0, 6000.0)])
	for i in b.size():
		var t := float(i) / RATE
		var x := randf_range(-1.0, 1.0)
		var hp := x - prev
		prev = x
		var v := hp * exp(-t * 12.0) * 0.6
		for tk: Array in tinkles:
			var st: float = tk[0]
			if t >= st:
				v += sin(TAU * float(tk[1]) * (t - st)) * exp(-(t - st) * 30.0) * 0.25
		b[i] = v
	return _normalize(b, 0.55)


## Kolari: matala jysähdys, rätisevä pelti ja kilahtelevia metallinsiruja.
func _gen_crash() -> PackedFloat32Array:
	var b := _buf(0.7)
	var ph := 0.0
	var lp := 0.0
	var prev := 0.0
	var partials := [[180.0, 0.5, 9.0], [377.0, 0.35, 12.0], [610.0, 0.3, 14.0], [1290.0, 0.18, 18.0]]
	var rattles: Array = []
	for k in 7:
		rattles.append([randf_range(0.04, 0.4), randf_range(1800.0, 4200.0)])
	for i in b.size():
		var t := float(i) / RATE
		var f := lerpf(110.0, 38.0, minf(t / 0.12, 1.0))
		ph += TAU * f / RATE
		var v := sin(ph) * exp(-t * 14.0) * 1.1
		var x := randf_range(-1.0, 1.0)
		lp += 0.25 * (x - lp)
		v += lp * exp(-t * 7.0) * 1.3
		var hp := x - prev
		prev = x
		v += hp * exp(-t * 22.0) * 0.5
		for p: Array in partials:
			v += sin(TAU * float(p[0]) * t) * float(p[1]) * exp(-t * float(p[2]))
		for r: Array in rattles:
			var st: float = r[0]
			if t >= st:
				v += sin(TAU * float(r[1]) * (t - st)) * exp(-(t - st) * 35.0) * 0.2
		b[i] = v
	return _normalize(b, 0.9)


## Tömähdys: vartalo osuu konepeltiin / maahan.
func _gen_thud() -> PackedFloat32Array:
	var b := _buf(0.22)
	var ph := 0.0
	var lp := 0.0
	for i in b.size():
		var t := float(i) / RATE
		var f := lerpf(95.0, 40.0, minf(t / 0.1, 1.0))
		ph += TAU * f / RATE
		lp += 0.15 * (randf_range(-1.0, 1.0) - lp)
		b[i] = sin(ph) * exp(-t * 18.0) + lp * exp(-t * 30.0) * 0.8
	return _normalize(b, 0.85)


## Räjähdys: terävä pamaus, matala jyrinä ja rätisevä jälkikaiku.
func _gen_explosion() -> PackedFloat32Array:
	var b := _buf(1.8)
	var ph := 0.0
	var lp := 0.0
	var lp2 := 0.0
	var prev := 0.0
	var crackles: Array = []
	for k in 40:
		crackles.append([randf_range(0.05, 1.3), randf_range(0.3, 1.0)])
	for i in b.size():
		var t := float(i) / RATE
		# matala pamaus, joka laskee
		var f := lerpf(70.0, 26.0, minf(t / 0.35, 1.0))
		ph += TAU * f / RATE
		var v := sin(ph) * exp(-t * 3.2) * 1.2
		var x := randf_range(-1.0, 1.0)
		# jyrinä: voimakkaasti alipäästetty kohina
		lp += 0.06 * (x - lp)
		lp2 += 0.03 * (lp - lp2)
		v += lp2 * exp(-t * 1.8) * 5.0
		# terävä alku
		var hp := x - prev
		prev = x
		v += hp * exp(-t * 40.0) * 0.9
		v += lp * exp(-t * 6.0) * 1.2
		# palavan romun rätinä
		for c: Array in crackles:
			var st: float = c[0]
			if t >= st and t < st + 0.012:
				v += randf_range(-1.0, 1.0) * float(c[1]) * 0.35 * exp(-t * 1.5)
		b[i] = v * minf(t / 0.002, 1.0)
	return _normalize(b, 0.98)


## Syttyminen: humahdus (kohina, joka nousee ja laskee).
func _gen_ignite() -> PackedFloat32Array:
	var b := _buf(0.7)
	var lp := 0.0
	for i in b.size():
		var t := float(i) / RATE
		lp += 0.12 * (randf_range(-1.0, 1.0) - lp)
		var env := minf(t / 0.08, 1.0) * exp(-maxf(t - 0.08, 0.0) * 4.5)
		b[i] = lp * env
	return _normalize(b, 0.7)


## Auton tööttäys: kaksi epävireistä sahalaitaa yhdessä.
func _gen_horn() -> PackedFloat32Array:
	var b := _buf(0.38)
	for i in b.size():
		var t := float(i) / RATE
		var a := minf(t / 0.02, 1.0) * minf((0.38 - t) / 0.04, 1.0)
		var s1 := fmod(t * 392.0, 1.0) * 2.0 - 1.0
		var s2 := fmod(t * 494.0, 1.0) * 2.0 - 1.0
		b[i] = (s1 + s2) * 0.5 * a
	return _normalize(b, 0.45)


## Sade: pehmeä kohina (silmukka).
func _gen_rain() -> PackedFloat32Array:
	var b := _buf(2.0)
	var lp := 0.0
	for i in b.size():
		lp += 0.25 * (randf_range(-1.0, 1.0) - lp)
		var drop := 0.0
		if randf() < 0.002:
			drop = randf_range(0.3, 0.8)
		b[i] = lp + drop * randf_range(-1.0, 1.0)
	return _normalize(b, 0.5)


## Ukkonen: matala, vyöryvä jyrinä.
func _gen_thunder() -> PackedFloat32Array:
	var b := _buf(3.2)
	var lp := 0.0
	var lp2 := 0.0
	for i in b.size():
		var t := float(i) / RATE
		lp += 0.04 * (randf_range(-1.0, 1.0) - lp)
		lp2 += 0.08 * (lp - lp2)
		var env := minf(t / 0.08, 1.0) * exp(-t * 1.1) * (0.7 + 0.3 * sin(t * 9.0) * sin(t * 2.3))
		var crack := randf_range(-1.0, 1.0) * exp(-t * 25.0) * 0.4
		b[i] = lp2 * env * 6.0 + crack
	return _normalize(b, 0.85)


## Tikka osuu tauluun.
func _gen_dart() -> PackedFloat32Array:
	var b := _buf(0.12)
	for i in b.size():
		var t := float(i) / RATE
		b[i] = (sin(TAU * 900.0 * t) * 0.3 + randf_range(-1.0, 1.0) * 0.6) * exp(-t * 60.0)
	return _normalize(b, 0.5)


## Biljardipallot kopsahtavat.
func _gen_pool() -> PackedFloat32Array:
	var b := _buf(0.15)
	for i in b.size():
		var t := float(i) / RATE
		b[i] = (sin(TAU * 1800.0 * t) + 0.5 * sin(TAU * 3100.0 * t)) * exp(-t * 45.0)
	return _normalize(b, 0.5)


# ----------------------------------------------------------------------------
#  JUKEBOKSIN MUSIIKKI (lasketaan taustasäikeessä)
# ----------------------------------------------------------------------------
func _build_tunes() -> void:
	var list: Array[AudioStreamWAV] = []
	list.append(_wav(_gen_tune(0), MUSIC_RATE, true))
	list.append(_wav(_gen_tune(1), MUSIC_RATE, true))
	_tunes = list


## Lisää sävelen puskuriin. wave: 0 = sini, 1 = haitari (kaksi hieman eri vireistä
## pulssiaaltoa), 2 = basso (pehmeä kolmio).
func _note(start: float, dur: float, midi: float, amp: float, wave: int) -> void:
	var f := 440.0 * pow(2.0, (midi - 69.0) / 12.0)
	var s0 := int(start * MUSIC_RATE)
	var n := int(dur * MUSIC_RATE)
	var rel := mini(int(0.03 * MUSIC_RATE), n / 2)
	for k in n:
		var i := s0 + k
		if i >= _mb.size():
			break
		var t := float(k) / MUSIC_RATE
		var env := minf(float(k) / 40.0, 1.0)
		if k > n - rel:
			env *= float(n - k) / float(rel)
		var v := 0.0
		match wave:
			0:
				v = sin(TAU * f * t)
			1:
				var p1 := fmod(f * t, 1.0)
				var p2 := fmod(f * 1.006 * t, 1.0)
				v = (0.5 if p1 < 0.35 else -0.5) + (0.5 if p2 < 0.35 else -0.5)
				v *= 0.6
			2:
				var p := fmod(f * t, 1.0)
				v = 4.0 * absf(p - 0.5) - 1.0
		_mb[i] += v * amp * env


func _drum(start: float, kick: bool, amp: float) -> void:
	var s0 := int(start * MUSIC_RATE)
	var n := int((0.18 if kick else 0.09) * MUSIC_RATE)
	var lp := 0.0
	var ph := 0.0
	for k in n:
		var i := s0 + k
		if i >= _mb.size():
			break
		var t := float(k) / MUSIC_RATE
		if kick:
			ph += TAU * lerpf(110.0, 45.0, minf(t / 0.1, 1.0)) / MUSIC_RATE
			_mb[i] += sin(ph) * exp(-t * 22.0) * amp
		else:
			# säieturvallinen pseudokohina (ei globaalia satunnaislukugeneraattoria)
			var noise := fmod(sin(float(i) * 12.9898) * 43758.5453, 1.0) * 2.0
			lp += 0.7 * (noise - lp)
			_mb[i] += lp * exp(-t * 45.0) * amp * 0.6


## tune 0 = humppa (A-molli, 140 bpm), tune 1 = tango (D-molli, 104 bpm).
func _gen_tune(tune: int) -> PackedFloat32Array:
	var rng := RandomNumberGenerator.new()
	rng.seed = 1234 + tune * 77
	# soinnut: [basson pohjasävel, soinnun sävelet]
	var chords := {
		"Am": [45, [57, 60, 64]], "Dm": [38, [57, 62, 65]], "E": [40, [56, 59, 64]],
		"Gm": [43, [55, 58, 62]], "A": [45, [57, 61, 64]], "C": [48, [55, 60, 64]],
	}
	var prog: Array
	var bpm: float
	if tune == 0:
		prog = ["Am", "Am", "Dm", "Am", "E", "E", "Am", "Am", "C", "C", "Dm", "Am", "Dm", "E", "Am", "Am"]
		bpm = 140.0
	else:
		prog = ["Dm", "Dm", "A", "A", "A", "A", "Dm", "Dm", "Gm", "Gm", "Dm", "Dm", "A", "A", "Dm", "Dm"]
		bpm = 104.0
	var beat := 60.0 / bpm
	var bar := beat * 4.0
	_mb = _buf(bar * prog.size(), MUSIC_RATE)

	var melody_prev := 72
	for bi in prog.size():
		var ch: Array = chords[prog[bi]]
		var root: int = ch[0]
		var tones: Array = ch[1]
		var t0 := bi * bar
		if tune == 0:
			# Humppa: umpa-umpa. Basso iskuilla 1 ja 3, sointu iskuilla 2 ja 4
			_note(t0, beat * 0.8, root, 0.55, 2)
			_note(t0 + beat * 2.0, beat * 0.8, root + 7, 0.5, 2)
			for off: float in [1.0, 3.0]:
				for m: int in tones:
					_note(t0 + beat * off, beat * 0.45, m, 0.12, 1)
			_drum(t0, true, 0.5)
			_drum(t0 + beat * 2.0, true, 0.45)
			_drum(t0 + beat, false, 0.45)
			_drum(t0 + beat * 3.0, false, 0.45)
		else:
			# Tango: basso 3-3-2-rytmillä, haitarisointu taustalla
			for e: float in [0.0, 1.5, 3.0]:
				_note(t0 + beat * e, beat * 0.5, root + (7 if e == 1.5 else 0), 0.55, 2)
			for m: int in tones:
				_note(t0, bar * 0.95, m - 12, 0.05, 1)
			_drum(t0, true, 0.4)
			_drum(t0 + beat * 1.5, true, 0.3)
			_drum(t0 + beat * 3.0, false, 0.35)

		# Melodia: soinnun säveliä oktaavi ylempänä, kahdeksasosia ja neljäsosia
		var pos := 0.0
		while pos < 4.0 - 0.01:
			var step := 0.5 if rng.randf() < 0.6 else 1.0
			if tune == 1 and rng.randf() < 0.3:
				step = 1.5
			step = minf(step, 4.0 - pos)
			if rng.randf() < 0.85:
				var cands: Array[int] = []
				for m: int in tones:
					for o: int in [12, 24]:
						cands.append(m + o)
				# valitaan lähin sävel edellisestä (laulava melodia), välillä hyppy
				cands.sort_custom(func(a: int, c: int) -> bool: return absi(a - melody_prev) < absi(c - melody_prev))
				var pick: int = cands[mini(rng.randi_range(0, 2), cands.size() - 1)]
				_note(t0 + pos * beat, step * beat * 0.92, pick, 0.22, 1 if tune == 0 else 0)
				melody_prev = pick
			pos += step
	var out := _normalize(_mb, 0.8)
	_mb = PackedFloat32Array()
	return out
