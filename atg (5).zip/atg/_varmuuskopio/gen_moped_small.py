# Suzuki PV -mopo pienempänä: 32x32 ruutu (2x) -> pelissä 16x16. Satula ~6 px, tanko ~9 px maasta
from PIL import Image, ImageDraw
S = 32
RED = (206, 30, 34); RED_L = (246, 96, 86); WHITE = (238, 238, 240)
CHR = (196, 200, 210); CHR_D = (120, 124, 134); BLK = (22, 20, 26); TIRE = (40, 40, 46)
SPOKE = (150, 152, 160); SEAT = (34, 30, 34); ENG = (96, 98, 106); LENS = (255, 240, 170); TAIL = (230, 40, 40)
G = 30   # maa

def wheel(d, cx, cy):
	d.ellipse((cx - 3, cy - 3, cx + 3, cy + 3), fill=BLK)
	d.ellipse((cx - 2, cy - 2, cx + 2, cy + 2), fill=TIRE)
	d.point((cx, cy), fill=CHR)

def side():
	im = Image.new('RGBA', (S, S), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
	wheel(d, 9, G - 3); wheel(d, 22, G - 3)
	d.arc((5, G - 7, 13, G + 1), 200, 340, fill=CHR)
	d.arc((18, G - 7, 26, G + 1), 200, 340, fill=CHR)
	d.line((9, G - 3, 14, G - 5), fill=CHR_D)
	d.line((21, 20, 22, G - 3), fill=CHR)                          # etuhaarukka
	d.rectangle((14, 25, 17, 27), fill=ENG)
	d.line((16, 27, 6, 26), fill=CHR)                              # pakoputki
	d.rectangle((12, 23, 14, 25), fill=WHITE)                      # sivukansi
	d.polygon([(15, 21), (20, 20), (21, 22), (19, 24), (15, 24)], fill=RED)   # tankki
	d.line((16, 22, 20, 21), fill=WHITE)
	d.rectangle((7, 22, 15, 23), fill=SEAT)                        # satula (yläpinta y=22)
	d.point((6, 23), fill=TAIL)
	d.rectangle((22, 20, 24, 22), fill=CHR); d.point((24, 21), fill=LENS)   # ajovalo
	d.line((19, 19, 22, 19), fill=BLK); d.line((21, 19, 21, 16), fill=CHR_D)   # tanko + peili
	return im

def front(back):
	im = Image.new('RGBA', (S, S), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
	cx = 16
	d.rectangle((cx - 1, G - 7, cx, G), fill=BLK)
	if back:
		d.rectangle((cx - 2, 21, cx + 1, 24), fill=SEAT)
		d.rectangle((cx - 2, 19, cx + 1, 20), fill=RED)
		d.rectangle((cx - 1, 24, cx, 25), fill=TAIL)
		d.rectangle((cx - 1, 26, cx, 27), fill=WHITE)
		d.line((cx + 3, 24, cx + 3, 28), fill=CHR)
	else:
		d.rectangle((cx - 2, 20, cx + 1, 22), fill=RED)
		d.line((cx - 2, 22, cx - 2, 27), fill=CHR); d.line((cx + 1, 22, cx + 1, 27), fill=CHR)
		d.rectangle((cx - 2, 21, cx + 1, 23), fill=CHR); d.rectangle((cx - 1, 22, cx, 22), fill=LENS)
	d.line((cx - 5, 19, cx + 4, 19), fill=BLK)
	d.line((cx - 5, 18, cx - 6, 16), fill=CHR_D); d.line((cx + 4, 18, cx + 5, 16), fill=CHR_D)
	return im

sheet = Image.new('RGBA', (S * 4, S * 2), (0, 0, 0, 0))
for row in range(2):
	r = side()
	sheet.paste(r.transpose(Image.FLIP_LEFT_RIGHT), (0, S * row))
	sheet.paste(front(False), (S, S * row))
	sheet.paste(front(True), (S * 2, S * row))
	sheet.paste(r, (S * 3, S * row))
sheet.save('assets/sprites/vehicles/moped_hd.png')
# esikatselu: mopo + seisova pelaaja vieressä samassa mittakaavassa
pl = Image.open('assets/sprites/player/characters_hd.png').convert('RGBA').crop((96, 12 * 32, 128, 13 * 32))
prev = Image.new('RGBA', (S * 5, S), (110, 110, 115, 255))
prev.paste(sheet.crop((0, 0, S * 4, S)), (0, 0), sheet.crop((0, 0, S * 4, S)))
prev.paste(pl, (S * 4 - 6, 0), pl)
prev.resize((prev.width * 5, prev.height * 5), Image.NEAREST).save('_varmuuskopio/kartano2/moped_small.png')
print('ok')
