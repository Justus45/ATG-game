# Tekee baarin henkilökunnan hahmokuvat (staff_hd.png) characters_hd.png:n NPC-tyypeistä:
# samat hahmot, mutta vaatteet vaihdetaan: tarjoilija (valkoinen paita, musta liivi, rusetti),
# ovimies (musta t-paita) ja kokki (valkoinen takki napeilla).
# Rivit: (asu * 3 + tyyppi) * 3 + askel, sarakkeet 0 vasen, 1 alas, 2 ylös, 3 oikea.
from PIL import Image
SRC='assets/sprites/player/characters_hd.png'
OUT='assets/sprites/player/staff_hd.png'
# NPC-tyyppien paita- ja housuvärit: (värit, rooli) rooli: m=perus, s=varjo, h=valo, d=ääriviiva
TYPES={
 0:{'shirt':{(62,160,118):'m',(40,116,84):'s',(104,194,148):'h',(22,49,43):'d',(236,236,214):'m'},
    'pants':{(164,150,110):'m',(76,65,52):'d',(158,108,72):'s'}},
 1:{'shirt':{(192,70,70):'m',(146,42,46):'s',(170,66,70):'h',(86,30,26):'d',(196,80,82):'h'},
    'pants':{(84,90,146):'m',(37,36,66):'d'}},
 2:{'shirt':{(216,136,58):'m',(176,94,38):'s',(240,172,88):'h',(252,208,140):'h',(77,40,24):'d'},
    'pants':{(42,98,60):'m',(25,44,36):'d'}},
}
WHITE={'m':(238,238,234),'s':(196,198,204),'h':(252,252,250),'d':(70,72,82)}
VEST={'m':(48,48,58),'s':(32,32,40),'h':(72,72,86),'d':(16,16,22)}
BLACK_T={'m':(42,42,50),'s':(28,28,34),'h':(66,66,78),'d':(14,14,18)}
PANTS_BLACK={'m':(40,40,48),'s':(30,30,36),'d':(20,20,26)}
PANTS_GRAY={'m':(96,96,104),'s':(74,74,82),'d':(46,46,54)}

def outfit_frame(fr, t, col, outfit):
    fr=fr.copy(); px=fr.load(); W,H=fr.size
    sh=TYPES[t]['shirt']; pa=TYPES[t]['pants']
    spts=[(x,y) for y in range(H) for x in range(W) if px[x,y][3]>128 and px[x,y][:3] in sh]
    if not spts: return fr
    xs=[p[0] for p in spts]; ys=[p[1] for p in spts]
    cx=(min(xs)+max(xs))/2.0
    top=min(ys)
    for (x,y) in spts:
        role=sh[px[x,y][:3]]
        if outfit=='waiter':
            if col==1:
                dx=abs(x+0.5-cx-0.5)
                c=WHITE[role] if (dx<=2.0 or dx>5.5) else VEST[role]
            elif col==2:
                dx=abs(x+0.5-cx-0.5)
                c=VEST[role] if dx<=5.5 else WHITE[role]
            else:
                # sivulta: etureunassa valkoinen paita, muuten liivi; kädet valkoiset
                row=[p[0] for p in spts if p[1]==y]
                front=min(row) if col==0 else max(row)
                c=WHITE[role] if abs(x-front)<=1 else VEST[role]
            if role=='d': c=VEST['d']
        elif outfit=='bouncer':
            c=BLACK_T[role]
        else:  # chef
            c=WHITE[role]
            if col==1 and abs(x+0.5-cx-0.5) in (2.0,2.5) and (y-top)%3==1: c=(70,72,82)
        px[x,y]=c+(255,)
    pants=PANTS_GRAY if outfit=='chef' else PANTS_BLACK
    for y in range(H):
        for x in range(W):
            p=px[x,y]
            if p[3]>128 and p[:3] in pa:
                px[x,y]=pants[pa[p[:3]] if pa[p[:3]] in pants else 'm']+(255,)
    # rusetti tarjoilijalle (edestä)
    if outfit=='waiter' and col==1:
        ci=int(round(cx))
        for x in range(ci-2,ci+2):
            y=top+1
            if px[x,y][3]>128: px[x,y]=(200,28,40,255)
        if px[ci,top+1][3]>128: px[ci-1,top+1]=(140,16,24,255)
    if outfit=='bouncer' and col==1:
        # kuulokenappi korvassa ja tunnus rinnassa
        ci=int(round(cx))
        for x in range(ci+2,ci+5):
            if px[x,top+3][3]>128: px[x,top+3]=(230,200,60,255)
    return fr

src=Image.open(SRC).convert('RGBA')
outfits=['waiter','bouncer','chef']
out=Image.new('RGBA',(128,len(outfits)*3*3*32),(0,0,0,0))
for oi,o in enumerate(outfits):
    for ti,t in enumerate([0,1,2]):
        for step in range(3):
            for col in range(4):
                fr=src.crop((col*32,(t*3+step)*32,col*32+32,(t*3+step)*32+32))
                nf=outfit_frame(fr,t,col,o)
                out.paste(nf,(col*32,((oi*3+ti)*3+step)*32))
out.save(OUT)
prev=Image.new('RGBA',out.size,(120,140,120,255)); prev.alpha_composite(out)
prev=prev.crop((0,0,128,864))
# vain askel 0 esikatseluun
rows=[prev.crop((0,r*96,128,r*96+32)) for r in range(9)]
p2=Image.new('RGBA',(128,32*9))
for i,r in enumerate(rows): p2.paste(r,(0,i*32))
p2.resize((128*4,32*9*4),Image.NEAREST).save('_varmuuskopio/_staff_preview.png')
print('ok',out.size)
