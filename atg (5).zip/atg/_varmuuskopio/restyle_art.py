"""Uusi yhtenäinen ulkoasu ATG:n pikseligrafiikalle.
Pitää ruutujen paikat ja läpinäkyvyyden (törmäysmuodot) ennallaan, vaihtaa värit
yhteiseen palettiin ja lisää materiaaleille tekstuurit."""
import colorsys, math, sys, os
from PIL import Image

# ---------------------------------------------------------------- PALETTI
# Jokainen ramppi tummasta vaaleaan. Varjot kallistuvat siniseen/violettiin, valot keltaiseen.
R = {
 "ink":     [(22,20,30)],
 "asphalt": [(34,36,48),(44,47,60),(54,58,72),(66,70,85),(82,86,100),(102,106,118)],
 "steel":   [(46,48,66),(66,70,92),(92,98,122),(124,130,152),(160,166,184),(198,204,216),(232,236,240)],
 "stone":   [(70,64,72),(98,90,96),(128,120,122),(158,150,146),(188,180,170),(214,208,196),(236,232,220)],
 "sand":    [(96,78,66),(130,110,88),(166,146,116),(198,180,144),(222,208,172),(240,232,202)],
 "grass":   [(26,52,40),(36,74,46),(50,98,52),(70,124,58),(98,150,66),(136,176,82),(178,200,110)],
 "teal":    [(20,58,60),(28,88,84),(40,120,104),(66,154,126),(112,190,154),(170,222,186)],
 "autumn":  [(70,30,34),(112,42,36),(160,62,40),(204,96,48),(232,138,64),(248,184,104)],
 "brick":   [(58,28,36),(92,38,44),(128,50,50),(164,68,60),(196,98,80),(224,140,112)],
 "terra":   [(82,46,38),(122,68,44),(164,96,56),(202,128,72),(230,166,100),(246,206,146)],
 "wood":    [(54,36,32),(84,54,40),(118,78,52),(156,108,68),(194,146,94),(224,186,132)],
 "water":   [(22,40,74),(30,62,104),(40,92,138),(58,128,170),(96,166,200),(158,206,226),(214,238,244)],
 "skin":    [(98,56,48),(150,90,68),(196,128,94),(228,170,130),(246,206,170)],
 "gold":    [(110,74,30),(164,112,38),(212,160,56),(240,204,96),(252,236,160)],
 "navy":    [(22,26,52),(32,40,80),(46,60,116),(70,92,160),(110,138,200)],
 "white":   [(236,232,222),(250,248,242)],
}
def lum(c):
    r,g,b=[x/255 for x in c]; return 0.299*r+0.587*g+0.114*b

def hsv(c):
    return colorsys.rgb_to_hsv(*[x/255 for x in c])

def pick(ramp, L, bias=0.0):
    """Valitse rampista sävy, jonka kirkkaus on lähimpänä (L 0..1)."""
    rs=R[ramp]
    best=min(rs, key=lambda c: abs(lum(c)-(L+bias)))
    return best

def classify(c):
    """Alkuperäinen väri -> (ramppi, kirkkaus-bias)."""
    h,s,v=hsv(c); hd=h*360; L=lum(c)
    if v<0.24: return "ink",0
    if s<0.12 and v>0.92: return "white",0
    # mintunvihreä (nurmi, puut) -> oikea vihreä
    if 140<=hd<=185 and s>0.35:
        return "grass",-0.03
    if 100<=hd<140 and s>0.3: return "grass",0
    # turkoosi / syaani (vesi, lasi)
    if 185<hd<=210 and s>0.35: return "water",0
    if 185<hd<=215 and s<=0.35 and v>0.85: return "water",0.02   # lasi / heijastus
    # sinivioletit harmaat (betoni, tie, rakennukset)
    if 200<=hd<=275 and s<0.42:
        return "steel",0
    if 200<=hd<=250 and s>=0.42: return "navy",0
    # punaiset
    if (hd<12 or hd>340) and s>0.35:
        return "brick",0
    if 340>=hd>=275: return "brick",0
    # oranssit
    if 12<=hd<32 and s>0.45:
        if v>0.95 and s<0.45: return "skin",0
        return "terra",0
    # iho
    if 15<=hd<35 and 0.2<s<=0.45 and v>0.85: return "skin",0
    # ruskeat
    if hd<40 and v<0.62: return "wood",0
    if 12<=hd<40: return "wood",0.02 if s>0.3 else 0
    # keltaiset
    if 35<=hd<62 and s>0.5: return "gold",0
    if 35<=hd<75: return "sand",0
    if 75<=hd<100: return "grass",0
    return "stone",0

# ---------------------------------------------------------------- KOHINA
def h2(x,y,seed=0):
    n=(x*374761393 + y*668265263 + seed*2246822519) & 0xffffffff
    n=(n^(n>>13))*1274126177 & 0xffffffff
    return ((n^(n>>16)) & 0xffff)/65535.0

def shade(ramp, base, d):
    rs=R[ramp]
    try: i=rs.index(base)
    except ValueError: return base
    return rs[max(0,min(len(rs)-1,i+d))]

# ---------------------------------------------------------------- MATERIAALIT
# Tekstuuri riippuu vain (x%16, y%16):sta -> ruudut liittyvät saumattomasti.
def _vnoise(lx, ly, cell, seed):
    """16-jaksollinen pehmeä arvokohina (0..1)."""
    n=16//cell
    gx,gy=lx/cell,ly/cell
    x0,y0=int(gx)%n,int(gy)%n; x1,y1=(x0+1)%n,(y0+1)%n
    fx,fy=gx-int(gx),gy-int(gy)
    fx=fx*fx*(3-2*fx); fy=fy*fy*(3-2*fy)
    a=h2(x0,y0,seed); b=h2(x1,y0,seed); c=h2(x0,y1,seed); d=h2(x1,y1,seed)
    return (a*(1-fx)+b*fx)*(1-fy)+(c*(1-fx)+d*fx)*fy

def tex_grass(base, x, y):
    lx,ly=x%16,y%16
    v=_vnoise(lx,ly,8,31)*0.7+_vnoise(lx,ly,4,32)*0.3
    b=base
    if v<0.32 and (lx+ly)%2==0 and (lx%2==0 or v<0.24): b=shade("grass",base,-1)   # tummempi laikku (ditteröity)
    elif v>0.76 and (lx+ly)%2==0 and lx%2==0: b=shade("grass",base,1)
    # harvat ruohonkorret
    if h2(lx,ly,2)>0.975: return shade("grass",b,1)
    if h2(lx,(ly-1)%16,2)>0.975: return shade("grass",b,-1)
    if h2(lx,ly,7)>0.995: return R["gold"][3]
    if h2(lx,ly,8)>0.996: return R["white"][0]
    return b

def tex_asphalt(base, x, y):
    lx,ly=x%16,y%16
    r=h2(lx,ly,3)
    v=_vnoise(lx,ly,8,33)
    if r<0.10 or (v<0.3 and r<0.3): return shade("asphalt",base,-1)
    if r>0.985: return shade("asphalt",base,1)
    # pienet halkeamat
    if h2(lx//4,ly//4,21)>0.9 and (lx+ly)%4==0: return shade("asphalt",base,-1)
    return base

def tex_stone(ramp, base, x, y, size=8):
    """Kivilaatat: saumat joka size:nnes pikseli, laattojen sävy vaihtelee."""
    lx,ly=x%16,y%16
    off = (size//2) if (ly//size)%2 else 0          # limittäin
    tx,ty=(lx+off)%16, ly
    if ty%size==size-1 or tx%size==size-1:
        return shade(ramp,base,-1)
    if ty%size==0 and tx%size!=size-1:
        return shade(ramp,base,1) if h2(tx//size,ty//size,9)>0.3 else base
    t=h2((lx+off)//size, ly//size, 4)
    if t<0.25: b=shade(ramp,base,-1) if h2(lx,ly,5)<0.35 else base
    else: b=base
    if h2(lx,ly,6)>0.96: return shade(ramp,b,-1)
    return b

def tex_water(base, x, y):
    lx,ly=x%16,y%16
    # vaakasuorat aallonharjat
    w=(lx + 5*((ly//4)%2) ) % 8
    if ly%4==1 and w<3: return shade("water",base,1)
    if ly%4==2 and w<3 and h2(lx,ly,11)>0.5: return shade("water",base,-1)
    if h2(lx,ly,12)>0.985: return R["water"][-1]
    return base

def tex_roof(ramp, base, x, y):
    """Kattotiilet: rivit joka 4. pikseli, limitetty."""
    lx,ly=x%16,y%16
    off = 2 if (ly//4)%2 else 0
    if ly%4==3: return shade(ramp,base,-1)
    if (lx+off)%4==0 and ly%4!=3: return shade(ramp,base,-1) if h2(lx,ly,13)>0.4 else base
    if ly%4==0: return shade(ramp,base,1)
    return base

def tex_brick(ramp, base, x, y):
    lx,ly=x%16,y%16
    off = 4 if (ly//4)%2 else 0
    if ly%4==3 or (lx+off)%8==7: return shade(ramp,base,-1)
    if h2((lx+off)//8, ly//4, 14)<0.3: return shade(ramp,base,-1) if h2(lx,ly,15)<0.5 else base
    return base

def tex_foliage(ramp, base, x, y):
    lx,ly=x%16,y%16
    # pyöreät lehtiryppäät: vaalea yläreuna, tumma alareuna
    cx,cy=(lx//4)*4+2,(ly//4)*4+2
    dx,dy=lx-cx,ly-cy
    if dy<=-1 and abs(dx)<=1 and h2(lx//4,ly//4,16)>0.3: return shade(ramp,base,1)
    if dy>=1 and abs(dx)>=1: return shade(ramp,base,-1) if h2(lx,ly,17)>0.4 else base
    return base

# ---------------------------------------------------------------- ALUEET (tilemap, ruutukoordinaatit)
def region(tc, tr):
    """Mikä materiaali (jos mikään) tällä ruudulla on."""
    if tc<=7 and tr<=2: return "park"
    if 8<=tc<=15 and tr<=2: return "plaza"
    if tc<=7 and 3<=tr<=5: return "pavers"
    if 8<=tc<=15 and 3<=tr<=5: return "facade"
    if 8<=tc<=15 and 6<=tr<=8: return "water"
    if 16<=tc<=22 and tr<=3: return "roof_red"
    if 16<=tc<=22 and 4<=tr<=7: return "roof_orange"
    if 16<=tc<=22 and 8<=tr<=13: return "trees"
    if tc<=14 and 15<=tr<=17: return "road"
    return None

def material_pixel(reg, orig, new, ramp, x, y):
    if reg=="park" and ramp=="grass" and orig in GRASS_FILLS: return tex_grass(new,x,y)
    if reg in ("park","pavers") and ramp=="sand": return tex_stone("sand",new,x,y,8)
    if reg=="plaza" and ramp in ("steel","stone") and orig in PLAZA_FILLS: return tex_stone(ramp,new,x,y,8)
    if reg=="facade" and orig in FACADE_FILLS: return tex_brick(ramp,new,x,y)
    if reg=="facade" and orig in PLAZA_FILLS: return tex_stone(ramp,new,x,y,8)
    if reg=="water" and ramp=="water" and orig in WATER_FILLS: return tex_water(new,x,y)
    if reg=="road" and orig in ROAD_FILLS: return tex_asphalt(new,x,y)
    if reg=="road" and ramp=="steel" and lum(orig)<0.5: return pick("asphalt",lum(orig)-0.04)
    if reg in ("roof_red","roof_orange") and orig in ROOF_FILLS: return tex_roof(ramp,new,x,y)
    if reg=="trees" and ramp in ("grass","autumn") and orig in FOLIAGE_FILLS: return tex_foliage(ramp,new,x,y)
    return new

FACADE_FILLS={(170,174,186),(165,171,180),(158,163,172)}
GRASS_FILLS={(56,203,171)}
PLAZA_FILLS={(160,156,202),(170,168,189),(198,188,159)}
WATER_FILLS={(89,182,216),(100,192,225)}
ROAD_FILLS={(92,98,120)}
ROOF_FILLS={(194,80,77),(199,123,71),(220,134,82),(220,97,93)}
FOLIAGE_FILLS={(56,203,171),(66,223,171),(63,216,171),(59,210,171),(255,113,67),(218,96,56)}

# Erikoistapaukset: alkuperäinen väri -> (ramppi, indeksi)
FIXED = {
 (92,98,120): ("asphalt",3),      # tie
 (56,203,171): ("grass",3),       # nurmi
 (66,223,171): ("grass",4),
 (63,216,171): ("grass",4),
 (59,210,171): ("grass",4),
 (33,131,124): ("grass",1),
 (48,182,175): ("grass",2),
 (51,189,174): ("grass",2),
 (41,99,96):   ("grass",0),
 (160,156,202):("stone",4),       # aukio
 (170,168,189):("stone",4),
 (122,119,164):("stone",2),
 (181,176,221):("stone",5),
 (190,184,205):("stone",5),
 (205,201,231):("stone",6),
 (198,188,159):("sand",3),        # jalkakäytävä / lattia
 (214,212,175):("sand",4),
 (179,155,125):("sand",2),
 (89,182,216): ("water",3),
 (100,192,225):("water",4),
 (255,113,67): ("autumn",4),
 (218,96,56):  ("autumn",3),
 (194,80,77):  ("brick",3),       # punainen katto
 (220,97,93):  ("brick",4),
 (165,66,64):  ("brick",2),
 (125,69,82):  ("brick",1),
 (199,123,71): ("terra",3),       # oranssi katto
 (220,134,82): ("terra",4),
 (141,82,67):  ("terra",1),
 (170,174,186):("stone",4),       # julkisivu
 (165,171,180):("stone",4),
 (158,163,172):("stone",3),
 (245,169,76): ("gold",3),        # taksi
 (245,170,87): ("gold",3),
 (218,146,62): ("terra",3),
 (188,125,54): ("gold",1),
 (135,77,39):  ("wood",2),
}

_cache={}
def remap(c):
    if c in _cache: return _cache[c]
    if c in FIXED:
        rp,i=FIXED[c]; out=(R[rp][i],rp)
    else:
        rp,b=classify(c)
        out=(pick(rp,lum(c),b),rp)
    _cache[c]=out
    return out

def restyle(img, tiles=False, sep=1, tile=16):
    img=img.convert("RGBA")
    W,H=img.size
    src=img.load()
    out=Image.new("RGBA",(W,H),(0,0,0,0))
    dst=out.load()
    for y in range(H):
        for x in range(W):
            p=src[x,y]
            if p[3]==0: continue
            c=p[:3]
            new,rp=remap(c)
            if tiles:
                tc,tr=x//(tile+sep),y//(tile+sep)
                reg=region(tc,tr)
                if reg:
                    new=material_pixel(reg,c,new,rp,x-tc*(tile+sep),y-tr*(tile+sep))
            dst[x,y]=(new[0],new[1],new[2],p[3])
    return out

if __name__=="__main__":
    src_root, dst_root = sys.argv[1], sys.argv[2]
    for dp,_,fs in os.walk(src_root):
        for f in fs:
            if not f.endswith(".png"): continue
            sp=os.path.join(dp,f); rel=os.path.relpath(sp,src_root)
            o=restyle(Image.open(sp), tiles=(f=="tilemap.png"))
            op=os.path.join(dst_root,rel); os.makedirs(os.path.dirname(op),exist_ok=True)
            o.save(op)
            print("ok",rel)
